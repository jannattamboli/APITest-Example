#!/bin/bash

bundle install && bundle exec rake spec
