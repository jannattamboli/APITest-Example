# Infra-validation-gcpspec
Spec code to validate gcp resources
# RSpec/GcpSpec Tests for gcp resources 
These are generic GcpSpec Tests used by REAN-Test to test the Gcp Resource deployed by REAN-Deploy

## Prerequisite

     1. Ruby and Bundler must be installed to run GcpSpec
     
     2. You can set the (above) value to credential json file path using the following environment variables:
          * GOOGLE_APPLICATION_CREDENTIALS

   
## Installation

Add this line to your application's Gemfile:

```ruby
gem 'google-api-client'
```

And then execute:

    $ bundle

Or install it yourself as:

    $ gem install google-api-client

## Command to run GcpSpec

    $bash Run.sh
    
## How to use this spec

### Step 1. Input and Output from REAN Deploy
    
       Have your input i.e requirement json in the expected format as mentioned in the URL below
       REAN Deploy exposes endpoint to get output json 
       Send this combination of input and output json as infraParam.json to this GcpSpec code via REAN-Test
       
           
### Step 2. Execution of GcpSpec using REAN Test

       REAN Test is used to execute this GcpSpec. REAN Test will send the input and output json to this GcpSpec code as infraParam.json. This GcpSpec will not be executed correcly without infraParam.json file.
       

## How to add specs for more Gcp resources

### Step 1. Create directory with resource type in spec directory

    - Create directory named with gcp resource type like google_compute_instance  in spec/gcp_resources directory.
    - Define gcp resource type constant in ResourceType.rb file. Refer terraform documentation for gcp resource type.
    Example : GOOGLE_COMPUTE_INSTANCE="google_compute_instance". Values must be from terraform data sources. Refer below link.
 
https://registry.terraform.io/providers/hashicorp/google/latest/docs 

### Step 2. Create spec files under resource type directory

    - Create two file named with <resource_type>_spec.rb and <resource_type>_attributes.rb.
    Example : If resource type is google_compute_instance then files created will be agoogle_compute_instance_spec.rb and google_compute_instance_attributes.rb
    - <resource_type>_attributes.rb will contains all attributes for resources. Refer attributes reference from terraform documentaion for valid attributes.Define constant for each attribute in <resource_type>_attributes.rb

### step 3. Create spec class for each gcp resource
    - Create spec_class for each gcp resource which will act as wrapper class for gcp resource. This classs is used for rspec test.
    - You can test all gcp resource with the help of this wrapper class.
    
https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_instance

## List Of Supported Resources

| Resource Name                                               | Available Release Version       |
|-------------------------------------------------------------|---------------------------------|
|google_compute_instance                                      |  1.0 and later                  |
|google_compute_network                                       |  1.0 and later                  |
|google_compute_subnetwork                                    |  1.0 and later                  |
|google_compute_disk                                          |  1.0 and later                  |
|google_compute_machine_image                                 |  1.0 and later                  |
|google_compute_firewall                                      |  1.0 and later                  |
|google_compute_router                                        |  1.0 and later                  |
|google_compute_instance_template                             |  1.0 and later                  |
|google_compute_image                                         |  1.0 and later                  |
|google_compute_address                                       |  1.0 and later                  |
|google_compute_router_nat                                    |  1.0 and later                  |
|google_compute_autoscaler                                    |  1.0 and later                  |
|google_compute_instance_group_manager                        |  1.0 and later                  |
|google_storage_bucket_acl                                    |  1.0 and later                  |
|google_storage_bucket                                        |  1.0 and later                  |
|google_storage_default_object_acl                            |  1.0 and later                  |
|google_compute_vpn_gateway                                   |  1.0 and later                  |
|google_compute_target_instance                               |  1.0 and later                  |
|google_compute_route                                         |  1.0 and later                  |
|google_compute_instance_group                                |  1.0 and later                  |
|google_compute_target_pool                                   |  1.0 and later                  |
|google_compute_node_group                                    |  1.0 and later                  |
|google_compute_network_endpoint_group                        |  1.0 and later                  |
|google_container_node_pool                                   |  1.0 and later                  |
|google_compute_ssl_policy                                    |  1.0 and later                  |
|google_compute_ssl_certificate                               |  1.0 and later                  |
|google_compute_snapshot                                      |  1.0 and later                  |