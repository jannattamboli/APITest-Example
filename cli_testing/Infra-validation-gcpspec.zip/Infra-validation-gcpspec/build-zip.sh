
#!/bin/sh
home=$(pwd)
zip -r Infra-validation-gcpspec-$1.zip . -x *.git*
echo "Zip artifact for gcpspec infra validation automation is created." 
