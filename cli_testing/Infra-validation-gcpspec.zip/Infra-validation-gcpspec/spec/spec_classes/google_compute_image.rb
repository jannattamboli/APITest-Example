require_relative "../Util"
include Util

class GOOGLE_COMPUTE_IMAGE
  def initialize(project, image_name)
    @image_name = image_name
    begin
      puts "project : #{project}"
      puts "Image Name: #{image_name}"
      service = getClient("Compute")
      service.authorization = Google::Auth.get_application_default(["https://www.googleapis.com/auth/cloud-platform"])
      resource_name = get_resource_name(image_name)
      @resp = service.get_image(project, resource_name)
    rescue
      puts "The google_compute_image does not exist"
    end
  end

  def exists?
    if defined?(@resp) == nil || @resp.nil?
      fail "The google_compute_image : #{@image_name} does not exist"
    else
      true
    end
  end

  def name
    @resp.name
  end

  def description
    @resp.description
  end

  def has_labels?(input_key, input_value)
    _present = false
    labels = @resp.labels
    if labels != nil
      labels.each { |key, value|
        if key != nil and key == input_key and value == input_value
          _present = true
        end
      }
    else
      fail "labels are not present for google_compute_image"
    end
    if (!_present)
      fail "The expected labels Key:#{input_key}, Value:#{input_value} are not present for google compute image."
    end
    _present
  end

  def disk_size_gb
    @resp.disk_size_gb
  end

  def family
    @resp.family
  end

  def has_guest_os_features?(input_value)
    @os_feature = @resp.guest_os_features
    @guest_os_arr = Array.new
    if @os_feature != nil
      @os_feature.each { |os|
        @os_feature_config = {
          "type" => @os.type,
        }
        @guest_os_arr << @os_feature_config
      }
      if !JsonUtilities::compare_json(input_value, @guest_os_arr)
        fail "The Expected guest_os_features for google compute image is #{input_value} but the actual is #{@os_feature_config}"
      end
      true
    end
  end

  def licenses
    @resp.licenses
  end

  def has_raw_disk?(expected_raw_disk)
    @disk = @resp.raw_disk
    if @disk != nil
      @disk_data = {
        "container_type" => @disk.container_type,
        "sha1" => @disk.sha1_checksum,
        "source" => @disk.source,
      }
      if !JsonUtilities::compare_json(input_value, @disk_data)
        fail "The Expected raw_disk for google compute image is #{input_value} but the actual is #{@disk_data}"
      end
      true
    end
  end

  def source_snapshot
    get_resource_name(@resp.source_snapshot)
  end

  def source_disk
    get_resource_name(@resp.source_disk)
  end

  def source_image
    get_resource_name(@resp.source_image)
  end
end

def hcap_google_compute_image(project, image_name)
  GOOGLE_COMPUTE_IMAGE.new(project, image_name)
end
