  require_relative '../Util'
  include Util

  class GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER
    def initialize(project,zone,manager)
      @manager = manager
      begin
        puts "project : #{project}"
        puts "zone : #{zone}"
        puts "instance group manager: #{manager}"
        service = getClient('Compute')
        service.authorization = Google::Auth.get_application_default(['https://www.googleapis.com/auth/cloud-platform'])
        resource_name=get_resource_name(manager)
        @resp = service.get_instance_group_manager(project, zone, resource_name)
      rescue
      puts "The google_compute_instance_group_manager does not exist"
    end
    end

    def exists?
      if defined?(@resp) == nil || @resp.nil?
       fail "The google_compute_instance_group_manager : #{@manager} does not exist"
      else
      true
      end
    end

    def base_instance_name
      @resp.base_instance_name
    end
    def has_version? expected_version
      originalArr = Array.new
      if @resp.versions != nil
        @resp.versions.each {|ver |
            @target_size = {
              "fixed"=> ver.target_size.fixed,
              "percent"=> ver.target_size.percent
            }
            @vers = {
              "name"=> ver.name,
              "target_size" => @target_size,
              "instance_template" => ver.instance_template
            }
             originalArr << @vers
        }
          if !JsonUtilities::compare_json(expected_version, originalArr)
            fail "The Expected version for google_compute_instance_group_manager is #{expected_version} but the actual is #{originalArr}"
          end
          true
      end
    end
    def name
      @resp.name
    end
    def zone
      get_resource_name(@resp.zone)
    end
    def description
      @resp.description
    end
    def has_named_port? expected_named_ports
       originalArr = Array.new
          if @resp.named_ports != nil && expected_named_ports != nil
            @resp.named_ports.each { |por |
                  @port_name = {
                    "name" => por.name,
                    "port"=> por.port
                  }
                  originalArr << @port_name
            }          
          if !JsonUtilities::compare_json(originalArr,expected_named_ports)
            fail "The Expected named_ports for google compute instance_group_manager is #{expected_named_ports} but the actual is #{originalArr}"
          end
          true
          end
    end
    def target_size
      @resp.target_size
    end
    def target_pools
      @resp.target_pools
    end
    def has_auto_healing_policies? expected_healing_policy
      @resp.auto_healing_policies
       originalArr = Array.new
          if @resp.auto_healing_policies != nil && expected_healing_policy != nil
            @resp.auto_healing_policies.each { |pol |
                  @healing = {
                    "health_check" => pol.health_check,
                    "initial_delay_sec"=> pol.initial_delay_sec
                  }
                  originalArr << @healing
            }          
          if !JsonUtilities::compare_json(originalArr,expected_healing_policy)
            fail "The Expected healing_policies for google compute instance_group_manager is #{expected_healing_policy} but the actual is #{originalArr}"
          end
          true
          end
    end
    def has_stateful_disk? expected_disk
        @disk = @resp.stateful_policy.preserved_state
          if @disk != nil && expected_disk != nil
            @disk.disks.map{ |k,v|  
              @state_disk = {
                "device_name" => k,
                "delete_rule" => v.auto_delete
              }
            }
          if !JsonUtilities::compare_json(@state_disk, @expected_disk)
            fail "The Expected stateful_disk for google compute instance_group_manager is #{expected_disk} but the actual is #{@state_disk}"
          end
          true
          end
    end
    def has_update_policy? expected_policy
          @policy = @resp.update_policy
          if @policy != nil && expected_policy != nil
            @update_pol = {
              "minimal_action" => @policy.minimal_action,
              "type" => @policy.type,
              "max_surge_fixed" => @policy.max_surge.fixed,
              "max_surge_percent" => @policy.max_surge.percent,
              "max_unavailable_fixed" => @policy.max_unavailable.fixed,
              "max_unavailable_percent" => @policy.max_unavailable.percent
            }
          if !JsonUtilities::compare_json(@update_pol, expected_policy)
            fail "The Expected update_policy for google compute instance_group_manager is #{expected_policy} but the actual is #{@update_pol}"
          end
          true
          end
    end
end
  def hcap_google_compute_instance_group_manager(project,zone,manager)
      GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER.new(project,zone,manager)
  end