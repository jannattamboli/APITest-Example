  require_relative '../Util'
  include Util

  class GOOGLE_COMPUTE_INSTANCE_GROUP
    def initialize(project, zone, instance_group)
      @instance_group = instance_group
      begin  
        puts "project : #{project}"
        puts "zone : #{zone}"
        puts "instance group: #{instance_group}"
        service = getClient('Compute')
        service.authorization = Google::Auth.get_application_default(['https://www.googleapis.com/auth/cloud-platform'])
        resource_name=get_resource_name(instance_group)
        @resp = service.get_instance_group(project, zone,resource_name)
        @project = project
      rescue
      puts "The google_compute_instance_group does not exist"
    end
    end

    def exists?
      if defined?(@resp) == nil || @resp.nil?
       fail "The google_compute_instance_group : #{@instance_group} does not exist"
      else
      true
      end
    end

    def name
      @resp.name
    end
    def description
      @resp.description
    end
    def project
      if defined?(@resp) != nil || !@resp.nil?
        @project
      end
    end
    def zone
      get_resource_name(@resp.zone)
    end
    def network
      get_resource_name(@resp.network)
    end
    def named_port
      @resp
    end

    def has_named_port?expected_named_port
      @actuals=@resp.named_ports
      if @actuals != nil
        @actuals.each { | sub |
        if  sub.name == expected_named_port['name']
          @named_port = {
                "name" => sub.name,
                "port" => sub.port
            }
        
        end
        }
      if !JsonUtilities::compare_json(expected_named_port,@named_port)
        fail "The Expected name port for google compute instance group is #{expected_named_port} but the actual is #{@named_port}"
      end
      true
    end

    end 

end
  def hcap_google_compute_instance_group(project, zone, instance_group)
      GOOGLE_COMPUTE_INSTANCE_GROUP.new(project, zone, instance_group)
  end