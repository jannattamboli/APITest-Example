  require_relative '../Util'
  include Util
  include JsonUtilities

  class GOOGLE_COMPUTE_SUBNETWORK
    def initialize(project, region, subnetwork)
      @subnetwork=subnetwork 
      begin
        puts "project : #{project}"
        puts "region : #{region}"
        puts "subnetwork: #{subnetwork}"
        service = getClient('Compute')
        service.authorization = Google::Auth.get_application_default(['https://www.googleapis.com/auth/cloud-platform'])
        resource_name=get_resource_name(subnetwork)
        @response = service.get_subnetwork(project, region, resource_name)
        @log_config = @response.log_config
        @project = project 
      rescue
      puts "The google_compute_subnetwork does not exist"
    end
    end

    def exists?
      if defined?(@response) == nil || @response.nil?
       fail "The google_compute_subnetwork : #{@subnetwork} does not exist"
      else
      true
      end
    end

    def name
      @response.name
    end

    def description
      @response.description
    end

    def project
      if defined?(@response) != nil || !@response.nil?
        @project
      end
    end

    def purpose
      @response.purpose
    end
    def private_ip_google_access
      @response.private_ip_google_access
    end
    def ip_cidr_range
      @response.ip_cidr_range
    end

    def has_secondary_ip_range?expected_secondary_ip_range
      @actuals=@response.secondary_ip_ranges
      if @actuals != nil
        @actuals.each { | sub |
        if  sub.range_name == expected_secondary_ip_range['range_name']
        @secondary_ip_range = {
              "range_name" => sub.range_name,
              "ip_cidr_range" => sub.ip_cidr_range
          }
        
        end
        } 
        if !JsonUtilities::compare_json(expected_secondary_ip_range,@secondary_ip_range)
          fail "The Expected secondary ip range for google compute subnetwork is #{expected_config} but the actual is #{@secondary_ip_range}"
        end
        true
      end
    end

    def has_log_config? expected_config
      if @log_config != nil
          @log_conf = {
            "aggregation_interval" => @log_config.aggregation_interval,
            "flow_sampling" => @log_config.flow_sampling,
            "metadata" => @log_config.metadata
        }
        if !JsonUtilities::compare_json(expected_config,@log_conf)
          fail "The Expected log config for  google compute subnetwork is #{expected_config} but the actual is #{@log_conf}"
        end
      true
     end
    end


end
  def hcap_google_compute_subnetwork(project, region, subnetwork)
      GOOGLE_COMPUTE_SUBNETWORK.new(project, region, subnetwork)
  end
