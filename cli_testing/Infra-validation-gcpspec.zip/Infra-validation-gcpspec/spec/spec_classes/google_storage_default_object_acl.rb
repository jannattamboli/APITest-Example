  require_relative '../Util'
  include Util

  class GOOGLE_STORAGE_DEFAULT_OBJECT_ACL
    def initialize(project,bucket)
      @bucket=bucket
      begin  
        puts "project : #{project}"
        puts "bucket: #{bucket}" 
        service = getClient('Storage')
        resource_name=get_resource_name(bucket)
        @resp = service.bucket bucket
      rescue
      puts "The google_storage_default_object_acl does not exist"
    end
    end

    def exists?
      if defined?(@resp) == nil || @resp.nil?
       fail "The google_storage_default_object_acl for bucket : #{@bucket} does not exist"
      else
      true
      end
    end

    def name
      @resp.name
    end

    def has_role_entity?expected_role_entity
      array=Array.new
      if  defined?(@resp.acl.owners)  != nil || !@resp.acl.owners.nil?
        @resp.acl.owners.each{ | a |
             arr=a.split('-')
             resource_name= arr[0]
             if  resource_name.include? "project"
              s= "OWNER:"
              array << s.concat(a)
        end
        }
      end

      if  defined?(@resp.acl.writers)  != nil || !@resp.acl.writers.nil?
        @resp.acl.writers.each{ | a |
             arr=a.split('-')
             resource_name= arr[0]
             if  resource_name.include? "project"
              s= "WRITER:"
              array << s.concat(a)

        end
        }
      end

      if  defined?(@resp.acl.readers)  != nil || !@resp.acl.readers.nil?
        @resp.acl.readers.each{ | a |
             arr=a.split('-')
             resource_name= arr[0]
             if  resource_name.include? "project"
              s= "READER:"
              array << s.concat(a)

        end
        }
      end
      compare_arr(expected_role_entity,array)
    end
   
end
  def hcap_google_storage_default_object_acl(project,bucket)
      GOOGLE_STORAGE_DEFAULT_OBJECT_ACL.new(project,bucket)
  end