  require_relative '../Util'
  include Util

  class GOOGLE_COMPUTE_VPN_GATEWAY
    def initialize(project, region, target_vpn_gateway)
      @target_vpn_gateway=target_vpn_gateway  
      begin
        puts "project : #{project}"
        puts "region: #{region}"
        puts "target vpn gateway: #{target_vpn_gateway}"
        service = getClient('Compute')
        service.authorization = Google::Auth.get_application_default(['https://www.googleapis.com/auth/cloud-platform'])
        resource_name=get_resource_name(target_vpn_gateway)
        @response = service.get_target_vpn_gateway(project, region, resource_name)
        @project = project   
      rescue
      puts "The google_compute_vpn_gateway does not exist"
    end
    end

    def exists?
      if defined?(@response) == nil || @response.nil?
       fail "The google_compute_vpn_gateway : #{@target_vpn_gateway} does not exist"
      else
      true
      end
    end

    def name
      @response.name
    end
    def description
      @response.description
    end

    def project
      if defined?(@response) != nil || !@response.nil?
        @project
      end
    end
    def network
      get_resource_name(@response.network)
    end
end
  def hcap_google_compute_vpn_gateway(project, region, target_vpn_gateway)
      GOOGLE_COMPUTE_VPN_GATEWAY.new(project, region, target_vpn_gateway)
  end