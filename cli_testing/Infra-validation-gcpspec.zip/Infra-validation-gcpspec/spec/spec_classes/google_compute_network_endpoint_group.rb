  require_relative '../Util'
  include Util

  class GOOGLE_COMPUTE_NETWORK_ENDPOINT_GROUP
    def initialize(project,zone,endpoint)
      @endpoint = endpoint
      begin 
        puts "project : #{project}"
        puts "zone: #{zone}"
        puts "network endpoint group: #{endpoint}"
        service = getClient('Compute')
        service.authorization = Google::Auth.get_application_default(['https://www.googleapis.com/auth/cloud-platform'])
        resource_name=get_resource_name(endpoint)
        @resp = service.get_network_endpoint_group(project,zone,resource_name)
        @project = project     
      rescue
      puts "The google_compute_network_endpoint_group does not exist"
    end
    end

    def exists?
      if defined?(@resp) == nil || @resp.nil?
       fail "The google_compute_network_endpoint_group : #{@endpoint} does not exist"
      else
      true
      end
    end

    def name
      @resp.name
    end
    def description
      @resp.description
    end
    def zone
      get_resource_name(@resp.zone)
    end
    def project
      if defined?(@resp) != nil || !@resp.nil?
        @project
      end
    end
    def network
      get_resource_name(@resp.network)
    end
    def network_endpoint_type
      @resp.network_endpoint_type
    end
    def subnetwork
      get_resource_name(@resp.subnetwork)
    end
    def default_port
      @resp.default_port
    end
end
  def hcap_google_compute_network_endpoint_group(project,zone,endpoint)
      GOOGLE_COMPUTE_NETWORK_ENDPOINT_GROUP.new(project,zone,endpoint)
  end