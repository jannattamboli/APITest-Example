  require_relative '../Util'
  include Util

  class GOOGLE_COMPUTE_SNAPSHOT
    def initialize(project, snapshot) 
      @snapshot=snapshot
        begin 
          puts "project : #{project}"
          puts "snapshot : #{snapshot}"
          service = getClient('Compute')
          service.authorization = Google::Auth.get_application_default(['https://www.googleapis.com/auth/cloud-platform'])
          resource_name=get_resource_name(snapshot)
          @resp = service.get_snapshot(project, resource_name)
          @project = project 
      rescue
      puts "The google_compute_snapshot does not exist"
    end
    end

    def exists?
      if defined?(@resp) == nil || @resp.nil?
       fail "The google_compute_snapshot : #{@snapshot} does not exist"
      else
      true
      end
    end

    def name
      @resp.name
    end
    
    def description
      @resp.description
    end

    def project
      if defined?(@resp) != nil || !@resp.nil?
        @project
      end
    end

    def source_disk
      get_resource_name(@resp.source_disk)
    end

    def has_storage_locations?expected_storage_locations
      actual_array=Array.new
      @resp.storage_locations.each { |l|

      actual_array << l

    }
    compare_arr(expected_storage_locations,actual_array)
    end


    def has_labels? input_key, input_value
      _present = false
    labels = @resp.labels
    if labels != nil
      labels.each { |key, value|
        if key != nil and key == input_key and value == input_value
          _present = true
        end
      }
    else
      fail "labels are not present for google_compute_snapshot"
    end
    if (!_present)
      fail "The expected labels Key:#{input_key}, Value:#{input_value} is wrong or not present for google_compute_snapshot."
    end
    _present
    end

end
  def hcap_google_compute_snapshot(project, snapshot)
      GOOGLE_COMPUTE_SNAPSHOT.new(project, snapshot)
  end