  require_relative '../Util'
  include Util

  class GOOGLE_COMPUTE_ADDRESS
    def initialize(project,region,address)
      @address=address
      begin
        puts "project : #{project}"
        puts "region : #{region}"
        puts "Address: #{address}"
        service = getClient('Compute')
        service.authorization = Google::Auth.get_application_default(['https://www.googleapis.com/auth/cloud-platform'])
        resource_name=get_resource_name(address)
        @resp = service.get_address(project, region, resource_name)   
      rescue
      puts "The google_compute_address does not exist"
    end
    end

    def exists?
      if defined?(@resp) == nil || @resp.nil?
       fail "The google_compute_address : #{@address} does not exist"
      else
      true
      end
    end

    def name
      @resp.name
    end
    def description
      @resp.description
    end
    def has_labels? input_key, input_value
      _present = false
    labels = @resp.labels
    if labels != nil
      labels.each { |key, value|
        if key != nil and key == input_key and value == input_value
          _present = true
        end
      }
    else
      fail "labels are not present for google_compute_address"
    end
    if (!_present)
      fail "The expected labels Key:#{input_key}, Value:#{input_value} is wrong or not present for google_compute_address."
    end
    _present
    end
    def address
      @resp.address
    end
    def address_type
      @resp.address_type
    end
    def purpose
      @resp.purpose
    end
    def network_tier
      @resp.network_tier
    end
    def subnetwork
      @resp.subnetwork
    end
    def region
      get_resource_name(@resp.region)
    end
end
  def hcap_google_compute_address(project,region,address)
      GOOGLE_COMPUTE_ADDRESS.new(project,region,address)
  end