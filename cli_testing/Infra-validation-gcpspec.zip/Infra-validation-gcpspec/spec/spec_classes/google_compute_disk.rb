  require_relative '../Util'
  include Util

  class GOOGLE_COMPUTE_DISK
    def initialize(project,zone,disk)
      @disk = disk
      begin
        puts "project : #{project}"
        puts "zone : #{zone}"
        puts "disk: #{disk}"
        service = getClient('Compute')
        service.authorization = Google::Auth.get_application_default(['https://www.googleapis.com/auth/cloud-platform'])
        resource_name=get_resource_name(disk)
        @resp = service.get_disk(project, zone, resource_name)
        @project = project
      rescue
      puts "The google_compute_disk does not exist"
      end
    end

    def exists?
      if defined?(@resp) == nil || @resp.nil?
       fail "The google_compute_disk : #{@disk} does not exist"
      else
      true
      end
    end

    def name
      @resp.name
    end
    def description
      @resp.description
    end

    def project
      if defined?(@resp) != nil || !@resp.nil?
        @project
      end
    end

    def size
      @resp.size_gb
    end
    def physical_block_size_bytes
      @resp.physical_block_size_bytes
    end
    def type
      @type=get_resource_name(@resp.type)
    end
    def image
      image_name=get_resource_name(@resp.source_image)
    end
    def zone
      @zone=get_resource_name(@resp.zone)
    end
    def has_source_image_encryption_key? input_key, input_value
       _present = false
      response = @resp.source_image_encryption_key
      if response != nil
          if "sha256" == input_key and response.sha256 == input_value
            _present = true
          end
      else
        fail "Data are not present for google_compute_disk"
    end
    if (!_present)
      fail "The expected paarameter :#{input_key}, Value:#{input_value} are not present for google_compute_disk."
    end
    _present
    end
    def has_disk_encryption_key? input_key, input_value
       _present = false
      response = @resp.disk_encryption_key
      if response != nil
          if "sha256" == input_key and response.sha256 == input_value
            _present = true
          end
      else
        fail "Data are not present for google_compute_disk"
    end
    if (!_present)
      fail "The expected paarameter :#{input_key}, Value:#{input_value} are not present for google_compute_disk."
    end
    _present
    end

    def snapshot
      snapshot_name=get_resource_name(@resp.source_snapshot)
    end

    def has_source_snapshot_encryption_key? input_key, input_value
       _present = false
      response = @resp.source_snapshot_encryption_key
      if response != nil
          if "sha256" == input_key and response.sha256 == input_value
            _present = true
          end
      else
        fail "Data are not present for google_compute_disk"
    end
    if (!_present)
      fail "The expected paarameter :#{input_key}, Value:#{input_value} are not present for google_compute_disk."
    end
    _present
    end

    def has_label? input_key, input_value
    _present = false
    labels = @resp.labels
    if labels != nil
      labels.each {|key, value|
        if key != nil and key == input_key and value == input_value
          _present = true
        end
      }
    else
      fail "labels are not present for google_compute_disk"
    end
    if (!_present)
      fail "The expected labels Key:#{input_key}, Value:#{input_value} are not present for google_compute_disk."
    end
    _present
  end
  end
  def hcap_google_compute_disk(project,zone,disk)
      GOOGLE_COMPUTE_DISK.new(project,zone,disk)
  end