  require_relative '../Util'
  include Util

  class GOOGLE_COMPUTE_ROUTER
    def initialize(project, region, router)
      @router = router
      begin 
        puts "project : #{project}"
        puts "region : #{region}"
        puts "router: #{router}"
        service = getClient('Compute')
        service.authorization = Google::Auth.get_application_default(['https://www.googleapis.com/auth/cloud-platform'])
        resource_name=get_resource_name(router)
        @resp = service.get_router(project, region, resource_name)
        @project = project
      rescue
      puts "The google_compute_router does not exist"
    end
    end

    def exists?
      if defined?(@resp) == nil || @resp.nil?
       fail "The google_compute_router : #{@router} does not exist"
      else
      true
      end
    end

    def name
      @resp.name
    end
    def description
      @resp.description
    end

    def project
      if defined?(@resp) != nil || !@resp.nil?
        @project
      end
    end

    def region
      get_resource_name(@resp.region)
    end
    def network
      get_resource_name(@resp.network)
    end


    def has_bgp? input_key, input_value
      _present = false
      response = @resp.bgp
      if response != nil
          if "asn" == input_key and response.asn == input_value
            _present = true
          end
          if "advertise_mode" == input_key and response.advertise_mode  == input_value
            _present = true
          end
          if "advertised_groups" == input_key
            actual_array=Array.new
            response.advertised_groups.each { |l|
      
            actual_array << l
      
          }
          compare_arr(input_value,actual_array)
            _present = true
          end 
          if "advertised_ip_ranges" == input_key
            array=Array.new
            response.advertised_ip_ranges.each { |l|
            input_value.each { | value | 
            if value['range'] == l.range
              @ip_range = {
                "range" => l.range,
                "description" => l.description
              }
              array << @ip_range
            end
          }   
          }
          if !JsonUtilities::compare_json(input_value,array)
            fail "The Expected advertised ip range for google compute router is #{input_value} but the actual is #{array}"
          end
            _present = true
          end
      else
        fail "Data are not present for google_compute_router"
    end
    if (!_present)
      fail "The expected parameter :#{input_key}, Value:#{input_value} are not present for google_compute_router."
    end
    _present
    end

end
  def hcap_google_compute_router(project, region, router)
      GOOGLE_COMPUTE_ROUTER.new(project, region, router)
  end