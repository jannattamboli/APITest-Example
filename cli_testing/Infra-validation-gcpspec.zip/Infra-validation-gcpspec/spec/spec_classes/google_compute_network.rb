  require_relative '../Util'
  include Util

  class GOOGLE_COMPUTE_NETWORK
    def initialize(project, network)
      @network = network
      begin
        puts "project : #{project}"
        puts "network: #{network}"
        service = getClient('Compute')
        service.authorization = Google::Auth.get_application_default(['https://www.googleapis.com/auth/cloud-platform'])
        resource_name=get_resource_name(network)
        @response = service.get_network(project, resource_name)
        @project = project
      rescue
      puts "The google_compute_network does not exist"
    end
    end

    def exists?
      if defined?(@response) == nil || @response.nil?
       fail "The google_compute_network : #{ @network} does not exist"
      else
      true
      end
    end

    def name
      @response.name
    end

    def project
      if defined?(@response) != nil || !@response.nil?
        @project
      end
    end


    def auto_create_subnetworks
      @response.auto_create_subnetworks
    end
    def routing_mode 
      @response.routing_config.routing_mode
    end
    def mtu
      @response.mtu
    end

end
  def hcap_google_compute_network(project, network)
      GOOGLE_COMPUTE_NETWORK.new(project, network)
  end