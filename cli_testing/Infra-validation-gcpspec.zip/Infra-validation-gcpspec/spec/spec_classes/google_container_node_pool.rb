  require_relative '../Util'
  include Util

  class GOOGLE_CONTAINER_NODE_POOL
    def initialize(project, zone, cluster_id, node_pool_id)
      @node_pool_id=node_pool_id 
      begin 
        puts "project : #{project}"
        puts "zone: #{zone}"
        puts "cluster_id: #{cluster_id}"
        puts "node_pool_id: #{node_pool_id}"
        service = getClient('ContainerService')
        service.authorization = Google::Auth.get_application_default(['https://www.googleapis.com/auth/cloud-platform'])
        resource_name=get_resource_name(node_pool_id)
        cluster=get_resource_name(cluster_id)
        @resp = service.get_project_zone_cluster_node_pool(project,  zone, cluster, resource_name)
        @project = project   

      rescue
      puts "The google_container_node_pool does not exist"
    end
    end

    def exists?
      if defined?(@resp) == nil || @resp.nil?
       fail "The google_container_node_pool : #{@node_pool_id} does not exist"
      else
      true
      end
    end


    def name
      @resp.name
    end

    def project
      if defined?(@resp) != nil || !@resp.nil?
        @project
      end
    end
    def initial_node_count
      @resp.initial_node_count
    end

    def has_management?(expected_management)
      @management= @resp.management
      if @management != nil
        @mang = {
          "auto_upgrade" => @management.auto_upgrade,
          "auto_repair" => @management.auto_repair
        }
        if !JsonUtilities::compare_json(expected_management, @mang)
          fail "The Expected management for google container node pool is #{expected_management} but the actual is #{@mang}"
        end
        true
      end
    end

    def has_autoscaling?(expected_autoscaling)
      @autoscaling = @resp.autoscaling
      if @autoscaling != nil
        @policy = {
          "min_node_count" => @autoscaling.min_node_count,
          "max_node_count" => @autoscaling.max_node_count
        }
        if !JsonUtilities::compare_json(expected_autoscaling, @policy)
          fail "The Expected autoscaling  for google container node pool is #{expected_autoscaling} but the actual is #{@policy}"
        end
        true
      end
    end

    def has_upgrade_settings?(expected_upgrade_settings)
      @upgrade_settings = @resp.upgrade_settings
      if @upgrade_settings != nil
        @setting = {
          "max_surge" => @upgrade_settings.max_surge,
          "max_unavailable" => @upgrade_settings.max_unavailable
        }
        if !JsonUtilities::compare_json(expected_upgrade_settings, @setting)
          fail "The Expected upgrade settings  for google container node pool is #{expected_upgrade_settings} but the actual is #{@setting}"
        end
        true
      end
    end


    def max_pods_per_node
      @resp.max_pods_constraint.max_pods_per_node
    end

    def has_node_locations?expected_node_locations
      actual_array=Array.new
      @resp.locations.each { |l|

      actual_array << l

    }
    compare_arr(expected_node_locations,actual_array)
    end


    def has_node_config? input_key, input_value
      _present = false
      response = @resp.config
      if response != nil
          if "machine_type" == input_key and response.machine_type == input_value
            _present = true
          end
          if "disk_size_gb" == input_key and response.disk_size_gb  == input_value
            _present = true
          end
          if "image_type" == input_key and response.image_type == input_value
            _present = true
          end
          if "service_account" == input_key and response.service_account  == input_value
            _present = true
          end

          if "disk_type" == input_key and response.disk_type  == input_value
            _present = true
          end

          if "metadata" == input_key and response.metadata['disable-legacy-endpoints'] == input_value['disable-legacy-endpoints'].to_s
            _present = true
          end

          if "shielded_instance_config" == input_key and response.shielded_instance_config.enable_integrity_monitoring  == input_value['enable_integrity_monitoring']
            _present = true
          end

          if "oauth_scopes" == input_key
            actual_array=Array.new
            response.oauth_scopes.each { |l|
      
            actual_array << l
      
          }
          compare_arr(input_value,actual_array)
            _present = true
          end
      else
        fail "Data are not present for google_container_node_pool"
    end
    if (!_present)
      fail "The expected parameter :#{input_key}, Value:#{input_value} are not present for google container node pool."
    end
    _present
    end


    def version
      @resp.version
    end
end
  def hcap_google_container_node_pool(project, zone, cluster_id, node_pool_id)
      GOOGLE_CONTAINER_NODE_POOL.new(project, zone, cluster_id, node_pool_id)
  end