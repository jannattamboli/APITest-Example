require_relative "../Util"
include Util

class GOOGLE_COMPUTE_ROUTER_NAT
  def initialize(project, region, router, nat_name)
    @nat_name = nat_name
    begin
      puts "project : #{project}"
      puts "region : #{region}"
      puts "router: #{router}"
      service = getClient("Compute")
      service.authorization = Google::Auth.get_application_default(["https://www.googleapis.com/auth/cloud-platform"])
      resource_name = get_resource_name(router)
      @response = service.get_router(project, region, resource_name)
      # @resp = service.get_router_nat_mapping_info(project, region, router)
      @response.nats.each { |n|
        if n.name == nat_name
          @resp = n
        end
      }
    rescue Exception => e
      puts e
      puts "The google_compute_router_nat does not exist"
    end
  end

  def exists?
    if defined?(@resp) == nil || @resp.nil?
      fail "The google_compute_router_nat : #{@nat_name} does not exist"
    else
      true
    end
  end

  def name
    @resp.name
  end

  def nat_ip_allocate_option
    @resp.nat_ip_allocate_option
  end

  def source_subnetwork_ip_ranges_to_nat
    @resp.source_subnetwork_ip_ranges_to_nat
  end

  def nat_ips
    @natIp = Array.new
    @resp.nat_ips.each { |ip|
      @natIp << get_resource_name(ip)
    }
    return @natIp
  end

  def drain_nat_ips
    @resp.drain_nat_ips
  end

  # def has_subnetwork?expected_subnetwork
  #   @resp.subnetworks.each {|sub_net|
  #     if sub_net != nil && sub_net.name == expected_subnetwork.name
  #       @subnetwork = {
  #         "name" => @subnetwork_resp.name,
  #         "source_ip_ranges_to_nat" => @subnetwork_resp.source_ip_ranges_to_nat,
  #         "secondary_ip_range_names" => @subnetwork_resp.secondary_ip_range_names
  #       }
  #       if !JsonUtilities::compare_json(expected_subnetwork,@subnetwork)
  #         fail "The Expected subnetwork for google compute router nat is #{expected_subnetwork} but the actual is #{@subnetwork}"
  #       end
  #       true
  #     end
  #   }
  #   true
  # end
  def min_ports_per_vm
    @resp.min_ports_per_vm
  end

  def udp_idle_timeout_sec
    @resp.udp_idle_timeout_sec
  end

  def icmp_idle_timeout_sec
    @resp.icmp_idle_timeout_sec
  end

  def tcp_established_idle_timeout_sec
    @resp.tcp_established_idle_timeout_sec
  end

  def tcp_transitory_idle_timeout_sec
    @resp.tcp_transitory_idle_timeout_sec
  end

  def has_log_config?(expected_logconfig)
    @logconfig_resp = @resp.log_config
    if @logconfig_resp != nil
      @logconfig = {
        "enable" => @logconfig_resp.enable,
        "filter" => @logconfig_resp.filter,
      }
      if !JsonUtilities::compare_json(expected_logconfig, @logconfig)
        fail "The Expected log config for google compute router nat is #{expected_logconfig} but the actual is #{@logconfig}"
      end
      true
    end
  end
end

def hcap_google_compute_router_nat(project, region, router, nat_name)
  GOOGLE_COMPUTE_ROUTER_NAT.new(project, region, router, nat_name)
end
