  require_relative '../Util'
  include Util

  class GOOGLE_COMPUTE_TARGET_INSTANCE
    def initialize(project, zone, target_instance)
      @target_instance=target_instance 
      begin 
        puts "project : #{project}"
        puts "zone: #{zone}"
        puts "target instance: #{target_instance}"
        service = getClient('Compute')
        service.authorization = Google::Auth.get_application_default(['https://www.googleapis.com/auth/cloud-platform'])
        resource_name=get_resource_name(target_instance)
        @response = service.get_target_instance(project, zone, resource_name)
        @project = project       
      rescue
      puts "The google_compute_target_instance does not exist"
    end
    end

    def exists?
      if defined?(@response) == nil || @response.nil?
       fail "The google_compute_target_instance : #{@target_instance} does not exist"
      else
      true
      end
    end

    def name
      @response.name
    end
    def description
      @response.description
    end

    def project
      if defined?(@response) != nil || !@response.nil?
        @project
      end
    end
    def instance
      get_resource_name(@response.instance)
    end
    def nat_policy
      @response.nat_policy
    end
end
  def hcap_google_compute_target_instance(project, zone, target_instance)
      GOOGLE_COMPUTE_TARGET_INSTANCE.new(project, zone, target_instance)
  end