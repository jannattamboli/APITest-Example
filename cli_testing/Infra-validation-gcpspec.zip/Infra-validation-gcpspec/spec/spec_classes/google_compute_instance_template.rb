require_relative "../Util"
require "spec_helper"
include Util

class GOOGLE_COMPUTE_INSTANCE_TEMPLATE
  def initialize(project, template)
    @template = template
    begin
      puts "project : #{project}"
      puts "instance_template: #{template}"
      service = getClient("Compute")
      service.authorization = Google::Auth.get_application_default(["https://www.googleapis.com/auth/cloud-platform"])
      resource_name = get_resource_name(template)
      @resp = service.get_instance_template(project, resource_name)
    rescue
      puts "The google_compute_instance_template does not exist"
    end
  end

  def exists?
    if defined?(@resp) == nil || @resp.nil?
      fail "The google_compute_instance_template : #{@template} does not exist"
    else
      true
    end
  end

  def name
    @resp.name
  end

  def can_ip_forward
    @resp.properties.can_ip_forward
  end

  def instance_description
    @resp.properties.description
  end

  def description
    @resp.description
  end

  def has_disk?(input_key, input_value, disk_name)
    _present = false
    @resp.properties.disks.each { |response|
      if response.device_name == disk_name
        if "auto_delete" == input_key and response.auto_delete == input_value
          _present = true
        end
        if "boot" == input_key and response.boot == input_value
          _present = true
        end
        if "device_name" == input_key and response.device_name == input_value
          _present = true
        end
        if "disk_size_gb" == input_key and response.initialize_params.disk_size_gb == input_value
          _present = true
        end
        if "disk_type" == input_key and response.initialize_params.disk_type == input_value
          _present = true
        end
        if "source_image" == input_key and get_resource_name(response.initialize_params.source_image) == input_value
          _present = true
        end
        if "interface" == input_key and response.interface == input_value
          _present = true
        end
        if "type" == input_key and response.type == input_value
          _present = true
        end
        if "source" == input_key and response.source == input_value
          _present = true
        end
        if "mode" == input_key and response.mode == input_value
          _present = true
        end
      end
    }
    if (!_present)
      fail "The expected paarameter: #{input_key}, Value: #{input_value} is wrong or not present for google_compute_instance_template."
    end
    _present
  end

  def has_metadata?(input_key, input_value)
    _present = false
    response = @resp.properties.metadata.items
    if response != nil
      response.each { |response|
        if response != nil and response.key == input_key and response.value == input_value
          _present = true
        end
      }
    else
      fail "Metadata are not present for google_compute_disk"
    end
    if (!_present)
      fail "The expected Key:#{input_key}, Value:#{input_value} is wrong or not present for google_compute_disk."
    end
    _present
  end

  def has_network_interface?(input_key, input_value, net_name)
    _present = false
    @resp.properties.network_interfaces.each { |response|
      if get_resource_name(response.network) == net_name
        if "network" == input_key and get_resource_name(response.network) == input_value
          _present = true
        end
        if "network_ip" == input_key and response.network_ip == input_value
          _present = true
        end
        if "subnetwork" == input_key and get_resource_name(response.subnetwork) == input_value
          _present = true
        end
      end
    }
    if (!_present)
      fail "The expected paarameter :#{input_key}, Value:#{input_value} is wrong or not present for google_compute_instance_template."
    end
    _present
  end

  def machine_type
    @resp.properties.machine_type
  end

  def has_scheduling?(input_key, input_value)
    _present = false
    response = @resp.properties.scheduling
    if response != nil
      if "automatic_restart" == input_key and response.automatic_restart == input_value
        _present = true
      end
      if "on_host_maintenance" == input_key and response.on_host_maintenance == input_value
        _present = true
      end
      if "preemptible" == input_key and response.preemptible == input_value
        _present = true
      end
    else
      fail "scheduling is not present for google_compute_instance_template"
    end
    if (!_present)
      fail "The expected paarameter: #{input_key}, Value: #{input_value} is wrong or not present for google_compute_instance_template."
    end
    _present
  end

  def has_service_account?(input_key, input_value)
    _present = false
    response = @resp.properties.service_accounts[0]
    if response != nil
      if "email" == input_key and response.email == input_value
        _present = true
      end
      if "scopes" == input_key and response.scopes == input_value
        _present = true
      end
    else
      fail "service_account is not present for google_compute_instance_template"
    end
    if (!_present)
      fail "The expected paarameter: #{input_key}, Value: #{input_value} is wrong or not present for google_compute_instance_template."
    end
    _present
  end

  def tags
    @resp.properties.tags.items
  end

  def min_cpu_platform
    @resp.properties.min_cpu_platform
  end

  def has_shielded_instance_config?(input_key, input_value)
    _present = false
    response = @resp.properties.shielded_instance_config
    if response != nil
      if "enable_secure_boot" == input_key and response.enable_secure_boot == input_value
        _present = true
      end
      if "enable_vtpm" == input_key and response.enable_vtpm == input_value
        _present = true
      end
      if "enable_integrity_monitoring" == input_key and response.enable_integrity_monitoring == input_value
        _present = true
      end
    else
      fail "shielded_instance_config data is not present for google_compute_instance_template"
    end
    if (!_present)
      fail "The expected paarameter :#{input_key}, Value:#{input_value} is wrong or not present for google_compute_instance_template."
    end
    _present
  end

  def has_label?(input_key, input_value)
    _present = false
    labels = @resp.properties.labels
    if labels != nil
      labels.each { |key, value|
        if key != nil and key == input_key and value == input_value
          _present = true
        end
      }
    else
      fail "labels are not present for google_compute_disk"
    end
    if (!_present)
      fail "The expected labels Key:#{input_key}, Value:#{input_value} is wrong or not present for google_compute_disk."
    end
    _present
  end
end

def hcap_google_compute_instance_template(project, template)
  GOOGLE_COMPUTE_INSTANCE_TEMPLATE.new(project, template)
end
