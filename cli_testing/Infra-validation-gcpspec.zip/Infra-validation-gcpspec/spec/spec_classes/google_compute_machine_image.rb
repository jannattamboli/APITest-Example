  require_relative '../Util'
  include Util

  class GOOGLE_COMPUTE_MACHINE_IMAGE
    def initialize(project,image)
      @image = image  
      begin
        puts "project : #{project}"
        puts "machine image: #{image}"
        service = getClient('Compute-Beta')
        service.authorization = Google::Auth.get_application_default(['https://www.googleapis.com/auth/cloud-platform'])
        resource_name=get_resource_name(image)
        @resp = service.get_machine_image(project, resource_name)
        @project = project
      rescue
      puts "The google_compute_machine_image does not exist"
    end
    end

    def exists?
      if defined?(@resp) == nil || @resp.nil?
       fail "The google_compute_machine_image : #{@image} does not exist"
      else
      true
      end
    end

    def name
      @resp.name
    end
    def source_instance
      source_instance_name=get_resource_name(@resp.source_instance)
    end
    def description
      @resp.description
    end
    def guest_flush
      @resp.guest_flush
    end

    def project
      if defined?(@resp) != nil || !@resp.nil?
        @project
      end
    end

    def has_machine_image_encryption_key? input_key, input_value
      _present = false
      response = @resp.machine_image_encryption_key
      if response != nil
          if "sha256" == input_key and response.sha256 == input_value
            _present = true
          end
          if "kms_key_name" == input_key and response.kms_key_name  == input_value
            _present = true
          end
          if "kms_key_service_account" == input_key and response.kms_key_service_account == input_value
            _present = true
          end
      else
        fail "Data are not present for google_compute_machine_image"
    end
    if (!_present)
      fail "The expected paarameter :#{input_key}, Value:#{input_value} are not present for google_compute_machine_image."
    end
    _present
    end
end
  def hcap_google_compute_machine_image(project,image)
      GOOGLE_COMPUTE_MACHINE_IMAGE.new(project,image)
  end