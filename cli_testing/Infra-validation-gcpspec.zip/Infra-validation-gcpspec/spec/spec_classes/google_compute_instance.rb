  require_relative '../Util'
  include Util
  include JsonUtilities

  class GOOGLE_COMPUTE_INSTANCE
    def initialize(project,zone,instance)
      @instance = instance
      begin
        puts "project : #{project}"
        puts "zone : #{zone}"
        puts "instance: #{instance}"
        service = getClient('Compute')
        service.authorization = Google::Auth.get_application_default(['https://www.googleapis.com/auth/cloud-platform'])
        resource_name=get_resource_name(instance)
        @resp = service.get_instance(project, zone, resource_name) 
        @project = project
      rescue
      puts "The google_compute_instance does not exist"
    end
    end

    def exists?
      if defined?(@resp) == nil || @resp.nil?
       fail "The google_compute_instance : #{@instance} does not exist"
      else
      true
      end
    end

    def name
      @resp.name
    end

    def project
      if defined?(@resp) != nil || !@resp.nil?
        @project
      end
    end

    def machine_type
      get_resource_name(@resp.machine_type)
    end
    def desired_status
      @resp.status
    end
    def deletion_protection
      @resp.deletion_protection
    end
    def can_ip_forward
      @resp.can_ip_forward
    end
    def enable_display
      @resp.display_device.enable_display
    end

    def has_boot_disk? expected_boot_disk
      @disk=@resp.disks
      if @disk != nil 
        @disk.each { | sub |
        if  sub.device_name == expected_boot_disk['device_name']
          @scratch_disk = {
            "interface" => sub.interface,
          }
          @size = {
            "size" => sub.disk_size_gb
          }
          @boot_disk = {
            "auto_delete" => sub.auto_delete,
            "device_name" => sub.device_name,
            "mode" => sub.mode,
            "source" => get_resource_name(sub.source),
            "scratch_disk" => @scratch_disk,
            "initialize_params" => @size 
        } 
        end
        }  
        if !JsonUtilities::compare_json(expected_boot_disk,@boot_disk)
          fail "The Expected boot disk for google compute instance is #{expected_boot_disk} but the actual is #{@boot_disk}"
        end
      true
     end
    end

    def has_labels? input_key, input_value
      _present = false
      labels = @resp.labels
      if labels != nil
        labels.each {|key, value|
          if key != nil and key == input_key and value == input_value
            _present = true
          end
        }
      else
        fail "labels are not present for google_compute_instance"
      end
      if (!_present)
        fail "The expected labels Key:#{input_key}, Value:#{input_value} are not present for google compute instance."
      end
      _present
    end


    def has_network_interface?expected_network_interface
      @actuals=@resp.network_interfaces
      @config = Array.new
      if @actuals != nil
        @actuals.each { | sub |

                sub.access_configs.each { | s |
                @access_block = {
                  "nat_ip" => s.nat_ip,
                  "network_tier" => s.network_tier
                }
                @config << @access_block
              }

        @network_interface = {
              "network" => get_resource_name(sub.network),
              "network_ip" => sub.network_ip,
              "subnetwork" => get_resource_name(sub.subnetwork),
              "access_configs" => @config
          }
        } 
        if !JsonUtilities::compare_json(expected_network_interface,@network_interface)
          fail "The Expected secondary ip range for google compute subnetwork is #{expected_network_interface} but the actual is #{@network_interface}"
        end
        true
      end
    end
    

    def has_shielded_instance_config? expected_shielded_instance_config
      @shielded_instance = @resp.shielded_instance_config
      if @shielded_instance != nil
          @shielded_instance_config = {
            "enable_integrity_monitoring" => @shielded_instance.enable_integrity_monitoring,
            "enable_secure_boot" => @shielded_instance.enable_secure_boot,
            "enable_vtpm" => @shielded_instance.enable_vtpm
        }
        if !JsonUtilities::compare_json(expected_shielded_instance_config,@shielded_instance_config)
          fail "The Expected shielded instance config for google compute instance is #{expected_shielded_instance_config} but the actual is #{@shielded_instance_config}"
        end
      true
     end
    end

    def has_scheduling? expected_scheduling
      @scheduling_resp = @resp.scheduling
      if @scheduling_resp != nil
          @scheduling = {
            "automatic_restart" => @scheduling_resp.automatic_restart,
            "on_host_maintenance" => @scheduling_resp.on_host_maintenance,
            "preemptible" => @scheduling_resp.preemptible
        }
        if !JsonUtilities::compare_json(expected_scheduling,@scheduling)
          fail "The Expected scheduling for google compute instance is #{expected_scheduling} but the actual is #{@scheduling}"
        end
      true
     end
    end


    def has_service_account? expected_service_account
      @service_account_resp = @resp.service_accounts
      if @service_account_resp != nil
            @scope = Array.new
            @service_account_resp[0].scopes.each { | sub |
              @scope  << sub
             }
          @service_account = {
            "email" => @service_account_resp[0].email,
            "scopes" => @scope
        }
        if @service_account != expected_service_account
          fail "The Expected service account for google compute instance is #{expected_service_account} but the actual is #{@service_account}"
        end
      true
     end
    end

    def has_tags?expected_tags
      @tags=@resp.tags
      _present=false
      if @tags != nil
        @tags.items.each { | sub | 
          if sub != nil and sub == expected_tags
            _present=true	
          end
        }
        if(!_present)
          puts "The expected tags  is  not present for google compute instance"
        end
      else
        puts " Actual tags are not present for google compute instance"
      end
      _present
    end


end
  def hcap_google_compute_instance(project,zone,instance)
      GOOGLE_COMPUTE_INSTANCE.new(project,zone,instance)
  end