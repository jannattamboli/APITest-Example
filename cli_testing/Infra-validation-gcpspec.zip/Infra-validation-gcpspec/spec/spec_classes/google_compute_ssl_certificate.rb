  require_relative '../Util'
  include Util

  class GOOGLE_COMPUTE_SSL_CERTIFICATE
    def initialize(project,name)
      @name=name
      begin
        puts "project : #{project}"
        puts "ssl_certificate_name: #{name}"
        service = getClient('Compute')
        service.authorization = Google::Auth.get_application_default(['https://www.googleapis.com/auth/cloud-platform'])
        resource_name=get_resource_name(name)
        @resp = service.get_ssl_certificate(project, resource_name)
      rescue
      puts "The google_compute_ssl_certificate does not exist"
    end
    end

    def exists?
      if defined?(@resp) == nil || @resp.nil?
       fail "The google_compute_ssl_certificate : #{@name} does not exist"
      else
      true
      end
    end

    def name
      @resp.name
    end
    def description
      @resp.description
    end
    def certificate
      @resp.certificate
    end
end
  def hcap_google_compute_ssl_certificate(project,name)
      GOOGLE_COMPUTE_SSL_CERTIFICATE.new(project,name)
  end