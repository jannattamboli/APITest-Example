  require_relative '../Util'
  include Util

  class GOOGLE_COMPUTE_AUTOSCALER
    def initialize(project,zone,autoScaler)
      @autoScaler = autoScaler
      begin
        puts "project : #{project}"
        puts "zone : #{zone}"
        puts "autoScaler: #{autoScaler}"
        service = getClient('Compute')
        service.authorization = Google::Auth.get_application_default(['https://www.googleapis.com/auth/cloud-platform'])
        resource_name=get_resource_name(autoScaler)
        @resp = service.get_autoscaler(project, zone, resource_name) 
      rescue
      puts "The google_compute_autoscaler does not exist"
    end
    end

    def exists?
      if defined?(@resp) == nil || @resp.nil?
       fail "The google_compute_autoscaler : #{@autoScaler} does not exist"
      else
      true
      end
    end

    def name
      @resp.name
    end
    def target
      @resp.target
    end
    def has_autoscaling_policy? input_key, input_value
      
        @policy = @resp.autoscaling_policy
      if @policy != nil
        if "cooldown_period" == input_key and @policy.cool_down_period_sec == input_value
            return true
        elsif "max_replicas" == input_key and @policy.max_num_replicas == input_value
            return true
        elsif "min_replicas" == input_key and @policy.min_num_replicas == input_value
            return true
        elsif "mode" == input_key and @policy.mode == input_value
            return true
        elsif "cpu_utilization" == input_key and @policy.cpu_utilization.utilization_target == input_value["target"]
          return true
        elsif "load_balancing_utilization" == input_key and @policy.load_balancing_utilization.utilization_target == input_value["target"]
          return true
        elsif "scale_in_control" == input_key
          if @policy.scale_in_control != nil
           @max_scaled_rep = {
            "fixed"=> @policy.scale_in_control.max_scaled_in_replicas.fixed,
            "percent"=> @policy.scale_in_control.max_scaled_in_replicas.percent
           }
            @scale_in_control = {
              "max_scaled_in_replicas" => @max_scaled_rep,
              "time_window_sec" => @policy.scale_in_control.time_window_sec
            }
          if !JsonUtilities::compare_json(input_value, @scale_in_control)
            fail "The Expected autoscaling_policy scale_in_control for google compute autoscaling_policy is #{input_value} but the actual is #{@scale_in_control}"
          end
          true
          end
        elsif "metric" == input_key
          originalArr = Array.new
          if @policy.custom_metric_utilizations != nil && input_value != nil
            @policy.custom_metric_utilizations.each { |met |
              input_value.each {|inp|
                if met.metric == inp["name"]
                  @metric = {
                    "name" => met.metric,
                    "type"=> met.utilization_target_type,
                    "target" => met.utilization_target,
                  }
                  originalArr << @metric
                end
              }
          }          
          if !JsonUtilities::compare_json(originalArr,input_value)
            fail "The Expected autoscaling_policy metric for google compute autoscaling_policy is #{input_value} but the actual is #{originalArr}"
          end
          true
          end
        else
          fail "Attribute #{input_key} not present for autoscaling policy"
        end
      end
    end
    def description
      @resp.description
    end
    def zone
      get_resource_name(@resp.zone)
    end
end
  def hcap_google_compute_autoscaler(project,zone,autoScaler)
      GOOGLE_COMPUTE_AUTOSCALER.new(project,zone,autoScaler)
  end