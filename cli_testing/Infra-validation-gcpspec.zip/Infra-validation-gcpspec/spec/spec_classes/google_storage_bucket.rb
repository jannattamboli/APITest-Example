  require_relative '../Util'
  include Util
  include JsonUtilities

  class GOOGLE_STORAGE_BUCKET
    def initialize(project,bucket)
      @bucket=bucket
      begin 
        puts "project : #{project}"
        puts "bucket: #{bucket}" 
        service = getClient('Storage')
        resource_name=get_resource_name(bucket)
        @resp = service.bucket bucket
        @project=project
      rescue
      puts "The google_storage_bucket does not exist"
    end
    end

    def exists?
      if defined?(@resp) == nil || @resp.nil?
       fail "The google_storage_bucket : #{@bucket} does not exist"
      else
      true
      end
    end

    def name
      @resp.name
    end
    def location
      @resp.location
    end
    def project
      if defined?(@resp) != nil || !@resp.nil?
        @project
      end
    end
    def storage_class
      @resp.storage_class
    end
    def has_labels? input_key, input_value
      _present = false
    labels = @resp.labels
    if labels != nil
      labels.each { |key, value|
        if key != nil and key == input_key and value == input_value
          _present = true
        end
      }
    else
      fail "labels are not present for google_storage_bucket"
    end
    if (!_present)
      fail "The expected labels Key:#{input_key}, Value:#{input_value} is wrong or not present for google_storage_bucket."
    end
    _present
    end

    def bucket_policy_only
      @resp.gapi.iam_configuration.bucket_policy_only.enabled
    end

    def uniform_bucket_level_access
      @resp.gapi.iam_configuration.uniform_bucket_level_access.enabled
    end


    def has_website?expected_website
      @website = @resp.gapi.website
      if @website != nil 
          @website_rep = {
            "main_page_suffix" => @website.main_page_suffix,
            "not_found_page" => @website.not_found_page
          }
          if !JsonUtilities::compare_json(expected_website,@website_rep)
            fail "The Expected website for google storage bucket is #{expected_website} but the actual is #{@website_rep}"
          end
        true
      end
    end

    def has_logging?expected_logging
      @logging = @resp.gapi.logging
      if @logging != nil 
          @logging_rep = {
            "log_bucket" => @logging.log_bucket,
            "log_object_prefix" => @logging.log_object_prefix
          }
          if !JsonUtilities::compare_json(expected_logging,@logging_rep)
            fail "The Expected logging for google storage bucket is #{expected_logging} but the actual is #{@logging_rep}"
          end
        true
      end
    end



    def has_cors?(input_key, input_value,cors)
      _present = false
      response_con = @resp.gapi.cors_configurations
      if response_con != nil
        response_con.each{ | response |
        if cors['max_age_seconds'] == response.max_age_seconds
            if "max_age_seconds" == input_key and response.max_age_seconds == input_value
              _present = true
            end
            if "method" == input_key 
              array=Array.new
              array << response.http_method
              compare_arr(input_value,array)
              _present = true
            end
            if "origin" == input_key 
              array=Array.new
              array << response.origin
              compare_arr(input_value,array)
              _present = true
            end
            if "response_header" == input_key 
              array=Array.new
              array << response.response_header
              compare_arr(input_value,array)
              _present = true
            end
        end
      }
      else
        fail "cors data is not present for google_storage_bucket"
      end
      if (!_present)
        fail "The expected core parameter :#{input_key}, Value:#{input_value} is wrong or not present for google_storage_bucket."
      end
      _present
    end
    

    def has_versioning?expected_versioning
      @versioning = @resp.gapi.versioning
      if @versioning != nil 
          @versioning_resp = {
            "enabled" => @versioning.enabled
          }
          if !JsonUtilities::compare_json(expected_versioning,@versioning_resp)
            fail "The Expected versioning for google storage bucket is #{expected_versioning} but the actual is #{@versioning_resp}"
          end
        true
      end
    end


    def has_retention_policy?expected_retention_policy
      retention_policy = @resp.gapi.retention_policy
      if retention_policy != nil 
          @retention_policy_resp = {
            "retention_period" => retention_policy.retention_period
          }
          if !JsonUtilities::compare_json(expected_retention_policy,@retention_policy_resp)
            fail "The Expected retention policy for google storage bucket is #{expected_retention_policy} but the actual is #{@retention_policy_resp}"
          end
        true
      end
    end

    def has_lifecycle_rule?(input_key, input_value,lifecycle)
      response= @resp.gapi.lifecycle.rule 
      if response != nil
          response.each{ | ac |
            if(ac.action.type == lifecycle['action']['type'])
              if  "action" == input_key 
                @action = {
                  "storage_class" => ac.action.storage_class,
                  "type" => ac.action.type
                }
                if !JsonUtilities::compare_json(input_value,@action)
                  fail "The Expected life cycle rule action for google storage bucket is #{input_value} but the actual is #{@action}"
                end
                 true
              end
              if  "condition" == input_key 
                @condition = {
                  "age" => ac.condition.age,
                  "created_before" => ac.condition.created_before.to_s,
                  "num_newer_versions" => ac.condition.num_newer_versions,
                  "matches_storage_class" => ac.condition.matches_storage_class
                }
                if input_value != @condition
                  fail "The Expected life cycle rule condition for google storage bucket is #{input_value} but the actual is #{@condition}"
                end
              end
            end
          }

      end
    end
end
  def hcap_google_storage_bucket(project,bucket)
      GOOGLE_STORAGE_BUCKET.new(project,bucket)
  end