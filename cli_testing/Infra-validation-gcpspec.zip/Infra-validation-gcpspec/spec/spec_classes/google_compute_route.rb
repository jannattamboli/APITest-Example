  require_relative '../Util'
  include Util

  class GOOGLE_COMPUTE_ROUTE
    def initialize(project,route)
      @route = route
      begin
        puts "project : #{project}"
        puts "route: #{route}"
        service = getClient('Compute')
        service.authorization = Google::Auth.get_application_default(['https://www.googleapis.com/auth/cloud-platform'])
        resource_name=get_resource_name(route)
        @resp = service.get_route(project, resource_name)

      rescue
      puts "The google_compute_route does not exist"
    end
    end

    def exists?
      if defined?(@resp) == nil || @resp.nil?
       fail "The google_compute_route : #{ @route} does not exist"
      else
      true
      end
    end

    def name
      @resp.name
    end
    def dest_range
      @resp.dest_range
    end
    def network
      @resp.network
    end
    def description
      @resp.description
    end
    def priority
      @resp.priority
    end
    def next_hop_gateway
      @resp.next_hop_gateway
    end
    def next_hop_instance
      @resp.next_hop_instance
    end
    def next_hop_ip
      @resp.next_hop_ip
    end
    def next_hop_vpn_tunnel
      @resp.next_hop_vpn_tunnel
    end
    def next_hop_ilb
      @resp.next_hop_ilb
    end
    def has_tags?expected_tags
      @tags=@resp.tags
      _present=false
      if @tags != nil
        @tags.items.each { | sub | 
          if sub != nil and sub == expected_tags
            _present=true 
          end
        }
        if(!_present)
          puts "The expected tags  is  not present for google compute route"
        end
      else
        puts " Actual tags are not present for google compute route"
      end
      _present
    end
  end
  def hcap_google_compute_route(project,route)
      GOOGLE_COMPUTE_ROUTE.new(project,route)
  end