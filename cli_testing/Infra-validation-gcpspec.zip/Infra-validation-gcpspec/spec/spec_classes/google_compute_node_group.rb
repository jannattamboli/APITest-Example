  require_relative '../Util'
  include Util

  class GOOGLE_COMPUTE_NODE_GROUP
    def initialize(project,zone,node_group)
      @node_group = node_group    
      begin 
        puts "project : #{project}"
        puts "zone: #{zone}"
        puts "network node group: #{node_group}"
        service = getClient('Compute')
        service.authorization = Google::Auth.get_application_default(['https://www.googleapis.com/auth/cloud-platform'])
        resource_name=get_resource_name(node_group)
        @resp = service.get_node_group(project,zone,resource_name)
        @project = project  
      rescue
      puts "The google_compute_node_group does not exist"
    end
    end

    def exists?
      if defined?(@resp) == nil || @resp.nil?
       fail "The google_compute_node_group : #{@node_group} does not exist"
      else
      true
      end
    end

    def name
      @resp.name
    end
    def description
      @resp.description
    end
    def zone
      get_resource_name(@resp.zone)
    end
    def project
      if defined?(@resp) != nil || !@resp.nil?
        @project
      end
    end
    def node_template
      get_resource_name(@resp.node_template)
    end
    def size
      @resp.size
    end
    def maintenance_policy
      @resp.maintenance_policy
    end
    def autoscaling_policy
      @resp.autoscaling_policy
    end

    def has_autoscaling_policy?(expected_autoscaling_policy)
      @autoscaling_policy = @resp.autoscaling_policy
      if @autoscaling_policy != nil
        @policy = {
          "mode" => @autoscaling_policy.mode,
          "min_nodes" => @autoscaling_policy.min_nodes,
          "max_nodes" => @autoscaling_policy.max_nodes,
        }
        if !JsonUtilities::compare_json(expected_autoscaling_policy, @policy)
          fail "The Expected autoscaling policy for google compute node group is #{expected_autoscaling_policy} but the actual is #{@policy}"
        end
        true
      end
    end

    
end
  def hcap_google_compute_node_group(project,zone,node_group)
      GOOGLE_COMPUTE_NODE_GROUP.new(project,zone,node_group)
  end