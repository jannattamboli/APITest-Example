  require_relative '../Util'
  include Util

  class GOOGLE_COMPUTE_TARGET_POOL
    def initialize(project, region, target_pool)
      @target_pool=target_pool
      begin  
        puts "project : #{project}"
        puts "region: #{region}"
        puts "target pool: #{target_pool}"
        service = getClient('Compute')
        service.authorization = Google::Auth.get_application_default(['https://www.googleapis.com/auth/cloud-platform'])
        resource_name=get_resource_name(target_pool)
        @resp = service.get_target_pool(project, region, resource_name)
        @project = project       
      rescue
      puts "The google_compute_target_pool does not exist"
    end
    end

    def exists?
      if defined?(@resp) == nil || @resp.nil?
       fail "The google_compute_target_pool : #{@target_pool} does not exist"
      else
      true
      end
    end

    def name
      @resp.name
    end
    def description
      @resp.description
    end
    def region
      get_resource_name(@resp.region)
    end
    def project
      if defined?(@resp) != nil || !@resp.nil?
        @project
      end
    end
    def instance
      @resp
    end
    def backup_pool
      get_resource_name(@resp.backup_pool)
    end
    def failover_ratio
      @resp.failover_ratio
    end

    def has_instance?expected_instance
      actual_array=Array.new
      @resp.instances.each { |l|

      actual_array << get_resource_name(l)

    }
    compare_arr(expected_instance,actual_array)
    end

    def has_health_checks?expected_health_checks
      actual_array=Array.new
      @resp.health_checks.each { |l|

      actual_array << get_resource_name(l)

    }
    compare_arr(expected_health_checks,actual_array)
    end

    def session_affinity
      @resp.session_affinity
    end
end
  def hcap_google_compute_target_pool(project, region, target_pool)
      GOOGLE_COMPUTE_TARGET_POOL.new(project, region, target_pool)
  end