  require_relative '../Util'
  include Util
  include JsonUtilities


  class GOOGLE_COMPUTE_FIREWALL
    def initialize(project,firewall)
      @firewall = firewall
      begin
        puts "project : #{project}"
        puts "firewall: #{firewall}"
        service = getClient('Compute')
        service.authorization = Google::Auth.get_application_default(['https://www.googleapis.com/auth/cloud-platform'])
        resource_name=get_resource_name(firewall)
        @resp = service.get_firewall(project, resource_name)
        @project = project
      rescue
      puts "The google_compute_firewall does not exist"
    end
    end

    def exists?
      if defined?(@resp) == nil || @resp.nil?
       fail "The google_compute_firewall : #{@firewall} does not exist"
      else
      true
      end
    end

    def name
      @resp.name
    end
    def description
      @resp.description
    end

    def project
      if defined?(@resp) != nil || !@resp.nil?
        @project
      end
    end
    
    def network
      get_resource_name(@resp.network)
    end
    def direction
      @resp.direction
    end
    def disabled
      @resp.disabled
    end
    def enable_logging
      @resp.log_config.enable
    end
    def priority
      @resp.priority
    end

    def has_log_config?expected_log_config
      @config = @resp.log_config
      if @config != nil 
          @log_config = {
            "metadata" => @config.metadata,
          }
          @resp
          if !JsonUtilities::compare_json(expected_log_config,@log_config)
            fail "The Expected log config for google compute firewall is #{expected_log_config} but the actual is #{@log_config}"
          end
        true
      end
    end

    def has_source_ranges?expected_source
      actual_array=Array.new
      @resp.source_ranges.each { |l|

      actual_array << l

    }
    compare_arr(expected_source,actual_array)
    end

    def has_destination_ranges?expected_destination
      actual_array=Array.new
      @resp.destination_ranges.each { |l|

      actual_array << l

    }
    compare_arr(expected_destination,actual_array)
    end

    def has_source_service_accounts?expected_source_service_accounts
      actual_array=Array.new
      @resp.source_service_accounts.each { |l|

      actual_array << l

    }
    compare_arr(expected_source_service_accounts,actual_array)   
   end

    def has_target_service_accounts?expected_target_service_accounts
      actual_array=Array.new
      @resp.target_service_accounts.each { |l|

      actual_array << l

    }
    compare_arr(expected_target_service_accounts,actual_array)
    end

    def has_target_tags?expected_target_tags
      actual_array=Array.new
      @resp.target_tags.each { |l|

      actual_array << l

    }
    compare_arr(expected_target_tags,actual_array)
    end


    def has_allow?expected_allow
      @actuals=@resp.allowed
      @ports = Array.new
      if @actuals != nil
        @actuals.each { | sub |
        if  sub.ip_protocol == expected_allow['protocol']
                  sub.ports.each { | s |
                  @ports << s
                 }
          @allow_rules = {
                "protocol" => sub.ip_protocol,
                "ports" => @ports
            }
        
        end
        }
        if expected_allow != @allow_rules
          fail "The Expected allow rule for google compute firewall is #{expected_allow} but the actual is #{@allow_rules}"
        end
        true
      end
    end 

    def has_deny?expected_deny
      @actuals=@resp.denied
      @ports = Array.new
      if @actuals != nil
        @actuals.each { | sub |
        if  sub.ip_protocol == expected_deny['protocol']
                  sub.ports.each { | s |
                  @ports << s
                 }
          @deny_rules = {
                "protocol" => sub.ip_protocol,
                "ports" => @ports
            }
        
        end
        }
        if expected_deny != @deny_rules
          fail "The Expected deny rule for google compute firewall allow rules is #{expected_allow} but the actual is #{@deny_rules}"
        end
        true
      end
    end 

    def deny
      @resp
    end
end
  def hcap_google_compute_firewall(project,firewall)
      GOOGLE_COMPUTE_FIREWALL.new(project,firewall)
  end