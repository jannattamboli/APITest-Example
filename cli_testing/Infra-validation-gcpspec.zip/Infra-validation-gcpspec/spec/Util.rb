require 'json'
require_relative './JsonUtilities'
include JsonUtilities
require 'yaml'
require 'json-compare'
require 'googleauth'
require 'google/apis/compute_v1'
require 'google/apis/container_v1'
require 'google/apis/compute_beta'
require "google/cloud/storage"
require 'google/apis/sqladmin_v1beta4'
require 'google/iam/v1beta'
require 'google/apis/iam_v1'
require 'google/apis/container_v1'


module Util

    def getClient(clientType)
		if (clientType != nil)

  			case clientType
                when 'Compute'
                    puts 'Client Name - Compute'
                    compute_service = Google::Apis::ComputeV1::ComputeService.new
                    return compute_service
                when 'Compute-Beta'
                    puts 'Client Name - Compute-Beta'
                    compute_beta_service = Google::Apis::ComputeBeta::ComputeService.new
					return compute_beta_service
				when 'Storage'
					puts 'Client Name - Storage'
					storage_service = Google::Cloud::Storage.new
					return storage_service
				
				when 'SQL'
					puts 'Client Name - SQL'
					service=Google::Apis::SqladminV1beta4::SQLAdminService.new
					return service
				when 'Iam-Beta'
					puts 'Client Name - IamBeta'
					service=Google::Iam::V1beta::WorkloadIdentityPools::Client.new
					return service
				when 'Iam'
					puts 'Client Name - Iam'
					service=Google::Apis::IamV1::IamService.new
					return service
				when 'ContainerService'
					puts 'Client Name - ContainerService'
					service=Google::Apis::ContainerV1::ContainerService.new
					return service

  			else
    			puts 'Client type is not valid'
    			return nil
			end
		end
    end
    
    def get_value_to_compare(key_array, result, indx, type) 
		
		result_array = []
		 
		# if last attribute and JSON_STRING type comparision then just return the value
		json_string_compare = ((indx == (key_array.length - 1)) and type == "JSON_STRING")
		
		data = result[key_array[indx]]
			if data.instance_of? Array and !json_string_compare
				data.each do |record|
					if record.kind_of?Aws::Structure
						return get_value_to_compare(key_array,record,indx+1,type)
					else
						result_array.push(record)	
					end 	
				end
			elsif data.kind_of?Aws::Structure
				return get_value_to_compare(key_array,data,indx+1,type)
			else 
				result_array.push(data)
			end
		return result_array	
	end

	def compare_arr(a,b)
		a.size==b.size and a&b==a
    end
    
    def get_resource_name(resource_id)
		if resource_id.include? "projects"
			arr = resource_id.split('/')
			resource_name= arr[arr.length - 1]
			@resource_name=resource_name
        else
			@resource_name=resource_id
		end
		@resource_name
	end

end