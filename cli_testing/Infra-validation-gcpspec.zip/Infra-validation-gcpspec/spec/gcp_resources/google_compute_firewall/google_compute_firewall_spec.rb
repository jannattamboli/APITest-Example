require 'spec_helper'
require 'ResourceType'
require_relative '../../spec_classes/google_compute_firewall'
require_relative 'google_compute_firewall_attributes'

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_compute_firewall"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_COMPUTE_FIREWALL)

if list_of_gcp_resource != nil

  list_of_gcp_resource.each {|name, value|

    puts "#{name} : #{value}"
    google_compute_firewall_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_COMPUTE_FIREWALL, name)
    puts "google_compute_firewall attributes : #{google_compute_firewall_attributes}"

	if google_compute_firewall_attributes != nil
		
		project = project = ENV['PROJECT']
      
		if project.nil? || project.empty? 
		  fail "Project name can not be null or empty."
		end

      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_compute_firewall : #{name}"
      puts "--------------------------------------------"

	  describe hcap_google_compute_firewall(project,value) do
		
		context "When validating existance of google_compute_firewall [#{value}]" do
				it {should exist}
		end

		if google_compute_firewall_attributes.has_key?(GOOGLE_COMPUTE_FIREWALL_ATTR::NAME) and google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::NAME] != nil
			its(:name) { should eq value(google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::NAME]) }
		end 
		if google_compute_firewall_attributes.has_key?(GOOGLE_COMPUTE_FIREWALL_ATTR::PROJECT) and google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::PROJECT] != nil
			its(:project) { should eq value(google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::PROJECT]) }
		end
		if google_compute_firewall_attributes.has_key?(GOOGLE_COMPUTE_FIREWALL_ATTR::DESCRIPTION) and google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::DESCRIPTION] != nil
			its(:description) { should eq value(google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::DESCRIPTION]) }
		end
		if google_compute_firewall_attributes.has_key?(GOOGLE_COMPUTE_FIREWALL_ATTR::NETWORK) and google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::NETWORK] != nil
			its(:network) { should eq value(google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::NETWORK]) }
		end
		if google_compute_firewall_attributes.has_key?(GOOGLE_COMPUTE_FIREWALL_ATTR::DIRECTION) and google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::DIRECTION] != nil
			its(:direction) { should eq value(google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::DIRECTION]) }
		end
		if google_compute_firewall_attributes.has_key?(GOOGLE_COMPUTE_FIREWALL_ATTR::DISABLED) and google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::DISABLED] != nil
			its(:disabled) { should eq value(google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::DISABLED]) }
		end
		if google_compute_firewall_attributes.has_key?(GOOGLE_COMPUTE_FIREWALL_ATTR::ENABLE_LOGGING) and google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::ENABLE_LOGGING] != nil
			its(:enable_logging) { should eq value(google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::ENABLE_LOGGING]) }
		end
		if google_compute_firewall_attributes.has_key?(GOOGLE_COMPUTE_FIREWALL_ATTR::PRIORITY) and google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::PRIORITY] != nil
			its(:priority) { should eq value(google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::PRIORITY]) }
		end

		context 'validating log config for google compute firewall' do
			if google_compute_firewall_attributes.has_key?(GOOGLE_COMPUTE_FIREWALL_ATTR::LOG_CONFIG) and google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::LOG_CONFIG] != nil
				it { should have_log_config google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::LOG_CONFIG]}
            end
		  end

		context 'validating source ranges for google compute firewall' do
			if google_compute_firewall_attributes.has_key?(GOOGLE_COMPUTE_FIREWALL_ATTR::SOURCE_RANGES) and google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::SOURCE_RANGES] != nil
				it { should have_source_ranges google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::SOURCE_RANGES]}
            end
		  end
		  
		  context 'validating destination ranges for google compute firewall' do
			if google_compute_firewall_attributes.has_key?(GOOGLE_COMPUTE_FIREWALL_ATTR::DESTINATION_RANGES) and google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::DESTINATION_RANGES] != nil
				it { should have_destination_ranges google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::DESTINATION_RANGES]}
            end
		  end

		  context 'validating source service account ranges for google compute firewall' do
			if google_compute_firewall_attributes.has_key?(GOOGLE_COMPUTE_FIREWALL_ATTR::SOURCE_SERVICE_ACCOUNTS) and google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::SOURCE_SERVICE_ACCOUNTS] != nil
				it { should have_source_service_accounts google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::SOURCE_SERVICE_ACCOUNTS]}
            end
		  end

		  context 'validating target service account ranges for google compute firewall' do
			if google_compute_firewall_attributes.has_key?(GOOGLE_COMPUTE_FIREWALL_ATTR::TARGET_SERVICE_ACCOUNTS) and google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::TARGET_SERVICE_ACCOUNTS] != nil
				it { should have_target_service_accounts google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::TARGET_SERVICE_ACCOUNTS]}
            end
		  end

		  context 'validating target tags for google compute firewall' do
			if google_compute_firewall_attributes.has_key?(GOOGLE_COMPUTE_FIREWALL_ATTR::TARGET_TAGS) and google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::TARGET_TAGS] != nil
				it { should have_target_tags google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::TARGET_TAGS]}
            end
		  end

		context "When validating  Google Compute firewall allow rules" do
			allow = google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::ALLOW]
			if google_compute_firewall_attributes.has_key?(GOOGLE_COMPUTE_FIREWALL_ATTR::ALLOW) and google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::ALLOW] != nil
				allow.each{ |sub|
				it { should have_allow sub }
				}
			end
		end

		context "When validating  Google Compute firewall deny rules" do
			deny = google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::DENY]
			if google_compute_firewall_attributes.has_key?(GOOGLE_COMPUTE_FIREWALL_ATTR::DENY) and google_compute_firewall_attributes[GOOGLE_COMPUTE_FIREWALL_ATTR::DENY] != nil
				deny.each{ |sub|
				it { should have_deny sub }
				}
			end
		end

      end

    end
  }

end