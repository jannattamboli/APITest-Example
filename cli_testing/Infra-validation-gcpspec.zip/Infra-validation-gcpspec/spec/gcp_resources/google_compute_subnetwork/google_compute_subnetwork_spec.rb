require 'spec_helper'
require 'ResourceType'
require_relative '../../spec_classes/google_compute_subnetwork'
require_relative 'google_compute_subnetwork_attributes'

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_compute_subnetwork"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_COMPUTE_SUBNETWORK)

if list_of_gcp_resource != nil

  list_of_gcp_resource.each {|name, value|

    puts "#{name} : #{value}"
    google_compute_subnetwork_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_COMPUTE_SUBNETWORK, name)
    puts "google_compute_subnetwork attributes : #{google_compute_subnetwork_attributes}"

	if google_compute_subnetwork_attributes != nil
		
		region = google_compute_subnetwork_attributes[GOOGLE_COMPUTE_SUBNETWORK_ATTR::REGION]
      
      if region.nil? || region.empty? 
        fail "Region name can not be null or empty."
      end

      project = project = ENV['PROJECT']
      
      if project.nil? || project.empty? 
        fail "Project name can not be null or empty."
      end

      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_compute_subnetwork : #{name}"
      puts "--------------------------------------------"

      describe hcap_google_compute_subnetwork(project,region,value) do

		context "When validating existance of Google Compute Network : #{name}" do
            it {should exist}
		end
		
		if google_compute_subnetwork_attributes.has_key?(GOOGLE_COMPUTE_SUBNETWORK_ATTR::NAME) and google_compute_subnetwork_attributes[GOOGLE_COMPUTE_SUBNETWORK_ATTR::NAME] != nil
			its(:name) { should eq value(google_compute_subnetwork_attributes[GOOGLE_COMPUTE_SUBNETWORK_ATTR::NAME]) }
		end
		if google_compute_subnetwork_attributes.has_key?(GOOGLE_COMPUTE_SUBNETWORK_ATTR::DESCRIPTION) and google_compute_subnetwork_attributes[GOOGLE_COMPUTE_SUBNETWORK_ATTR::DESCRIPTION] != nil
			its(:description) { should eq value(google_compute_subnetwork_attributes[GOOGLE_COMPUTE_SUBNETWORK_ATTR::DESCRIPTION]) }
		end 

		if google_compute_subnetwork_attributes.has_key?(GOOGLE_COMPUTE_SUBNETWORK_ATTR::PROJECT) and google_compute_subnetwork_attributes[GOOGLE_COMPUTE_SUBNETWORK_ATTR::PROJECT] != nil
			its(:project) { should eq value(google_compute_subnetwork_attributes[GOOGLE_COMPUTE_SUBNETWORK_ATTR::PROJECT]) }
		end

		if google_compute_subnetwork_attributes.has_key?(GOOGLE_COMPUTE_SUBNETWORK_ATTR::PURPOSE) and google_compute_subnetwork_attributes[GOOGLE_COMPUTE_SUBNETWORK_ATTR::PURPOSE] != nil
			its(:purpose) { should eq value(google_compute_subnetwork_attributes[GOOGLE_COMPUTE_SUBNETWORK_ATTR::PURPOSE]) }
		end
		if google_compute_subnetwork_attributes.has_key?(GOOGLE_COMPUTE_SUBNETWORK_ATTR::PRIVATE_IP_GOOGLE_ACCESS) and google_compute_subnetwork_attributes[GOOGLE_COMPUTE_SUBNETWORK_ATTR::PRIVATE_IP_GOOGLE_ACCESS] != nil
			its(:private_ip_google_access) { should eq value(google_compute_subnetwork_attributes[GOOGLE_COMPUTE_SUBNETWORK_ATTR::PRIVATE_IP_GOOGLE_ACCESS]) }
		end
		if google_compute_subnetwork_attributes.has_key?(GOOGLE_COMPUTE_SUBNETWORK_ATTR::IP_CIDR_RANGE) and google_compute_subnetwork_attributes[GOOGLE_COMPUTE_SUBNETWORK_ATTR::IP_CIDR_RANGE] != nil
			its(:ip_cidr_range) { should eq value(google_compute_subnetwork_attributes[GOOGLE_COMPUTE_SUBNETWORK_ATTR::IP_CIDR_RANGE]) }
		end

			context "When validating  Google Compute Network secondary ip range" do
				secondary_ip = google_compute_subnetwork_attributes[GOOGLE_COMPUTE_SUBNETWORK_ATTR::SECONDARY_IP_RANGE]
				if google_compute_subnetwork_attributes.has_key?(GOOGLE_COMPUTE_SUBNETWORK_ATTR::SECONDARY_IP_RANGE) and google_compute_subnetwork_attributes[GOOGLE_COMPUTE_SUBNETWORK_ATTR::SECONDARY_IP_RANGE] != nil
					secondary_ip.each{ |sub|
					it { should have_secondary_ip_range sub }
					}
				end
			end

		context 'When validating  Google Compute Network log config' do
			if google_compute_subnetwork_attributes.has_key?(GOOGLE_COMPUTE_SUBNETWORK_ATTR::LOG_CONFIG) and google_compute_subnetwork_attributes[GOOGLE_COMPUTE_SUBNETWORK_ATTR::LOG_CONFIG] != nil
				it {should have_log_config google_compute_subnetwork_attributes[GOOGLE_COMPUTE_SUBNETWORK_ATTR::LOG_CONFIG]}
			end
		  end

      end

    end
  }

end