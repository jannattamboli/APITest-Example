module GOOGLE_COMPUTE_SUBNETWORK_ATTR
	NAME="name"
	REGION="region"
	DESCRIPTION="description"
	PROJECT="project"
	PURPOSE="purpose"
	PRIVATE_IP_GOOGLE_ACCESS="private_ip_google_access"
	IP_CIDR_RANGE="ip_cidr_range"
	LOG_CONFIG="log_config"
	SECONDARY_IP_RANGE="secondary_ip_range"
 end