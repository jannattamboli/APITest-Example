module GOOGLE_COMPUTE_ADDRESS_ATTR
	NAME="name"
	DESCRIPTION="description"
	LABELS="labels"
	ADDRESS="address"
	ADDRESS_TYPE="address_type"
	PURPOSE="purpose"
	NETWORK_TIER="network_tier"
	SUBNETWORK="subnetwork"
	REGION="region"
	PROJECT="project"
 end