require "spec_helper"
require "ResourceType"
require_relative "../../spec_classes/google_compute_router_nat"
require_relative "google_compute_router_nat_attributes"

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_compute_router_nat"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_COMPUTE_ROUTER_NAT)

if list_of_gcp_resource != nil
  list_of_gcp_resource.each { |name, value|
    puts "#{name} : #{value}"
    google_compute_router_nat_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_COMPUTE_ROUTER_NAT, name)
    puts "google_compute_router_nat attributes : #{google_compute_router_nat_attributes}"

    if google_compute_router_nat_attributes != nil
      region = google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::REGION]

      if region.nil? || region.empty?
        fail "Region name can not be null or empty."
      end
      router = google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::ROUTER]

      if router.nil? || router.empty?
        fail "router name can not be null or empty."
      end
      project = ENV["PROJECT"]

      if project.nil? || project.empty?
        fail "Project name can not be null or empty."
      end
      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_compute_router_nat : #{value}"
      puts "--------------------------------------------"

      describe hcap_google_compute_router_nat(project, region, router, value) do
        context "When validating existance of google_compute_router_nat [#{value}]" do
          it { should exist }
        end

        if google_compute_router_nat_attributes.has_key?(GOOGLE_COMPUTE_ROUTER_NAT_ATTR::NAME) and google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::NAME] != nil
          its(:name) { should eq value(google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::NAME]) }
        end
        if google_compute_router_nat_attributes.has_key?(GOOGLE_COMPUTE_ROUTER_NAT_ATTR::NAT_IP_ALLOCATE_OPTION) and google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::NAT_IP_ALLOCATE_OPTION] != nil
          its(:nat_ip_allocate_option) { should eq value(google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::NAT_IP_ALLOCATE_OPTION]) }
        end
        if google_compute_router_nat_attributes.has_key?(GOOGLE_COMPUTE_ROUTER_NAT_ATTR::SOURCE_SUBNETWORK_IP_RANGES_TO_NAT) and google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::SOURCE_SUBNETWORK_IP_RANGES_TO_NAT] != nil
          its(:source_subnetwork_ip_ranges_to_nat) { should eq value(google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::SOURCE_SUBNETWORK_IP_RANGES_TO_NAT]) }
        end
        if google_compute_router_nat_attributes.has_key?(GOOGLE_COMPUTE_ROUTER_NAT_ATTR::NAT_IPS) and google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::NAT_IPS] != nil
          its(:nat_ips) { should eq value(google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::NAT_IPS]) }
        end
        if google_compute_router_nat_attributes.has_key?(GOOGLE_COMPUTE_ROUTER_NAT_ATTR::DRAIN_NAT_IPS) and google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::DRAIN_NAT_IPS] != nil
          its(:drain_nat_ips) { should eq value(google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::DRAIN_NAT_IPS]) }
        end
        if google_compute_router_nat_attributes.has_key?(GOOGLE_COMPUTE_ROUTER_NAT_ATTR::MIN_PORTS_PER_VM) and google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::MIN_PORTS_PER_VM] != nil
          its(:min_ports_per_vm) { should eq value(google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::MIN_PORTS_PER_VM]) }
        end
        if google_compute_router_nat_attributes.has_key?(GOOGLE_COMPUTE_ROUTER_NAT_ATTR::UDP_IDLE_TIMEOUT_SEC) and google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::UDP_IDLE_TIMEOUT_SEC] != nil
          its(:udp_idle_timeout_sec) { should eq value(google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::UDP_IDLE_TIMEOUT_SEC]) }
        end
        if google_compute_router_nat_attributes.has_key?(GOOGLE_COMPUTE_ROUTER_NAT_ATTR::ICMP_IDLE_TIMEOUT_SEC) and google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::ICMP_IDLE_TIMEOUT_SEC] != nil
          its(:icmp_idle_timeout_sec) { should eq value(google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::ICMP_IDLE_TIMEOUT_SEC]) }
        end
        if google_compute_router_nat_attributes.has_key?(GOOGLE_COMPUTE_ROUTER_NAT_ATTR::TCP_ESTABLISHED_IDLE_TIMEOUT_SEC) and google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::TCP_ESTABLISHED_IDLE_TIMEOUT_SEC] != nil
          its(:tcp_established_idle_timeout_sec) { should eq value(google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::TCP_ESTABLISHED_IDLE_TIMEOUT_SEC]) }
        end
        if google_compute_router_nat_attributes.has_key?(GOOGLE_COMPUTE_ROUTER_NAT_ATTR::TCP_TRANSITORY_IDLE_TIMEOUT_SEC) and google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::TCP_TRANSITORY_IDLE_TIMEOUT_SEC] != nil
          its(:tcp_transitory_idle_timeout_sec) { should eq value(google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::TCP_TRANSITORY_IDLE_TIMEOUT_SEC]) }
        end

        # context 'When validating Google Compute Router Nat  SUBNETWORK' do
        # 		if google_compute_router_nat_attributes.has_key?(GOOGLE_COMPUTE_ROUTER_NAT_ATTR::SUBNETWORK) and google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::SUBNETWORK] != nil
        # 			it {should have_subnetwork google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::SUBNETWORK]}
        # 		end
        # end
        context "When validating Google Compute Router Nat log_config" do
          if google_compute_router_nat_attributes.has_key?(GOOGLE_COMPUTE_ROUTER_NAT_ATTR::LOG_CONFIG) and google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::LOG_CONFIG] != nil
            it { should have_log_config google_compute_router_nat_attributes[GOOGLE_COMPUTE_ROUTER_NAT_ATTR::LOG_CONFIG] }
          end
        end
      end
    end
  }
end
