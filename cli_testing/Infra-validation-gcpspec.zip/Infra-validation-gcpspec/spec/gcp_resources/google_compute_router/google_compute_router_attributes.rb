module GOOGLE_COMPUTE_ROUTER_ATTR
	NAME="name"
	DESCRIPTION="description"
	PROJECT="project"
	REGION="region"
	NETWORK="network"
	BGP ="bgp "
 end