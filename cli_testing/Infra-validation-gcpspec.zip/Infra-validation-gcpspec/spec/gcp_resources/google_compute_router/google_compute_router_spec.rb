require 'spec_helper'
require 'ResourceType'
require_relative '../../spec_classes/google_compute_router'
require_relative 'google_compute_router_attributes'

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_compute_router"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_COMPUTE_ROUTER)

if list_of_gcp_resource != nil

  list_of_gcp_resource.each {|name, value|

    puts "#{name} : #{value}"
    google_compute_router_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_COMPUTE_ROUTER, name)
    puts "google_compute_router attributes : #{google_compute_router_attributes}"

	if google_compute_router_attributes != nil
		
			region = google_compute_router_attributes[GOOGLE_COMPUTE_ROUTER_ATTR::REGION]
		  
		  if region.nil? || region.empty? 
			fail "Region name can not be null or empty."
		  end
	
		  project = ENV['PROJECT']
		  
		  if project.nil? || project.empty? 
			fail "Project name can not be null or empty."
		  end

      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_compute_router : #{name}"
      puts "--------------------------------------------"

		describe hcap_google_compute_router(project,region,value) do

			context "When validating existance of google_compute_router [#{value}]" do
				it {should exist}
		  	end

			if google_compute_router_attributes.has_key?(GOOGLE_COMPUTE_ROUTER_ATTR::NAME) and google_compute_router_attributes[GOOGLE_COMPUTE_ROUTER_ATTR::NAME] != nil
				its(:name) { should eq value(google_compute_router_attributes[GOOGLE_COMPUTE_ROUTER_ATTR::NAME]) }
			end
			if google_compute_router_attributes.has_key?(GOOGLE_COMPUTE_ROUTER_ATTR::DESCRIPTION) and google_compute_router_attributes[GOOGLE_COMPUTE_ROUTER_ATTR::DESCRIPTION] != nil
				its(:description) { should eq value(google_compute_router_attributes[GOOGLE_COMPUTE_ROUTER_ATTR::DESCRIPTION]) }
			end
			if google_compute_router_attributes.has_key?(GOOGLE_COMPUTE_ROUTER_ATTR::PROJECT) and google_compute_router_attributes[GOOGLE_COMPUTE_ROUTER_ATTR::PROJECT] != nil
				its(:project) { should eq value(google_compute_router_attributes[GOOGLE_COMPUTE_ROUTER_ATTR::PROJECT]) }
			end
			if google_compute_router_attributes.has_key?(GOOGLE_COMPUTE_ROUTER_ATTR::REGION) and google_compute_router_attributes[GOOGLE_COMPUTE_ROUTER_ATTR::REGION] != nil
				its(:region) { should eq value(google_compute_router_attributes[GOOGLE_COMPUTE_ROUTER_ATTR::REGION]) }
			end
			if google_compute_router_attributes.has_key?(GOOGLE_COMPUTE_ROUTER_ATTR::NETWORK) and google_compute_router_attributes[GOOGLE_COMPUTE_ROUTER_ATTR::NETWORK] != nil
				its(:network) { should eq value(google_compute_router_attributes[GOOGLE_COMPUTE_ROUTER_ATTR::NETWORK]) }
			end

			context 'When validating google compute router bgp' do
				if google_compute_router_attributes.has_key?(GOOGLE_COMPUTE_ROUTER_ATTR::BGP ) and google_compute_router_attributes[GOOGLE_COMPUTE_ROUTER_ATTR::BGP ] != nil
					google_compute_router_attributes[GOOGLE_COMPUTE_ROUTER_ATTR::BGP].each {|key, value|
					it {should have_bgp(key, value(value))}
					}
				end
			end

		
		end

    end
  }

end