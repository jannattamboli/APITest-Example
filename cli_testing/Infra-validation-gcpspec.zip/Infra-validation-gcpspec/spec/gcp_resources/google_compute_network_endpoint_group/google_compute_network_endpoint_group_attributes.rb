module GOOGLE_COMPUTE_NETWORK_ENDPOINT_GROUP_ATTR
	NAME="name"
	DESCRIPTION="description"
	ZONE="zone"
	PROJECT="project"
	NETWORK="network"
	NETWORK_ENDPOINT_TYPE="network_endpoint_type"
	SUBNETWORK="subnetwork"
	DEFAULT_PORT="default_port"
 end