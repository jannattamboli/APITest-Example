require 'spec_helper'
require 'ResourceType'
require_relative '../../spec_classes/google_compute_node_group'
require_relative 'google_compute_node_group_attributes'

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_compute_node_group"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_COMPUTE_NODE_GROUP)

if list_of_gcp_resource != nil

  list_of_gcp_resource.each {|name, value|

    puts "#{name} : #{value}"
    google_compute_node_group_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_COMPUTE_NODE_GROUP, name)
    puts "google_compute_node_group attributes : #{google_compute_node_group_attributes}"

	if google_compute_node_group_attributes != nil 
		
		zone = google_compute_node_group_attributes[GOOGLE_COMPUTE_NODE_GROUP_ATTR::ZONE]
      
		if zone.nil? || zone.empty? 
		  fail "Zone name can not be null or empty."
		end
  
		  
		  project = ENV['PROJECT']
		  if project.nil? || project.empty? 
			  fail "Project name can not be null or empty."
		  end

      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_compute_node_group : #{name}"
      puts "--------------------------------------------"

	  describe hcap_google_compute_node_group(project,zone,value) do
		
		context "When validating existance of Google Compute node  group : #{name}" do
			it {should exist}
		end


		if google_compute_node_group_attributes.has_key?(GOOGLE_COMPUTE_NODE_GROUP_ATTR::NAME) and google_compute_node_group_attributes[GOOGLE_COMPUTE_NODE_GROUP_ATTR::NAME] != nil
			its(:name) { should eq value(google_compute_node_group_attributes[GOOGLE_COMPUTE_NODE_GROUP_ATTR::NAME]) }
		end
		if google_compute_node_group_attributes.has_key?(GOOGLE_COMPUTE_NODE_GROUP_ATTR::DESCRIPTION) and google_compute_node_group_attributes[GOOGLE_COMPUTE_NODE_GROUP_ATTR::DESCRIPTION] != nil
			its(:description) { should eq value(google_compute_node_group_attributes[GOOGLE_COMPUTE_NODE_GROUP_ATTR::DESCRIPTION]) }
		end
		if google_compute_node_group_attributes.has_key?(GOOGLE_COMPUTE_NODE_GROUP_ATTR::ZONE) and google_compute_node_group_attributes[GOOGLE_COMPUTE_NODE_GROUP_ATTR::ZONE] != nil
			its(:zone) { should eq value(google_compute_node_group_attributes[GOOGLE_COMPUTE_NODE_GROUP_ATTR::ZONE]) }
		end
		if google_compute_node_group_attributes.has_key?(GOOGLE_COMPUTE_NODE_GROUP_ATTR::PROJECT) and google_compute_node_group_attributes[GOOGLE_COMPUTE_NODE_GROUP_ATTR::PROJECT] != nil
			its(:project) { should eq value(google_compute_node_group_attributes[GOOGLE_COMPUTE_NODE_GROUP_ATTR::PROJECT]) }
		end
		if google_compute_node_group_attributes.has_key?(GOOGLE_COMPUTE_NODE_GROUP_ATTR::NODE_TEMPLATE) and google_compute_node_group_attributes[GOOGLE_COMPUTE_NODE_GROUP_ATTR::NODE_TEMPLATE] != nil
			its(:node_template) { should eq value(google_compute_node_group_attributes[GOOGLE_COMPUTE_NODE_GROUP_ATTR::NODE_TEMPLATE]) }
		end
		if google_compute_node_group_attributes.has_key?(GOOGLE_COMPUTE_NODE_GROUP_ATTR::SIZE) and google_compute_node_group_attributes[GOOGLE_COMPUTE_NODE_GROUP_ATTR::SIZE] != nil
			its(:size) { should eq value(google_compute_node_group_attributes[GOOGLE_COMPUTE_NODE_GROUP_ATTR::SIZE]) }
		end
		if google_compute_node_group_attributes.has_key?(GOOGLE_COMPUTE_NODE_GROUP_ATTR::MAINTENANCE_POLICY) and google_compute_node_group_attributes[GOOGLE_COMPUTE_NODE_GROUP_ATTR::MAINTENANCE_POLICY] != nil
			its(:maintenance_policy) { should eq value(google_compute_node_group_attributes[GOOGLE_COMPUTE_NODE_GROUP_ATTR::MAINTENANCE_POLICY]) }
		end

		context "When validating google compute node group autoscaling policy" do
			if google_compute_node_group_attributes.has_key?(GOOGLE_COMPUTE_NODE_GROUP_ATTR::AUTOSCALING_POLICY) and google_compute_node_group_attributes[GOOGLE_COMPUTE_NODE_GROUP_ATTR::AUTOSCALING_POLICY] != nil
				it { should have_autoscaling_policy google_compute_node_group_attributes[GOOGLE_COMPUTE_NODE_GROUP_ATTR::AUTOSCALING_POLICY] }
			end
		  end

      end

    end
  }

end