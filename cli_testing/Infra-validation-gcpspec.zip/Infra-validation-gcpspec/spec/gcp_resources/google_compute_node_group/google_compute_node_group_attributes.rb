module GOOGLE_COMPUTE_NODE_GROUP_ATTR
	NAME="name"
	DESCRIPTION="description"
	ZONE="zone"
	PROJECT="project"
	NODE_TEMPLATE="node_template"
	SIZE="size"
	MAINTENANCE_POLICY="maintenance_policy"
	AUTOSCALING_POLICY="autoscaling_policy"
 end