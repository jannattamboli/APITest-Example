module GOOGLE_COMPUTE_TARGET_POOL_ATTR
	NAME="name"
	DESCRIPTION="description"
	REGION="region"
	PROJECT="project"
	INSTANCE="instance"
	BACKUP_POOL="backup_pool"
	FAILOVER_RATIO="failover_ratio"
	HEALTH_CHECKS="health_checks"
	SESSION_AFFINITY="session_affinity"
 end