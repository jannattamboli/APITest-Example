require 'spec_helper'
require 'ResourceType'
require_relative '../../spec_classes/google_compute_target_pool'
require_relative 'google_compute_target_pool_attributes'

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_compute_target_pool"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_COMPUTE_TARGET_POOL)

if list_of_gcp_resource != nil

  list_of_gcp_resource.each {|name, value|

    puts "#{name} : #{value}"
    google_compute_target_pool_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_COMPUTE_TARGET_POOL, name)
    puts "google_compute_target_pool attributes : #{google_compute_target_pool_attributes}"

	if google_compute_target_pool_attributes != nil 
		
		region = google_compute_target_pool_attributes[GOOGLE_COMPUTE_TARGET_POOL_ATTR::REGION]
      
		if region.nil? || region.empty? 
		  fail "region name can not be null or empty."
		end
  
		  
		  project = ENV['PROJECT']
		  if project.nil? || project.empty? 
			  fail "Project name can not be null or empty."
		  end

      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_compute_target_pool : #{name}"
      puts "--------------------------------------------"

      describe hcap_google_compute_target_pool(project,region,value) do

		context "When validating existance of Google Compute target pool : #{name}" do
			it {should exist}
		end

		if google_compute_target_pool_attributes.has_key?(GOOGLE_COMPUTE_TARGET_POOL_ATTR::NAME) and google_compute_target_pool_attributes[GOOGLE_COMPUTE_TARGET_POOL_ATTR::NAME] != nil
			its(:name) { should eq value(google_compute_target_pool_attributes[GOOGLE_COMPUTE_TARGET_POOL_ATTR::NAME]) }
		end
		if google_compute_target_pool_attributes.has_key?(GOOGLE_COMPUTE_TARGET_POOL_ATTR::DESCRIPTION) and google_compute_target_pool_attributes[GOOGLE_COMPUTE_TARGET_POOL_ATTR::DESCRIPTION] != nil
			its(:description) { should eq value(google_compute_target_pool_attributes[GOOGLE_COMPUTE_TARGET_POOL_ATTR::DESCRIPTION]) }
		end
		if google_compute_target_pool_attributes.has_key?(GOOGLE_COMPUTE_TARGET_POOL_ATTR::REGION) and google_compute_target_pool_attributes[GOOGLE_COMPUTE_TARGET_POOL_ATTR::REGION] != nil
			its(:region) { should eq value(google_compute_target_pool_attributes[GOOGLE_COMPUTE_TARGET_POOL_ATTR::REGION]) }
		end
		if google_compute_target_pool_attributes.has_key?(GOOGLE_COMPUTE_TARGET_POOL_ATTR::PROJECT) and google_compute_target_pool_attributes[GOOGLE_COMPUTE_TARGET_POOL_ATTR::PROJECT] != nil
			its(:project) { should eq value(google_compute_target_pool_attributes[GOOGLE_COMPUTE_TARGET_POOL_ATTR::PROJECT]) }
		end

		if google_compute_target_pool_attributes.has_key?(GOOGLE_COMPUTE_TARGET_POOL_ATTR::BACKUP_POOL) and google_compute_target_pool_attributes[GOOGLE_COMPUTE_TARGET_POOL_ATTR::BACKUP_POOL] != nil
			its(:backup_pool) { should eq value(google_compute_target_pool_attributes[GOOGLE_COMPUTE_TARGET_POOL_ATTR::BACKUP_POOL]) }
		end
		if google_compute_target_pool_attributes.has_key?(GOOGLE_COMPUTE_TARGET_POOL_ATTR::FAILOVER_RATIO) and google_compute_target_pool_attributes[GOOGLE_COMPUTE_TARGET_POOL_ATTR::FAILOVER_RATIO] != nil
			its(:failover_ratio) { should eq value(google_compute_target_pool_attributes[GOOGLE_COMPUTE_TARGET_POOL_ATTR::FAILOVER_RATIO]) }
		end

		if google_compute_target_pool_attributes.has_key?(GOOGLE_COMPUTE_TARGET_POOL_ATTR::SESSION_AFFINITY) and google_compute_target_pool_attributes[GOOGLE_COMPUTE_TARGET_POOL_ATTR::SESSION_AFFINITY] != nil
			its(:session_affinity) { should eq value(google_compute_target_pool_attributes[GOOGLE_COMPUTE_TARGET_POOL_ATTR::SESSION_AFFINITY]) }
		end

		context 'validating target tags for google compute firewall' do
			if google_compute_target_pool_attributes.has_key?(GOOGLE_COMPUTE_TARGET_POOL_ATTR::INSTANCE) and google_compute_target_pool_attributes[GOOGLE_COMPUTE_TARGET_POOL_ATTR::INSTANCE] != nil
				it { should have_instance google_compute_target_pool_attributes[GOOGLE_COMPUTE_TARGET_POOL_ATTR::INSTANCE]}
            end
		  end

		  context 'validating target tags for google compute firewall' do
			if google_compute_target_pool_attributes.has_key?(GOOGLE_COMPUTE_TARGET_POOL_ATTR::HEALTH_CHECKS) and google_compute_target_pool_attributes[GOOGLE_COMPUTE_TARGET_POOL_ATTR::HEALTH_CHECKS] != nil
				it { should have_health_checks google_compute_target_pool_attributes[GOOGLE_COMPUTE_TARGET_POOL_ATTR::HEALTH_CHECKS]}
            end
		  end


      end

    end
  }

end