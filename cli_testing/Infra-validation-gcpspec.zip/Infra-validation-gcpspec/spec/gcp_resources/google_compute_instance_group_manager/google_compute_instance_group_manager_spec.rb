require 'spec_helper'
require 'ResourceType'
require_relative '../../spec_classes/google_compute_instance_group_manager'
require_relative 'google_compute_instance_group_manager_attributes'

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_compute_instance_group_manager"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER)

if list_of_gcp_resource != nil

  list_of_gcp_resource.each {|name, value|

    puts "#{name} : #{value}"
    google_compute_instance_group_manager_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER, name)
    puts "google_compute_instance_group_manager attributes : #{google_compute_instance_group_manager_attributes}"

    if google_compute_instance_group_manager_attributes != nil 
    	zone = google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::ZONE]
      
      if zone.nil? || zone.empty? 
        fail "Zone name can not be null or empty."
      end

      project = ENV['PROJECT']
      
      if project.nil? || project.empty? 
        fail "Project name can not be null or empty."
	  end

      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_compute_instance_group_manager : #{value}"
      puts "--------------------------------------------"

      describe hcap_google_compute_instance_group_manager(project,zone,value) do
         context "When validating existance of google_compute_instance_group_manager [#{value}]" do
          it {should exist}
         end

		if google_compute_instance_group_manager_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::BASE_INSTANCE_NAME) and google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::BASE_INSTANCE_NAME] != nil
			its(:base_instance_name) { should eq value(google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::BASE_INSTANCE_NAME]) }
		end
		if google_compute_instance_group_manager_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::NAME) and google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::NAME] != nil
			its(:name) { should eq value(google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::NAME]) }
		end
		if google_compute_instance_group_manager_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::ZONE) and google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::ZONE] != nil
			its(:zone) { should eq value(google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::ZONE]) }
		end
		if google_compute_instance_group_manager_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::DESCRIPTION) and google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::DESCRIPTION] != nil
			its(:description) { should eq value(google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::DESCRIPTION]) }
		end
		if google_compute_instance_group_manager_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::TARGET_SIZE) and google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::TARGET_SIZE] != nil
			its(:target_size) { should eq value(google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::TARGET_SIZE]) }
		end
		if google_compute_instance_group_manager_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::TARGET_POOLS) and google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::TARGET_POOLS] != nil
			its(:target_pools) { should eq value(google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::TARGET_POOLS]) }
		end

		context 'When validating Google Compute Instance Group Manager update_policy' do
			if google_compute_instance_group_manager_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::UPDATE_POLICY) and google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::UPDATE_POLICY] != nil
				it {should have_update_policy google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::UPDATE_POLICY]}
			end
		end

		context 'When validating Google Compute Instance Group Manager stateful_disk' do
			if google_compute_instance_group_manager_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::STATEFUL_DISK) and google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::STATEFUL_DISK] != nil
				it {should have_stateful_disk google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::STATEFUL_DISK]}
			end
		end

		context 'When validating Google Compute Instance Group Manager auto_healing_policies' do
			if google_compute_instance_group_manager_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::AUTO_HEALING_POLICIES) and google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::AUTO_HEALING_POLICIES] != nil
				it {should have_auto_healing_policies google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::AUTO_HEALING_POLICIES]}
			end
		end

		context 'When validating Google Compute Instance Group Manager named_port' do
			if google_compute_instance_group_manager_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::NAMED_PORT) and google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::NAMED_PORT] != nil
				it {should have_named_port google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::NAMED_PORT]}
			end
		end

		context 'When validating Google Compute Instance Group Manager version' do
			if google_compute_instance_group_manager_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::VERSION) and google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::VERSION] != nil
				it {should have_version google_compute_instance_group_manager_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR::VERSION]}
			end
		end

      end

    end
  }

end