module GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER_ATTR
	BASE_INSTANCE_NAME="base_instance_name"
	VERSION="version"
	NAME="name"
	ZONE="zone"
	DESCRIPTION="description"
	NAMED_PORT="named_port"
	TARGET_SIZE="target_size"
	TARGET_POOLS="target_pools"
	AUTO_HEALING_POLICIES="auto_healing_policies"
	STATEFUL_DISK="stateful_disk"
	UPDATE_POLICY="update_policy"
 end