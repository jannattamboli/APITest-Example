require 'spec_helper'
require 'ResourceType'
require_relative '../../spec_classes/google_compute_network'
require_relative 'google_compute_network_attributes'

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_compute_network"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_COMPUTE_NETWORK)

if list_of_gcp_resource != nil

  list_of_gcp_resource.each {|name, value|

    puts "#{name} : #{value}"
    google_compute_network_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_COMPUTE_NETWORK, name)
	puts "google_compute_network attributes : #{google_compute_network_attributes}"
	

	if google_compute_network_attributes != nil
		project = ENV['PROJECT']
		if project.nil? || project.empty? 
			fail "Project name can not be null or empty."
		end
      
      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_compute_network : #{name}"
      puts "--------------------------------------------"

      describe hcap_google_compute_network(project,value) do
		context "When validating existance of Google Compute Network : #{name}" do
            it {should exist}
        end
		if google_compute_network_attributes.has_key?(GOOGLE_COMPUTE_NETWORK_ATTR::NAME) and google_compute_network_attributes[GOOGLE_COMPUTE_NETWORK_ATTR::NAME] != nil
			its(:name) { should eq value(google_compute_network_attributes[GOOGLE_COMPUTE_NETWORK_ATTR::NAME]) }
		end
		if google_compute_network_attributes.has_key?(GOOGLE_COMPUTE_NETWORK_ATTR::AUTO_CREATE_SUBNETWORKS) and google_compute_network_attributes[GOOGLE_COMPUTE_NETWORK_ATTR::AUTO_CREATE_SUBNETWORKS] != nil
			its(:auto_create_subnetworks) { should eq value(google_compute_network_attributes[GOOGLE_COMPUTE_NETWORK_ATTR::AUTO_CREATE_SUBNETWORKS]) }
		end
		if google_compute_network_attributes.has_key?(GOOGLE_COMPUTE_NETWORK_ATTR::PROJECT) and google_compute_network_attributes[GOOGLE_COMPUTE_NETWORK_ATTR::PROJECT] != nil
			its(:project) { should eq value(google_compute_network_attributes[GOOGLE_COMPUTE_NETWORK_ATTR::PROJECT]) }
		end

		if google_compute_network_attributes.has_key?(GOOGLE_COMPUTE_NETWORK_ATTR::ROUTING_MODE ) and google_compute_network_attributes[GOOGLE_COMPUTE_NETWORK_ATTR::ROUTING_MODE ] != nil
			its(:routing_mode ) { should eq value(google_compute_network_attributes[GOOGLE_COMPUTE_NETWORK_ATTR::ROUTING_MODE ]) }
		end
		if google_compute_network_attributes.has_key?(GOOGLE_COMPUTE_NETWORK_ATTR::MTU) and google_compute_network_attributes[GOOGLE_COMPUTE_NETWORK_ATTR::MTU] != nil
			its(:mtu) { should eq value(google_compute_network_attributes[GOOGLE_COMPUTE_NETWORK_ATTR::MTU]) }
		end

      end

    end
  }

end
