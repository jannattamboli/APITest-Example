module GOOGLE_COMPUTE_NETWORK_ATTR
	NAME="name"
	PROJECT="project"
	AUTO_CREATE_SUBNETWORKS="auto_create_subnetworks"
	ROUTING_MODE ="routing_mode "
	MTU="mtu"
 end