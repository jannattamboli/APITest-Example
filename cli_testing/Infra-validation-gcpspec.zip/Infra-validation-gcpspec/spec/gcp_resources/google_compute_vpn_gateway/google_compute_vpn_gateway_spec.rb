require 'spec_helper'
require 'ResourceType'
require_relative '../../spec_classes/google_compute_vpn_gateway'
require_relative 'google_compute_vpn_gateway_attributes'

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_compute_vpn_gateway"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_COMPUTE_VPN_GATEWAY)

if list_of_gcp_resource != nil

  list_of_gcp_resource.each {|name, value|

    puts "#{name} : #{value}"
    google_compute_vpn_gateway_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_COMPUTE_VPN_GATEWAY, name)
    puts "google_compute_vpn_gateway attributes : #{google_compute_vpn_gateway_attributes}"

	if google_compute_vpn_gateway_attributes != nil 
		
		region = google_compute_vpn_gateway_attributes[GOOGLE_COMPUTE_VPN_GATEWAY_ATTR::REGION]
      
      if region.nil? || region.empty? 
        fail "region name can not be null or empty."
      end

		
		project = ENV['PROJECT']
		if project.nil? || project.empty? 
			fail "Project name can not be null or empty."
		end
      

      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_compute_vpn_gateway : #{name}"
      puts "--------------------------------------------"

	  describe hcap_google_compute_vpn_gateway(project,region,value) do
		
		context "When validating existance of Google Compute Vpn Gateway : #{name}" do
			it {should exist}
		end

		if google_compute_vpn_gateway_attributes.has_key?(GOOGLE_COMPUTE_VPN_GATEWAY_ATTR::NAME) and google_compute_vpn_gateway_attributes[GOOGLE_COMPUTE_VPN_GATEWAY_ATTR::NAME] != nil
			its(:name) { should eq value(google_compute_vpn_gateway_attributes[GOOGLE_COMPUTE_VPN_GATEWAY_ATTR::NAME]) }
		end
		if google_compute_vpn_gateway_attributes.has_key?(GOOGLE_COMPUTE_VPN_GATEWAY_ATTR::DESCRIPTION) and google_compute_vpn_gateway_attributes[GOOGLE_COMPUTE_VPN_GATEWAY_ATTR::DESCRIPTION] != nil
			its(:description) { should eq value(google_compute_vpn_gateway_attributes[GOOGLE_COMPUTE_VPN_GATEWAY_ATTR::DESCRIPTION]) }
		end
		if google_compute_vpn_gateway_attributes.has_key?(GOOGLE_COMPUTE_VPN_GATEWAY_ATTR::PROJECT) and google_compute_vpn_gateway_attributes[GOOGLE_COMPUTE_VPN_GATEWAY_ATTR::PROJECT] != nil
			its(:project) { should eq value(google_compute_vpn_gateway_attributes[GOOGLE_COMPUTE_VPN_GATEWAY_ATTR::PROJECT]) }
		end
		if google_compute_vpn_gateway_attributes.has_key?(GOOGLE_COMPUTE_VPN_GATEWAY_ATTR::NETWORK) and google_compute_vpn_gateway_attributes[GOOGLE_COMPUTE_VPN_GATEWAY_ATTR::NETWORK] != nil
			its(:network) { should eq value(google_compute_vpn_gateway_attributes[GOOGLE_COMPUTE_VPN_GATEWAY_ATTR::NETWORK]) }
		end
      end

    end
  }

end