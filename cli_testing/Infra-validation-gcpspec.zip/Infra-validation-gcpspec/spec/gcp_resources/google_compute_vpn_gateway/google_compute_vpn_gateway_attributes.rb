module GOOGLE_COMPUTE_VPN_GATEWAY_ATTR
	NAME="name"
	DESCRIPTION="description"
	REGION="region"
	PROJECT="project"
	NETWORK="network"
 end