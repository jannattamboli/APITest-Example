require 'spec_helper'
require 'ResourceType'
require_relative '../../spec_classes/google_compute_machine_image'
require_relative 'google_compute_machine_image_attributes'

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_compute_machine_image"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_COMPUTE_MACHINE_IMAGE)

if list_of_gcp_resource != nil

  list_of_gcp_resource.each {|name, value|

    puts "#{name} : #{value}"
    google_compute_machine_image_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_COMPUTE_MACHINE_IMAGE, name)
    puts "google_compute_machine_image attributes : #{google_compute_machine_image_attributes}"

    if google_compute_machine_image_attributes != nil

    	project = project = ENV['PROJECT']
      
      	if project.nil? || project.empty? 
        	fail "Project name can not be null or empty."
      	end


      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_compute_machine_image : #{value}"
      puts "--------------------------------------------"

      describe hcap_google_compute_machine_image(project,value) do
         context "When validating existance of google_compute_machine_image [#{value}]" do
          it {should exist}
        end

		if google_compute_machine_image_attributes.has_key?(GOOGLE_COMPUTE_MACHINE_IMAGE_ATTR::NAME) and google_compute_machine_image_attributes[GOOGLE_COMPUTE_MACHINE_IMAGE_ATTR::NAME] != nil
			its(:name) { should eq value(google_compute_machine_image_attributes[GOOGLE_COMPUTE_MACHINE_IMAGE_ATTR::NAME]) }
    end
    if google_compute_machine_image_attributes.has_key?(GOOGLE_COMPUTE_MACHINE_IMAGE_ATTR::PROJECT) and google_compute_machine_image_attributes[GOOGLE_COMPUTE_MACHINE_IMAGE_ATTR::PROJECT] != nil
			its(:project) { should eq value(google_compute_machine_image_attributes[GOOGLE_COMPUTE_MACHINE_IMAGE_ATTR::PROJECT]) }
		end
		if google_compute_machine_image_attributes.has_key?(GOOGLE_COMPUTE_MACHINE_IMAGE_ATTR::SOURCE_INSTANCE) and google_compute_machine_image_attributes[GOOGLE_COMPUTE_MACHINE_IMAGE_ATTR::SOURCE_INSTANCE] != nil
			its(:source_instance) { should eq value(google_compute_machine_image_attributes[GOOGLE_COMPUTE_MACHINE_IMAGE_ATTR::SOURCE_INSTANCE]) }
		end
		if google_compute_machine_image_attributes.has_key?(GOOGLE_COMPUTE_MACHINE_IMAGE_ATTR::DESCRIPTION) and google_compute_machine_image_attributes[GOOGLE_COMPUTE_MACHINE_IMAGE_ATTR::DESCRIPTION] != nil
			its(:description) { should eq value(google_compute_machine_image_attributes[GOOGLE_COMPUTE_MACHINE_IMAGE_ATTR::DESCRIPTION]) }
		end
		if google_compute_machine_image_attributes.has_key?(GOOGLE_COMPUTE_MACHINE_IMAGE_ATTR::GUEST_FLUSH) and google_compute_machine_image_attributes[GOOGLE_COMPUTE_MACHINE_IMAGE_ATTR::GUEST_FLUSH] != nil
			its(:guest_flush) { should eq value(google_compute_machine_image_attributes[GOOGLE_COMPUTE_MACHINE_IMAGE_ATTR::GUEST_FLUSH]) }
		end
    context 'When validating google_compute_machine_image machine_image_encryption_key' do
            if google_compute_machine_image_attributes.has_key?(GOOGLE_COMPUTE_MACHINE_IMAGE_ATTR::MACHINE_IMAGE_ENCRYPTION_KEY) and google_compute_machine_image_attributes[GOOGLE_COMPUTE_MACHINE_IMAGE_ATTR::MACHINE_IMAGE_ENCRYPTION_KEY] != nil
                google_compute_machine_image_attributes[GOOGLE_COMPUTE_MACHINE_IMAGE_ATTR::MACHINE_IMAGE_ENCRYPTION_KEY].each {|key, value|
                it {should have_machine_image_encryption_key(key, value(value))}
                }
            end
            end
      end

    end
  }

end