module GOOGLE_COMPUTE_MACHINE_IMAGE_ATTR
	NAME="name"
	PROJECT="project"
	SOURCE_INSTANCE="source_instance"
	DESCRIPTION="description"
	GUEST_FLUSH="guest_flush"
	MACHINE_IMAGE_ENCRYPTION_KEY="machine_image_encryption_key"
 end