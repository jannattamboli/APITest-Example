module GOOGLE_COMPUTE_SSL_CERTIFICATE_ATTR
	NAME="name"
	DESCRIPTION="description"
	CERTIFICATE="certificate"
	PRIVATE_KEY="private_key"
 end