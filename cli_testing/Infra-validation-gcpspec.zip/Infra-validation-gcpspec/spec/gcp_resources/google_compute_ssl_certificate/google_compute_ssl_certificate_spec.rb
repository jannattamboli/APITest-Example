require 'spec_helper'
require 'ResourceType'
require_relative '../../spec_classes/google_compute_ssl_certificate'
require_relative 'google_compute_ssl_certificate_attributes'

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_compute_ssl_certificate"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_COMPUTE_SSL_CERTIFICATE)

if list_of_gcp_resource != nil

  list_of_gcp_resource.each {|name, value|

    puts "#{name} : #{value}"
    google_compute_ssl_certificate_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_COMPUTE_SSL_CERTIFICATE, name)
    puts "google_compute_ssl_certificate attributes : #{google_compute_ssl_certificate_attributes}"

    if google_compute_ssl_certificate_attributes != nil

      project = project = ENV['PROJECT']
      
      if project.nil? || project.empty? 
        fail "Project name cannot be null or empty."
      end

      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_compute_ssl_certificate : #{value}"
      puts "--------------------------------------------"

      describe hcap_google_compute_ssl_certificate(project,value) do
         context "When validating existance of google_compute_ssl_certificate [#{value}]" do
          it {should exist}
         end

		if google_compute_ssl_certificate_attributes.has_key?(GOOGLE_COMPUTE_SSL_CERTIFICATE_ATTR::NAME) and google_compute_ssl_certificate_attributes[GOOGLE_COMPUTE_SSL_CERTIFICATE_ATTR::NAME] != nil
			its(:name) { should eq value(google_compute_ssl_certificate_attributes[GOOGLE_COMPUTE_SSL_CERTIFICATE_ATTR::NAME]) }
		end
		if google_compute_ssl_certificate_attributes.has_key?(GOOGLE_COMPUTE_SSL_CERTIFICATE_ATTR::DESCRIPTION) and google_compute_ssl_certificate_attributes[GOOGLE_COMPUTE_SSL_CERTIFICATE_ATTR::DESCRIPTION] != nil
			its(:description) { should eq value(google_compute_ssl_certificate_attributes[GOOGLE_COMPUTE_SSL_CERTIFICATE_ATTR::DESCRIPTION]) }
		end
		if google_compute_ssl_certificate_attributes.has_key?(GOOGLE_COMPUTE_SSL_CERTIFICATE_ATTR::CERTIFICATE) and google_compute_ssl_certificate_attributes[GOOGLE_COMPUTE_SSL_CERTIFICATE_ATTR::CERTIFICATE] != nil
			its(:certificate) { should eq value(google_compute_ssl_certificate_attributes[GOOGLE_COMPUTE_SSL_CERTIFICATE_ATTR::CERTIFICATE]) }
		end
      end

    end
  }

end