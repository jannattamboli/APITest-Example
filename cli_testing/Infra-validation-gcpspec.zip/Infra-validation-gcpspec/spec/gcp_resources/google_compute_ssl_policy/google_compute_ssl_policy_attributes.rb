module GOOGLE_COMPUTE_SSL_POLICY_ATTR
	NAME="name"
	DESCRIPTION="description"
	PROFILE="profile"
	MIN_TLS_VERSION="min_tls_version"
	CUSTOM_FEATURES="custom_features"
 end