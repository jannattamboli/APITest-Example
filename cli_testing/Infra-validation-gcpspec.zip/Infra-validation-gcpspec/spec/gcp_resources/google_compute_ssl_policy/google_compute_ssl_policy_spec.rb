require 'spec_helper'
require 'ResourceType'
require_relative '../../spec_classes/google_compute_ssl_policy'
require_relative 'google_compute_ssl_policy_attributes'

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_compute_ssl_policy"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_COMPUTE_SSL_POLICY)

if list_of_gcp_resource != nil

  list_of_gcp_resource.each {|name, value|

    puts "#{name} : #{value}"
    google_compute_ssl_policy_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_COMPUTE_SSL_POLICY, name)
    puts "google_compute_ssl_policy attributes : #{google_compute_ssl_policy_attributes}"

    if google_compute_ssl_policy_attributes != nil 
      project = project = ENV['PROJECT']
      
      if project.nil? || project.empty? 
        fail "Project name cannot be null or empty."
      end

      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_compute_ssl_policy : #{value}"
      puts "--------------------------------------------"

      describe hcap_google_compute_ssl_policy(project,value) do
         context "When validating existance of google_compute_ssl_policy [#{value}]" do
          it {should exist}
         end

		if google_compute_ssl_policy_attributes.has_key?(GOOGLE_COMPUTE_SSL_POLICY_ATTR::NAME) and google_compute_ssl_policy_attributes[GOOGLE_COMPUTE_SSL_POLICY_ATTR::NAME] != nil
			its(:name) { should eq value(google_compute_ssl_policy_attributes[GOOGLE_COMPUTE_SSL_POLICY_ATTR::NAME]) }
		end
		if google_compute_ssl_policy_attributes.has_key?(GOOGLE_COMPUTE_SSL_POLICY_ATTR::DESCRIPTION) and google_compute_ssl_policy_attributes[GOOGLE_COMPUTE_SSL_POLICY_ATTR::DESCRIPTION] != nil
			its(:description) { should eq value(google_compute_ssl_policy_attributes[GOOGLE_COMPUTE_SSL_POLICY_ATTR::DESCRIPTION]) }
		end
		if google_compute_ssl_policy_attributes.has_key?(GOOGLE_COMPUTE_SSL_POLICY_ATTR::PROFILE) and google_compute_ssl_policy_attributes[GOOGLE_COMPUTE_SSL_POLICY_ATTR::PROFILE] != nil
			its(:profile) { should eq value(google_compute_ssl_policy_attributes[GOOGLE_COMPUTE_SSL_POLICY_ATTR::PROFILE]) }
		end
		if google_compute_ssl_policy_attributes.has_key?(GOOGLE_COMPUTE_SSL_POLICY_ATTR::MIN_TLS_VERSION) and google_compute_ssl_policy_attributes[GOOGLE_COMPUTE_SSL_POLICY_ATTR::MIN_TLS_VERSION] != nil
			its(:min_tls_version) { should eq value(google_compute_ssl_policy_attributes[GOOGLE_COMPUTE_SSL_POLICY_ATTR::MIN_TLS_VERSION]) }
		end
		if google_compute_ssl_policy_attributes.has_key?(GOOGLE_COMPUTE_SSL_POLICY_ATTR::CUSTOM_FEATURES) and google_compute_ssl_policy_attributes[GOOGLE_COMPUTE_SSL_POLICY_ATTR::CUSTOM_FEATURES] != nil
			its(:custom_features) { should eq value(google_compute_ssl_policy_attributes[GOOGLE_COMPUTE_SSL_POLICY_ATTR::CUSTOM_FEATURES]) }
		end
      end

    end
  }

end