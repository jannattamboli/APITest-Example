module GOOGLE_COMPUTE_TARGET_INSTANCE_ATTR
	NAME="name"
	DESCRIPTION="description"
	ZONE="zone"
	PROJECT="project"
	INSTANCE="instance"
	NAT_POLICY="nat_policy"
 end