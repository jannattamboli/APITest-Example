require 'spec_helper'
require 'ResourceType'
require_relative '../../spec_classes/google_storage_bucket'
require_relative 'google_storage_bucket_attributes'

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_storage_bucket"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_STORAGE_BUCKET)

if list_of_gcp_resource != nil

  list_of_gcp_resource.each {|name, value|

    puts "#{name} : #{value}"
    google_storage_bucket_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_STORAGE_BUCKET, name)
    puts "google_storage_bucket attributes : #{google_storage_bucket_attributes}"

	if google_storage_bucket_attributes != nil 
		
		project = ENV['GOOGLE_CLOUD_PROJECT']
		  
		  if project.nil? || project.empty? 
			fail "Project name can not be null or empty."
		  end

      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_storage_bucket : #{name}"
      puts "--------------------------------------------"

      describe hcap_google_storage_bucket(project,value) do

			context "When validating existance of google_storage_bucket [#{value}]" do
				it {should exist}
			end
		if google_storage_bucket_attributes.has_key?(GOOGLE_STORAGE_BUCKET_ATTR::NAME) and google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::NAME] != nil
			its(:name) { should eq value(google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::NAME]) }
		end
		if google_storage_bucket_attributes.has_key?(GOOGLE_STORAGE_BUCKET_ATTR::LOCATION) and google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::LOCATION] != nil
			its(:location) { should eq value(google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::LOCATION]) }
		end
		if google_storage_bucket_attributes.has_key?(GOOGLE_STORAGE_BUCKET_ATTR::PROJECT) and google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::PROJECT] != nil
			its(:project) { should eq value(google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::PROJECT]) }
		end
		if google_storage_bucket_attributes.has_key?(GOOGLE_STORAGE_BUCKET_ATTR::STORAGE_CLASS) and google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::STORAGE_CLASS] != nil
			its(:storage_class) { should eq value(google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::STORAGE_CLASS]) }
		end
		if google_storage_bucket_attributes.has_key?(GOOGLE_STORAGE_BUCKET_ATTR::BUCKET_POLICY_ONLY) and google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::BUCKET_POLICY_ONLY] != nil
			its(:bucket_policy_only) { should eq value(google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::BUCKET_POLICY_ONLY]) }
		end
		if google_storage_bucket_attributes.has_key?(GOOGLE_STORAGE_BUCKET_ATTR::UNIFORM_BUCKET_LEVEL_ACCESS) and google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::UNIFORM_BUCKET_LEVEL_ACCESS] != nil
			its(:uniform_bucket_level_access) { should eq value(google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::UNIFORM_BUCKET_LEVEL_ACCESS]) }
		end


		context 'validating website  for google storage bucket' do
			if google_storage_bucket_attributes.has_key?(GOOGLE_STORAGE_BUCKET_ATTR::WEBSITE) and google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::WEBSITE] != nil
				it { should have_website google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::WEBSITE]}
            end
		  end

		context 'validating logging ranges for google storage bucket' do
			if google_storage_bucket_attributes.has_key?(GOOGLE_STORAGE_BUCKET_ATTR::LOGGING) and google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::LOGGING] != nil
				it { should have_logging google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::LOGGING]}
            end
		  end

		context "When validating google_storage_bucket cors" do
			if google_storage_bucket_attributes.has_key?(GOOGLE_STORAGE_BUCKET_ATTR::CORS) and google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::CORS] != nil
				google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::CORS].each { |key, value|
				it { should have_cors(key,value,google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::CORS]) }
			  }
			end
		  end


		context 'validating versioning ranges for google storage bucket' do
			if google_storage_bucket_attributes.has_key?(GOOGLE_STORAGE_BUCKET_ATTR::VERSIONING) and google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::VERSIONING] != nil
				it { should have_versioning google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::VERSIONING]}
            end
		  end

		  context 'validating retention policy  for google storage bucket' do
			if google_storage_bucket_attributes.has_key?(GOOGLE_STORAGE_BUCKET_ATTR::RETENTION_POLICY) and google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::RETENTION_POLICY] != nil
				it { should have_retention_policy google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::RETENTION_POLICY]}
            end
		  end

		context "When validating google_storage_bucket lifecycle rule" do
			if google_storage_bucket_attributes.has_key?(GOOGLE_STORAGE_BUCKET_ATTR::LIFECYCLE_RULE) and google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::LIFECYCLE_RULE] != nil
				google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::LIFECYCLE_RULE].each { |key, value|
				it { should have_lifecycle_rule(key,value,google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::LIFECYCLE_RULE]) }
			  }
			end
		  end

		context "When validating google storage bucket labels" do
			if google_storage_bucket_attributes.has_key?(GOOGLE_STORAGE_BUCKET_ATTR::LABELS) and google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::LABELS] != nil
				google_storage_bucket_attributes[GOOGLE_STORAGE_BUCKET_ATTR::LABELS].each { |labelKey, labelValue|
				it { should have_labels(labelKey,labelValue) }
			  }
			end
		end 

      end

    end
  }

end