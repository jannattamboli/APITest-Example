require 'spec_helper'
require 'ResourceType'
require_relative '../../spec_classes/google_compute_disk'
require_relative 'google_compute_disk_attributes'

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_compute_disk"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_COMPUTE_DISK)

if list_of_gcp_resource != nil

  list_of_gcp_resource.each {|name, value|

    puts "#{name} : #{value}"
    google_compute_disk_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_COMPUTE_DISK, name)
    puts "google_compute_disk attributes : #{google_compute_disk_attributes}"

    if google_compute_disk_attributes != nil 

      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_compute_disk : #{value}"
      puts "--------------------------------------------"


      zone = google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::ZONE]
      
      if zone.nil? || zone.empty? 
        fail "Zone name can not be null or empty."
      end

      project = project = ENV['PROJECT']
      
      if project.nil? || project.empty? 
        fail "Project name can not be null or empty."
      end

      describe hcap_google_compute_disk(project,zone,value) do
      	context "When validating existance of google_compute_disk [#{value}]" do
          it {should exist}
        end
		if google_compute_disk_attributes.has_key?(GOOGLE_COMPUTE_DISK_ATTR::NAME) and google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::NAME] != nil
			its(:name) { should eq value(google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::NAME]) }
    end

    if google_compute_disk_attributes.has_key?(GOOGLE_COMPUTE_DISK_ATTR::PROJECT) and google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::PROJECT] != nil
			its(:project) { should eq value(google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::PROJECT]) }
    end
		if google_compute_disk_attributes.has_key?(GOOGLE_COMPUTE_DISK_ATTR::DESCRIPTION) and google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::DESCRIPTION] != nil
			its(:description) { should eq value(google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::DESCRIPTION]) }
		end
		if google_compute_disk_attributes.has_key?(GOOGLE_COMPUTE_DISK_ATTR::SIZE) and google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::SIZE] != nil
			its(:size) { should eq value(google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::SIZE]) }
		end
		if google_compute_disk_attributes.has_key?(GOOGLE_COMPUTE_DISK_ATTR::PHYSICAL_BLOCK_SIZE_BYTES) and google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::PHYSICAL_BLOCK_SIZE_BYTES] != nil
			its(:physical_block_size_bytes) { should eq value(google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::PHYSICAL_BLOCK_SIZE_BYTES]) }
		end
		if google_compute_disk_attributes.has_key?(GOOGLE_COMPUTE_DISK_ATTR::TYPE) and google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::TYPE] != nil
			its(:type) { should eq value(google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::TYPE]) }
		end
		if google_compute_disk_attributes.has_key?(GOOGLE_COMPUTE_DISK_ATTR::IMAGE) and google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::IMAGE] != nil
			its(:image) { should eq value(google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::IMAGE]) }
		end
		if google_compute_disk_attributes.has_key?(GOOGLE_COMPUTE_DISK_ATTR::ZONE) and google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::ZONE] != nil
			its(:zone) { should eq value(google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::ZONE]) }
		end
		if google_compute_disk_attributes.has_key?(GOOGLE_COMPUTE_DISK_ATTR::SNAPSHOT) and google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::SNAPSHOT] != nil
			its(:snapshot) { should eq value(google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::SNAPSHOT]) }
		end
    context 'When validating google_compute_disk source_snapshot_encryption_key' do
            if google_compute_disk_attributes.has_key?(GOOGLE_COMPUTE_DISK_ATTR::SOURCE_SNAPSHOT_ENCRYPTION_KEY) and google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::SOURCE_SNAPSHOT_ENCRYPTION_KEY] != nil
                google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::SOURCE_SNAPSHOT_ENCRYPTION_KEY].each {|key, value|
                it {should have_source_snapshot_encryption_key(key, value(value))}
                }
            end
            end
    context 'When validating google_compute_disk labels' do
            if google_compute_disk_attributes.has_key?(GOOGLE_COMPUTE_DISK_ATTR::SOURCE_IMAGE_ENCRYPTION_KEY) and google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::SOURCE_IMAGE_ENCRYPTION_KEY] != nil
                google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::SOURCE_IMAGE_ENCRYPTION_KEY].each {|key, value|
                it {should have_source_image_encryption_keyl(key, value(value))}
                }
            end
            end
		context 'When validating google_compute_disk labels' do
            if google_compute_disk_attributes.has_key?(GOOGLE_COMPUTE_DISK_ATTR::LABELS) and google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::LABELS] != nil
                google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::LABELS].each {|labelKey, labelValue|
                it {should have_label(labelKey, value(labelValue))}
                }
            end
            end
    context 'When validating google_compute_disk disk_encryption_key' do
            if google_compute_disk_attributes.has_key?(GOOGLE_COMPUTE_DISK_ATTR::DISK_ENCRYPTION_KEY) and google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::DISK_ENCRYPTION_KEY] != nil
                google_compute_disk_attributes[GOOGLE_COMPUTE_DISK_ATTR::DISK_ENCRYPTION_KEY].each {|key, value|
                it {should have_disk_encryption_key(key, value(value))}
                }
            end
            end
      end

    end
  }

end