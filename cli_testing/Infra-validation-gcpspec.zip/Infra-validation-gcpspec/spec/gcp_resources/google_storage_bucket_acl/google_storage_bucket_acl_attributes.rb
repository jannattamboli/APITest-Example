module GOOGLE_STORAGE_BUCKET_ACL_ATTR
	NAME="name"
	ROLE_ENTITY="role_entity"
	DEFAULT_ACL="default_acl"
 end