require 'spec_helper'
require 'ResourceType'
require_relative '../../spec_classes/google_storage_bucket_acl'
require_relative 'google_storage_bucket_acl_attributes'

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_storage_bucket_acl"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_STORAGE_BUCKET_ACL)

if list_of_gcp_resource != nil

  project = ENV['GOOGLE_CLOUD_PROJECT']
		  
  if project.nil? || project.empty? 
  fail "Project name can not be null or empty."
  end

  list_of_gcp_resource.each {|name, value|

    puts "#{name} : #{value}"
    google_storage_bucket_acl_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_STORAGE_BUCKET_ACL, name)
    puts "google_storage_bucket_acl attributes : #{google_storage_bucket_acl_attributes}"

    if google_storage_bucket_acl_attributes != nil 

      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_storage_bucket_acl : #{name}"
      puts "--------------------------------------------"

      describe hcap_google_storage_bucket_acl(project,value) do

        context "When validating existance of google_storage_bucket_acl [#{value}]" do
          it {should exist}
        end

		if google_storage_bucket_acl_attributes.has_key?(GOOGLE_STORAGE_BUCKET_ACL_ATTR::NAME) and google_storage_bucket_acl_attributes[GOOGLE_STORAGE_BUCKET_ACL_ATTR::NAME] != nil
			its(:name) { should eq value(google_storage_bucket_acl_attributes[GOOGLE_STORAGE_BUCKET_ACL_ATTR::NAME]) }
    end
    
    context 'validating role entity for google_storage_default_object_acl' do
      if google_storage_bucket_acl_attributes.has_key?(GOOGLE_STORAGE_BUCKET_ACL_ATTR::ROLE_ENTITY) and google_storage_bucket_acl_attributes[GOOGLE_STORAGE_BUCKET_ACL_ATTR::ROLE_ENTITY] != nil
				it { should have_role_entity google_storage_bucket_acl_attributes[GOOGLE_STORAGE_BUCKET_ACL_ATTR::ROLE_ENTITY]}
      end
    end

    context 'validating default  role entity for google_storage_default_object_acl' do
      if google_storage_bucket_acl_attributes.has_key?(GOOGLE_STORAGE_BUCKET_ACL_ATTR::DEFAULT_ACL) and google_storage_bucket_acl_attributes[GOOGLE_STORAGE_BUCKET_ACL_ATTR::DEFAULT_ACL] != nil
				it { should have_default_acl google_storage_bucket_acl_attributes[GOOGLE_STORAGE_BUCKET_ACL_ATTR::DEFAULT_ACL]}
      end
    end
 
  

  end


    end
  }

end