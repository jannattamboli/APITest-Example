require 'spec_helper'
require 'ResourceType'
require_relative '../../spec_classes/google_compute_instance_group'
require_relative 'google_compute_instance_group_attributes'

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_compute_instance_group"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_COMPUTE_INSTANCE_GROUP)

if list_of_gcp_resource != nil

  list_of_gcp_resource.each {|name, value|

    puts "#{name} : #{value}"
    google_compute_instance_group_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_COMPUTE_INSTANCE_GROUP, name)
    puts "google_compute_instance_group attributes : #{google_compute_instance_group_attributes}"

	if google_compute_instance_group_attributes != nil 
		
		zone = google_compute_instance_group_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_ATTR::ZONE]
      
      if zone.nil? || zone.empty? 
        fail "Zone name can not be null or empty."
      end

      project = ENV['PROJECT']
      
      if project.nil? || project.empty? 
        fail "Project name can not be null or empty."
	  end

      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_compute_instance_group : #{name}"
      puts "--------------------------------------------"

	  describe hcap_google_compute_instance_group(project,zone,value) do
		
		context "When validating existance of google_compute_group [#{name}]" do
				it {should exist}
			end

		if google_compute_instance_group_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_GROUP_ATTR::NAME) and google_compute_instance_group_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_ATTR::NAME] != nil
			its(:name) { should eq value(google_compute_instance_group_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_ATTR::NAME]) }
		end
		if google_compute_instance_group_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_GROUP_ATTR::DESCRIPTION) and google_compute_instance_group_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_ATTR::DESCRIPTION] != nil
			its(:description) { should eq value(google_compute_instance_group_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_ATTR::DESCRIPTION]) }
		end
		if google_compute_instance_group_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_GROUP_ATTR::PROJECT) and google_compute_instance_group_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_ATTR::PROJECT] != nil
			its(:project) { should eq value(google_compute_instance_group_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_ATTR::PROJECT]) }
		end
		if google_compute_instance_group_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_GROUP_ATTR::ZONE) and google_compute_instance_group_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_ATTR::ZONE] != nil
			its(:zone) { should eq value(google_compute_instance_group_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_ATTR::ZONE]) }
		end
		if google_compute_instance_group_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_GROUP_ATTR::NETWORK) and google_compute_instance_group_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_ATTR::NETWORK] != nil
			its(:network) { should eq value(google_compute_instance_group_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_ATTR::NETWORK]) }
		end
		
		context "When validating  Google Compute instance group named port" do
			named_port = google_compute_instance_group_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_ATTR::NAMED_PORT]
			if google_compute_instance_group_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_GROUP_ATTR::NAMED_PORT) and google_compute_instance_group_attributes[GOOGLE_COMPUTE_INSTANCE_GROUP_ATTR::NAMED_PORT] != nil
				named_port.each{ |sub|
				it { should have_named_port sub }
				}
			end
		end


      end

    end
  }

end