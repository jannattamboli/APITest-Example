module GOOGLE_COMPUTE_INSTANCE_GROUP_ATTR
	NAME="name"
	DESCRIPTION="description"
	PROJECT="project"
	ZONE="zone"
	NETWORK="network"
	NAMED_PORT="named_port"
 end