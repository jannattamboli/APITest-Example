require 'spec_helper'
require 'ResourceType'
require_relative '../../spec_classes/google_compute_snapshot'
require_relative 'google_compute_snapshot_attributes'

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_compute_snapshot"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_COMPUTE_SNAPSHOT)

if list_of_gcp_resource != nil

  list_of_gcp_resource.each {|name, value|

    puts "#{name} : #{value}"
    google_compute_snapshot_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_COMPUTE_SNAPSHOT, name)
    puts "google_compute_snapshot attributes : #{google_compute_snapshot_attributes}"

	if google_compute_snapshot_attributes != nil 
		
		project = ENV['PROJECT']
		  
		if project.nil? || project.empty? 
		  fail "Project name can not be null or empty."
		end

      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_compute_snapshot : #{name}"
      puts "--------------------------------------------"

	  describe hcap_google_compute_snapshot(project,value) do
		
			
		context "When validating existance of Google Compute snapshot : #{name}" do
			it {should exist}
		end

		if google_compute_snapshot_attributes.has_key?(GOOGLE_COMPUTE_SNAPSHOT_ATTR::NAME) and google_compute_snapshot_attributes[GOOGLE_COMPUTE_SNAPSHOT_ATTR::NAME] != nil
			its(:name) { should eq value(google_compute_snapshot_attributes[GOOGLE_COMPUTE_SNAPSHOT_ATTR::NAME]) }
		end
		if google_compute_snapshot_attributes.has_key?(GOOGLE_COMPUTE_SNAPSHOT_ATTR::DESCRIPTION) and google_compute_snapshot_attributes[GOOGLE_COMPUTE_SNAPSHOT_ATTR::DESCRIPTION] != nil
			its(:description) { should eq value(google_compute_snapshot_attributes[GOOGLE_COMPUTE_SNAPSHOT_ATTR::DESCRIPTION]) }
		end
		if google_compute_snapshot_attributes.has_key?(GOOGLE_COMPUTE_SNAPSHOT_ATTR::PROJECT) and google_compute_snapshot_attributes[GOOGLE_COMPUTE_SNAPSHOT_ATTR::PROJECT] != nil
			its(:project) { should eq value(google_compute_snapshot_attributes[GOOGLE_COMPUTE_SNAPSHOT_ATTR::PROJECT]) }
		end
		if google_compute_snapshot_attributes.has_key?(GOOGLE_COMPUTE_SNAPSHOT_ATTR::SOURCE_DISK) and google_compute_snapshot_attributes[GOOGLE_COMPUTE_SNAPSHOT_ATTR::SOURCE_DISK] != nil
			its(:source_disk) { should eq value(google_compute_snapshot_attributes[GOOGLE_COMPUTE_SNAPSHOT_ATTR::SOURCE_DISK]) }
		end

		context "When validating storage locations for google compute snapshot" do
			if google_compute_snapshot_attributes.has_key?(GOOGLE_COMPUTE_SNAPSHOT_ATTR::STORAGE_LOCATIONS) and google_compute_snapshot_attributes[GOOGLE_COMPUTE_SNAPSHOT_ATTR::STORAGE_LOCATIONS] != nil
				it { should have_storage_locations google_compute_snapshot_attributes[GOOGLE_COMPUTE_SNAPSHOT_ATTR::STORAGE_LOCATIONS] }
			end
		  end


		context "When validating google storage bucket labels" do
			if google_compute_snapshot_attributes.has_key?(GOOGLE_COMPUTE_SNAPSHOT_ATTR::LABELS) and google_compute_snapshot_attributes[GOOGLE_COMPUTE_SNAPSHOT_ATTR::LABELS] != nil
				google_compute_snapshot_attributes[GOOGLE_COMPUTE_SNAPSHOT_ATTR::LABELS].each { |labelKey, labelValue|
				it { should have_labels(labelKey,labelValue) }
			  }
			end
		end 


      end

    end
  }

end