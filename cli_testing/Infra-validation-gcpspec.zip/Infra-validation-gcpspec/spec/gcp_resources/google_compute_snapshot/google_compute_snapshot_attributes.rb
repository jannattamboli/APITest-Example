module GOOGLE_COMPUTE_SNAPSHOT_ATTR
	NAME="name"
	DESCRIPTION="description"
	PROJECT="project"
	SOURCE_DISK="source_disk"
	STORAGE_LOCATIONS="storage_locations"
	LABELS="labels"
 end