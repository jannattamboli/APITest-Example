require 'spec_helper'
require 'ResourceType'
require_relative '../../spec_classes/google_compute_autoscaler'
require_relative 'google_compute_autoscaler_attributes'

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_compute_autoscaler"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_COMPUTE_AUTOSCALER)

if list_of_gcp_resource != nil

  list_of_gcp_resource.each {|name, value|

    puts "#{name} : #{value}"
    google_compute_autoscaler_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_COMPUTE_AUTOSCALER, name)
    puts "google_compute_autoscaler attributes : #{google_compute_autoscaler_attributes}"

    if google_compute_autoscaler_attributes != nil 
    	zone = google_compute_autoscaler_attributes[GOOGLE_COMPUTE_AUTOSCALER_ATTR::ZONE]
      
      if zone.nil? || zone.empty? 
        fail "Zone name can not be null or empty."
      end

      project = ENV['PROJECT']
      
      if project.nil? || project.empty? 
        fail "Project name can not be null or empty."
	  end
      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_compute_autoscaler : #{value}"
      puts "--------------------------------------------"

      describe hcap_google_compute_autoscaler(project,zone,value) do
         context "When validating existance of google_compute_autoscaler [#{value}]" do
          it {should exist}
         end

		if google_compute_autoscaler_attributes.has_key?(GOOGLE_COMPUTE_AUTOSCALER_ATTR::NAME) and google_compute_autoscaler_attributes[GOOGLE_COMPUTE_AUTOSCALER_ATTR::NAME] != nil
			its(:name) { should eq value(google_compute_autoscaler_attributes[GOOGLE_COMPUTE_AUTOSCALER_ATTR::NAME]) }
		end
		if google_compute_autoscaler_attributes.has_key?(GOOGLE_COMPUTE_AUTOSCALER_ATTR::TARGET) and google_compute_autoscaler_attributes[GOOGLE_COMPUTE_AUTOSCALER_ATTR::TARGET] != nil
			its(:target) { should eq value(google_compute_autoscaler_attributes[GOOGLE_COMPUTE_AUTOSCALER_ATTR::TARGET]) }
		end
		if google_compute_autoscaler_attributes.has_key?(GOOGLE_COMPUTE_AUTOSCALER_ATTR::DESCRIPTION) and google_compute_autoscaler_attributes[GOOGLE_COMPUTE_AUTOSCALER_ATTR::DESCRIPTION] != nil
			its(:description) { should eq value(google_compute_autoscaler_attributes[GOOGLE_COMPUTE_AUTOSCALER_ATTR::DESCRIPTION]) }
		end
		if google_compute_autoscaler_attributes.has_key?(GOOGLE_COMPUTE_AUTOSCALER_ATTR::ZONE) and google_compute_autoscaler_attributes[GOOGLE_COMPUTE_AUTOSCALER_ATTR::ZONE] != nil
			its(:zone) { should eq value(google_compute_autoscaler_attributes[GOOGLE_COMPUTE_AUTOSCALER_ATTR::ZONE]) }
		end
		context 'When validating google_compute_autoscaler autoscaling_policy' do
            if google_compute_autoscaler_attributes.has_key?(GOOGLE_COMPUTE_AUTOSCALER_ATTR::AUTOSCALING_POLICY) and google_compute_autoscaler_attributes[GOOGLE_COMPUTE_AUTOSCALER_ATTR::AUTOSCALING_POLICY] != nil
                google_compute_autoscaler_attributes[GOOGLE_COMPUTE_AUTOSCALER_ATTR::AUTOSCALING_POLICY].each {|key, value|
                it {should have_autoscaling_policy(key, value(value))}
                }
            end
        end
      end

    end
  }

end