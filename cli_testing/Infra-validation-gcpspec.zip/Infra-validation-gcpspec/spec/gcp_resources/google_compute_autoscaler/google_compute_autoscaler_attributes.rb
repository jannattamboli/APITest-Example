module GOOGLE_COMPUTE_AUTOSCALER_ATTR
	NAME="name"
	TARGET="target"
	AUTOSCALING_POLICY="autoscaling_policy"
	DESCRIPTION="description"
	ZONE="zone"
 end