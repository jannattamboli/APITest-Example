module GOOGLE_COMPUTE_ROUTE_ATTR
	NAME="name"
	DEST_RANGE="dest_range"
	NETWORK="network"
	DESCRIPTION="description"
	PRIORITY="priority"
	NEXT_HOP_GATEWAY="next_hop_gateway"
	NEXT_HOP_INSTANCE="next_hop_instance"
	NEXT_HOP_IP="next_hop_ip"
	NEXT_HOP_VPN_TUNNEL="next_hop_vpn_tunnel"
	NEXT_HOP_ILB="next_hop_ilb"
	PROJECT="project"
	TAGS="tags"
 end