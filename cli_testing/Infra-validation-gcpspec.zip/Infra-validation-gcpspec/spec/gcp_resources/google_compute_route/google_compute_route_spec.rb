require 'spec_helper'
require 'ResourceType'
require_relative '../../spec_classes/google_compute_route'
require_relative 'google_compute_route_attributes'

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_compute_route"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_COMPUTE_ROUTE)

if list_of_gcp_resource != nil

  list_of_gcp_resource.each {|name, value|

    puts "#{name} : #{value}"
    google_compute_route_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_COMPUTE_ROUTE, name)
    puts "google_compute_route attributes : #{google_compute_route_attributes}"

    if google_compute_route_attributes != nil 
    	project = ENV['PROJECT']
		if project.nil? || project.empty? 
			fail "Project name cannot be null or empty."
		end
      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_compute_route : #{value}"
      puts "--------------------------------------------"

      describe hcap_google_compute_route(project,value) do
         context "When validating existance of google_compute_route [#{value}]" do
          it {should exist}
         end

		if google_compute_route_attributes.has_key?(GOOGLE_COMPUTE_ROUTE_ATTR::NAME) and google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::NAME] != nil
			its(:name) { should eq value(google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::NAME]) }
		end
		if google_compute_route_attributes.has_key?(GOOGLE_COMPUTE_ROUTE_ATTR::DEST_RANGE) and google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::DEST_RANGE] != nil
			its(:dest_range) { should eq value(google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::DEST_RANGE]) }
		end
		if google_compute_route_attributes.has_key?(GOOGLE_COMPUTE_ROUTE_ATTR::NETWORK) and google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::NETWORK] != nil
			its(:network) { should eq value(google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::NETWORK]) }
		end
		if google_compute_route_attributes.has_key?(GOOGLE_COMPUTE_ROUTE_ATTR::DESCRIPTION) and google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::DESCRIPTION] != nil
			its(:description) { should eq value(google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::DESCRIPTION]) }
		end
		if google_compute_route_attributes.has_key?(GOOGLE_COMPUTE_ROUTE_ATTR::PRIORITY) and google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::PRIORITY] != nil
			its(:priority) { should eq value(google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::PRIORITY]) }
		end
		if google_compute_route_attributes.has_key?(GOOGLE_COMPUTE_ROUTE_ATTR::NEXT_HOP_GATEWAY) and google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::NEXT_HOP_GATEWAY] != nil
			its(:next_hop_gateway) { should eq value(google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::NEXT_HOP_GATEWAY]) }
		end
		if google_compute_route_attributes.has_key?(GOOGLE_COMPUTE_ROUTE_ATTR::NEXT_HOP_INSTANCE) and google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::NEXT_HOP_INSTANCE] != nil
			its(:next_hop_instance) { should eq value(google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::NEXT_HOP_INSTANCE]) }
		end
		if google_compute_route_attributes.has_key?(GOOGLE_COMPUTE_ROUTE_ATTR::NEXT_HOP_IP) and google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::NEXT_HOP_IP] != nil
			its(:next_hop_ip) { should eq value(google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::NEXT_HOP_IP]) }
		end
		if google_compute_route_attributes.has_key?(GOOGLE_COMPUTE_ROUTE_ATTR::NEXT_HOP_VPN_TUNNEL) and google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::NEXT_HOP_VPN_TUNNEL] != nil
			its(:next_hop_vpn_tunnel) { should eq value(google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::NEXT_HOP_VPN_TUNNEL]) }
		end
		if google_compute_route_attributes.has_key?(GOOGLE_COMPUTE_ROUTE_ATTR::NEXT_HOP_ILB) and google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::NEXT_HOP_ILB] != nil
			its(:next_hop_ilb) { should eq value(google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::NEXT_HOP_ILB]) }
		end
		context 'validating tags for google compute route' do
			if google_compute_route_attributes.has_key?(GOOGLE_COMPUTE_ROUTE_ATTR::TAGS) and google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::TAGS] != nil
				it { should have_tags google_compute_route_attributes[GOOGLE_COMPUTE_ROUTE_ATTR::TAGS]}
            end
		end
      end

    end
  }

end