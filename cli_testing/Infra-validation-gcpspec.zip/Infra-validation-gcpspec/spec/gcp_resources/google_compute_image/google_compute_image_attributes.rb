module GOOGLE_COMPUTE_IMAGE_ATTR
	NAME="name"
	DESCRIPTION="description"
	LABELS="labels"
	DISK_SIZE_GB="disk_size_gb"
	FAMILY="family"
	GUEST_OS_FEATURES="guest_os_features"
	LICENSES="licenses"
	RAW_DISK="raw_disk"
	SOURCE_SNAPSHOT="source_snapshot"
	SOURCE_DISK="source_disk"
	SOURCE_IMAGE="source_image"
	PROJECT="project"
 end