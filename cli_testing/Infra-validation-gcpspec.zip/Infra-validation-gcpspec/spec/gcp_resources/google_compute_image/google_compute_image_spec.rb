require "spec_helper"
require "ResourceType"
require_relative "../../spec_classes/google_compute_image"
require_relative "google_compute_image_attributes"

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_compute_image"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_COMPUTE_IMAGE)

if list_of_gcp_resource != nil
  list_of_gcp_resource.each { |name, value|
    puts "#{name} : #{value}"
    google_compute_image_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_COMPUTE_IMAGE, name)
    puts "google_compute_image attributes : #{google_compute_image_attributes}"

    if google_compute_image_attributes != nil
      image_name = google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::NAME]

      if image_name.nil? || image_name.empty?
        fail "Image name can not be null or empty."
      end

      project = ENV["PROJECT"]
      if project.nil? || project.empty?
        fail "Project name can not be null or empty."
      end

      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_compute_image : #{value}"
      puts "--------------------------------------------"

      describe hcap_google_compute_image(project, image_name) do
        context "When validating existance of google_compute_image [#{value}]" do
          it { should exist }
        end

        if google_compute_image_attributes.has_key?(GOOGLE_COMPUTE_IMAGE_ATTR::NAME) and google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::NAME] != nil
          its(:name) { should eq value(google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::NAME]) }
        end
        if google_compute_image_attributes.has_key?(GOOGLE_COMPUTE_IMAGE_ATTR::DESCRIPTION) and google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::DESCRIPTION] != nil
          its(:description) { should eq value(google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::DESCRIPTION]) }
        end
        if google_compute_image_attributes.has_key?(GOOGLE_COMPUTE_IMAGE_ATTR::DISK_SIZE_GB) and google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::DISK_SIZE_GB] != nil
          its(:disk_size_gb) { should eq value(google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::DISK_SIZE_GB]) }
        end
        if google_compute_image_attributes.has_key?(GOOGLE_COMPUTE_IMAGE_ATTR::FAMILY) and google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::FAMILY] != nil
          its(:family) { should eq value(google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::FAMILY]) }
        end
        if google_compute_image_attributes.has_key?(GOOGLE_COMPUTE_IMAGE_ATTR::LICENSES) and google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::LICENSES] != nil
          its(:licenses) { should eq value(google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::LICENSES]) }
        end
        if google_compute_image_attributes.has_key?(GOOGLE_COMPUTE_IMAGE_ATTR::SOURCE_SNAPSHOT) and google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::SOURCE_SNAPSHOT] != nil
          its(:source_snapshot) { should eq value(google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::SOURCE_SNAPSHOT]) }
        end
        if google_compute_image_attributes.has_key?(GOOGLE_COMPUTE_IMAGE_ATTR::SOURCE_DISK) and google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::SOURCE_DISK] != nil
          its(:source_disk) { should eq value(google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::SOURCE_DISK]) }
        end
        if google_compute_image_attributes.has_key?(GOOGLE_COMPUTE_IMAGE_ATTR::SOURCE_IMAGE) and google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::SOURCE_IMAGE] != nil
          its(:source_image) { should eq value(google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::SOURCE_IMAGE]) }
        end
        context "When validating google_compute_image labels" do
          if google_compute_image_attributes.has_key?(GOOGLE_COMPUTE_IMAGE_ATTR::LABELS) and google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::LABELS] != nil
            google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::LABELS].each { |labelKey, labelValue|
              it { should have_labels(labelKey, value(labelValue)) }
            }
          end
        end
        context "When validating google_compute_image guest_os_features" do
          if google_compute_image_attributes.has_key?(GOOGLE_COMPUTE_IMAGE_ATTR::GUEST_OS_FEATURES) and google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::GUEST_OS_FEATURES] != nil
            it { should have_guest_os_features google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::GUEST_OS_FEATURES] }
          end
        end
        context "When validating google_compute_image raw_disk" do
          if google_compute_image_attributes.has_key?(GOOGLE_COMPUTE_IMAGE_ATTR::RAW_DISK) and google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::RAW_DISK] != nil
            it { should have_raw_disk google_compute_image_attributes[GOOGLE_COMPUTE_IMAGE_ATTR::RAW_DISK] }
          end
        end
      end
    end
  }
end
