require "spec_helper"
require "ResourceType"
require_relative "../../spec_classes/google_compute_instance_template"
require_relative "google_compute_instance_template_attributes"

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_compute_instance_template"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_COMPUTE_INSTANCE_TEMPLATE)

if list_of_gcp_resource != nil
  list_of_gcp_resource.each { |name, value|
    puts "#{name} : #{value}"
    google_compute_instance_template_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_COMPUTE_INSTANCE_TEMPLATE, name)
    puts "google_compute_instance_template attributes : #{google_compute_instance_template_attributes}"

    if google_compute_instance_template_attributes != nil
      temp_name = google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::NAME]

      if temp_name.nil? || temp_name.empty?
        fail "Template name can not be null or empty."
      end

      project = ENV["PROJECT"]
      if project.nil? || project.empty?
        fail "Project name can not be null or empty."
      end

      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_compute_instance_template : #{value}"
      puts "--------------------------------------------"

      describe hcap_google_compute_instance_template(project, temp_name) do
        context "When validating existance of google_compute_instance_template [#{value}]" do
          it { should exist }
        end

        if google_compute_instance_template_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::NAME) and google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::NAME] != nil
          its(:name) { should eq value(google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::NAME]) }
        end
        if google_compute_instance_template_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::CAN_IP_FORWARD) and google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::CAN_IP_FORWARD] != nil
          its(:can_ip_forward) { should eq value(google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::CAN_IP_FORWARD]) }
        end
        if google_compute_instance_template_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::INSTANCE_DESCRIPTION) and google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::INSTANCE_DESCRIPTION] != nil
          its(:instance_description) { should eq value(google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::INSTANCE_DESCRIPTION]) }
        end
        if google_compute_instance_template_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::DESCRIPTION) and google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::DESCRIPTION] != nil
          its(:description) { should eq value(google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::DESCRIPTION]) }
        end
        if google_compute_instance_template_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::MACHINE_TYPE) and google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::MACHINE_TYPE] != nil
          its(:machine_type) { should eq value(google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::MACHINE_TYPE]) }
        end
        if google_compute_instance_template_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::TAGS) and google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::TAGS] != nil
          its(:tags) { should eq value(google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::TAGS]) }
        end
        if google_compute_instance_template_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::MIN_CPU_PLATFORM) and google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::MIN_CPU_PLATFORM] != nil
          its(:min_cpu_platform) { should eq value(google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::MIN_CPU_PLATFORM]) }
        end
        context "When validating google_compute_instance_template labels" do
          if google_compute_instance_template_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::LABELS) and google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::LABELS] != nil
            google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::LABELS].each { |labelKey, labelValue|
              it { should have_label(labelKey, value(labelValue)) }
            }
          end
        end
        context "When validating google_compute_disk shielded_instance_config" do
          if google_compute_instance_template_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::SHIELDED_INSTANCE_CONFIG) and google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::SHIELDED_INSTANCE_CONFIG] != nil
            google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::SHIELDED_INSTANCE_CONFIG].each { |key, value|
              it { should have_shielded_instance_config(key, value(value)) }
            }
          end
        end
        context "When validating google_compute_disk service_account" do
          if google_compute_instance_template_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::SERVICE_ACCOUNT) and google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::SERVICE_ACCOUNT] != nil
            google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::SERVICE_ACCOUNT].each { |key, value|
              it { should have_service_account(key, value(value)) }
            }
          end
        end
        context "When validating google_compute_disk disk" do
          if google_compute_instance_template_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::DISK) and google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::DISK] != nil
            google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::DISK].each { |disk|
              disk.each { |key, value|
                it { should have_disk(key, value(value), disk["device_name"]) }
              }
            }
          end
        end
        context "When validating google_compute_disk scheduling" do
          if google_compute_instance_template_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::SCHEDULING) and google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::SCHEDULING] != nil
            google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::SCHEDULING].each { |key, value|
              it { should have_scheduling(key, value(value)) }
            }
          end
        end
        context "When validating google_compute_instance_template metadata" do
          if google_compute_instance_template_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::METADATA) and google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::METADATA] != nil
            google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::METADATA].each { |labelKey, labelValue|
              it { should have_metadata(labelKey, value(labelValue)) }
            }
          end
        end
        context "When validating google_compute_disk network_interface" do
          if google_compute_instance_template_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::NETWORK_INTERFACE) and google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::NETWORK_INTERFACE] != nil
            google_compute_instance_template_attributes[GOOGLE_COMPUTE_INSTANCE_TEMPLATE_ATTR::NETWORK_INTERFACE].each { |network|
              network.each { |key, value|
                it { should have_network_interface(key, value(value), network["network"]) }
              }
            }
          end
        end
      end
    end
  }
end
