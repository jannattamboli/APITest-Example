require 'spec_helper'
require 'ResourceType'
require_relative '../../spec_classes/google_container_node_pool'
require_relative 'google_container_node_pool_attributes'

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_container_node_pool"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_CONTAINER_NODE_POOL)

if list_of_gcp_resource != nil

  list_of_gcp_resource.each {|name, value|

    puts "#{name} : #{value}"
    google_container_node_pool_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_CONTAINER_NODE_POOL, name)
    puts "google_container_node_pool attributes : #{google_container_node_pool_attributes}"

	if google_container_node_pool_attributes != nil 
		
		zone = google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::ZONE]
      
		if zone.nil? || zone.empty? 
		  fail "Zone name can not be null or empty."
		end

		cluster = google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::CLUSTER]
      
		if cluster.nil? || cluster.empty? 
		  fail "cluster name can not be null or empty."
		end
  
		  
		  project = ENV['PROJECT']
		  if project.nil? || project.empty? 
			  fail "Project name can not be null or empty."
		  end
		


      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_container_node_pool : #{name}"
      puts "--------------------------------------------"

      describe hcap_google_container_node_pool(project,zone,cluster,value) do


			context "When validating existance of Google container node pool: #{name}" do
				it {should exist}
			end

			if google_container_node_pool_attributes.has_key?(GOOGLE_CONTAINER_NODE_POOL_ATTR::NAME) and google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::NAME] != nil
				its(:name) { should eq value(google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::NAME]) }
			end

			if google_container_node_pool_attributes.has_key?(GOOGLE_CONTAINER_NODE_POOL_ATTR::PROJECT) and google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::PROJECT] != nil
				its(:project) { should eq value(google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::PROJECT]) }
			end
			if google_container_node_pool_attributes.has_key?(GOOGLE_CONTAINER_NODE_POOL_ATTR::INITIAL_NODE_COUNT) and google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::INITIAL_NODE_COUNT] != nil
				its(:initial_node_count) { should eq value(google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::INITIAL_NODE_COUNT]) }
			end

			if google_container_node_pool_attributes.has_key?(GOOGLE_CONTAINER_NODE_POOL_ATTR::MAX_PODS_PER_NODE) and google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::MAX_PODS_PER_NODE] != nil
				its(:max_pods_per_node) { should eq value(google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::MAX_PODS_PER_NODE]) }
			end

			context 'validating autoscaling for google container node pool' do
				if google_container_node_pool_attributes.has_key?(GOOGLE_CONTAINER_NODE_POOL_ATTR::AUTOSCALING) and google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::AUTOSCALING] != nil
					it { should have_autoscaling google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::AUTOSCALING]}
				end
			end

			context 'validating node locations  for google container node pool' do
				if google_container_node_pool_attributes.has_key?(GOOGLE_CONTAINER_NODE_POOL_ATTR::NODE_LOCATIONS ) and google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::NODE_LOCATIONS ] != nil
					it { should have_node_locations google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::NODE_LOCATIONS]}
				end
			end

			context "When validating management for google container node pool" do
				if google_container_node_pool_attributes.has_key?(GOOGLE_CONTAINER_NODE_POOL_ATTR::MANAGEMENT) and google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::MANAGEMENT] != nil
					it { should have_management google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::MANAGEMENT] }
				end
			  end

			  context "When validating upgrade setting for google container node pool" do
				if google_container_node_pool_attributes.has_key?(GOOGLE_CONTAINER_NODE_POOL_ATTR::UPGRADE_SETTINGS) and google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::UPGRADE_SETTINGS] != nil
					it { should have_upgrade_settings google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::UPGRADE_SETTINGS] }
				end
			  end

			if google_container_node_pool_attributes.has_key?(GOOGLE_CONTAINER_NODE_POOL_ATTR::VERSION) and google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::VERSION] != nil
				its(:version) { should eq value(google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::VERSION]) }
			end
			
			context 'When validating node_config for google container node pool' do
				if google_container_node_pool_attributes.has_key?(GOOGLE_CONTAINER_NODE_POOL_ATTR::NODE_CONFIG) and google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::NODE_CONFIG] != nil
					google_container_node_pool_attributes[GOOGLE_CONTAINER_NODE_POOL_ATTR::NODE_CONFIG].each {|key, value|
					it {should have_node_config(key, value(value))}
					}
				end
			end


      end

    end
  }

end