module GOOGLE_CONTAINER_NODE_POOL_ATTR
	CLUSTER="cluster"
	NAME="name"
	ZONE="zone"
	AUTOSCALING="autoscaling"
	PROJECT="project"
	INITIAL_NODE_COUNT="initial_node_count"
	MANAGEMENT="management"
	MAX_PODS_PER_NODE="max_pods_per_node"
	NODE_LOCATIONS ="node_locations "
	NODE_CONFIG="node_config"
	UPGRADE_SETTINGS="upgrade_settings"
	VERSION="version"
 end