require 'spec_helper'
require 'ResourceType'
require_relative '../../spec_classes/google_compute_instance'
require_relative 'google_compute_instance_attributes'

puts "-------------------------------------------"
puts "Executing gcp spec for resource - google_compute_instance"
puts "-------------------------------------------"

list_of_gcp_resource = getOutputHashByResourceType(ResourceType::GOOGLE_COMPUTE_INSTANCE)

if list_of_gcp_resource != nil

  list_of_gcp_resource.each {|name, value|

    puts "#{name} : #{value}"
    google_compute_instance_attributes = getAttributesByResourceTypeAndName(ResourceType::GOOGLE_COMPUTE_INSTANCE, name)
    puts "google_compute_instance attributes : #{google_compute_instance_attributes}"

    if google_compute_instance_attributes != nil 

		zone = google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::ZONE]
      
      if zone.nil? || zone.empty? 
        fail "Zone name can not be null or empty."
      end

      project = ENV['PROJECT']
      
      if project.nil? || project.empty? 
        fail "Project name can not be null or empty."
	  end
	  
      puts "--------------------------------------------"
      puts "Validating gcp spec for resource - google_compute_instance : #{name}"
      puts "--------------------------------------------"

		describe hcap_google_compute_instance(project,zone,value) do

			context "When validating existance of google_compute_instance [#{name}]" do
				it {should exist}
			end

			if google_compute_instance_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_ATTR::NAME) and google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::NAME] != nil
				its(:name) { should eq value(google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::NAME]) }
			end 
			if google_compute_instance_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_ATTR::PROJECT) and google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::PROJECT] != nil
				its(:project) { should eq value(google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::PROJECT]) }
			end
			if google_compute_instance_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_ATTR::MACHINE_TYPE) and google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::MACHINE_TYPE] != nil
				its(:machine_type) { should eq value(google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::MACHINE_TYPE]) }
			end
			if google_compute_instance_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_ATTR::DESIRED_STATUS) and google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::DESIRED_STATUS] != nil
				its(:desired_status) { should eq value(google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::DESIRED_STATUS]) }
			end
			if google_compute_instance_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_ATTR::DELETION_PROTECTION) and google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::DELETION_PROTECTION] != nil
				its(:deletion_protection) { should eq value(google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::DELETION_PROTECTION]) }
			end
			if google_compute_instance_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_ATTR::CAN_IP_FORWARD) and google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::CAN_IP_FORWARD] != nil
				its(:can_ip_forward) { should eq value(google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::CAN_IP_FORWARD]) }
			end
			if google_compute_instance_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_ATTR::ENABLE_DISPLAY) and google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::ENABLE_DISPLAY] != nil
				its(:enable_display) { should eq value(google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::ENABLE_DISPLAY]) }
			end

			context 'When validating Google Compute instance  boot disk' do
				if google_compute_instance_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_ATTR::BOOT_DISK) and google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::BOOT_DISK] != nil
					it {should have_boot_disk google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::BOOT_DISK]}
				end
			end 

			context 'When validating Google Compute instance labels' do
				if google_compute_instance_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_ATTR::LABELS) and google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::LABELS] != nil
					google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::LABELS].each {|tagKey, tagValue|
					it {should have_labels(tagKey,tagValue)}
				}
				end
			end

			context 'When validating Google Compute instance  scheduling' do
				if google_compute_instance_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_ATTR::SCHEDULING) and google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::SCHEDULING] != nil
					it {should have_scheduling google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::SCHEDULING]}
				end
			end 

			context 'When validating Google Compute instance  shielded_instance_config' do
				if google_compute_instance_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_ATTR::SHIELDED_INSTANCE_CONFIG) and google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::SHIELDED_INSTANCE_CONFIG] != nil
					it {should have_shielded_instance_config google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::SHIELDED_INSTANCE_CONFIG]}
				end
			end 


			context 'When validating Google Compute instance  service account' do
				if google_compute_instance_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_ATTR::SERVICE_ACCOUNT) and google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::SERVICE_ACCOUNT] != nil
					it {should have_service_account google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::SERVICE_ACCOUNT]}
				end
			end 


			context "validating Google Compute instance tags" do
				tags = google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::TAGS]
				if google_compute_instance_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_ATTR::TAGS) and google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::TAGS] != nil
					tags.each{ |sub|
					it { should have_tags sub }
					}
				end
			end
			context "validating Google Compute instance nnetwork interface" do
				if google_compute_instance_attributes.has_key?(GOOGLE_COMPUTE_INSTANCE_ATTR::NETWORK_INTERFACE) and google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::NETWORK_INTERFACE] != nil
					it {should have_network_interface google_compute_instance_attributes[GOOGLE_COMPUTE_INSTANCE_ATTR::NETWORK_INTERFACE]}
				end
			end
	  end
	  

    end
  }

end