# Define all gcp resource types in this module
# Value must be same as resource types provided by terrafom
module ResourceType

    GOOGLE_COMPUTE_INSTANCE="google_compute_instance"
    GOOGLE_COMPUTE_DISK="google_compute_disk"
    GOOGLE_COMPUTE_MACHINE_IMAGE="google_compute_machine_image"
    GOOGLE_COMPUTE_NETWORK="google_compute_network"
    GOOGLE_COMPUTE_SUBNETWORK="google_compute_subnetwork"
    

	GOOGLE_COMPUTE_FIREWALL="google_compute_firewall"
	GOOGLE_COMPUTE_ROUTER="google_compute_router"
	GOOGLE_COMPUTE_INSTANCE_TEMPLATE="google_compute_instance_template"
	GOOGLE_COMPUTE_IMAGE="google_compute_image"
	GOOGLE_COMPUTE_ADDRESS="google_compute_address"
	GOOGLE_COMPUTE_ROUTER_NAT="google_compute_router_nat"
	GOOGLE_COMPUTE_AUTOSCALER="google_compute_autoscaler"
	GOOGLE_COMPUTE_INSTANCE_GROUP_MANAGER="google_compute_instance_group_manager"
	GOOGLE_STORAGE_BUCKET="google_storage_bucket"
	GOOGLE_STORAGE_DEFAULT_OBJECT_ACL="google_storage_default_object_acl"
	GOOGLE_STORAGE_BUCKET_ACL="google_storage_bucket_acl"
	GOOGLE_COMPUTE_VPN_GATEWAY="google_compute_vpn_gateway"
	GOOGLE_COMPUTE_TARGET_INSTANCE="google_compute_target_instance"
	GOOGLE_COMPUTE_ROUTE="google_compute_route"
	GOOGLE_COMPUTE_INSTANCE_GROUP="google_compute_instance_group"
	GOOGLE_COMPUTE_SSL_CERTIFICATE="google_compute_ssl_certificate"
	GOOGLE_COMPUTE_SSL_POLICY="google_compute_ssl_policy"
	GOOGLE_COMPUTE_TARGET_POOL="google_compute_target_pool"
	GOOGLE_COMPUTE_NODE_GROUP="google_compute_node_group"
	GOOGLE_COMPUTE_NETWORK_ENDPOINT_GROUP="google_compute_network_endpoint_group"
	GOOGLE_CONTAINER_NODE_POOL="google_container_node_pool"
	GOOGLE_COMPUTE_SNAPSHOT="google_compute_snapshot"
end