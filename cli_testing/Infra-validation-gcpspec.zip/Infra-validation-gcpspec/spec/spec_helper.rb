require 'rubygems'
require 'json'
require 'rspec/its'
path = File.expand_path('../../infraParam.json', __FILE__)
INPUT_OUTPUT  = File.read(path)
PARSED_JSON  = INPUT_OUTPUT && INPUT_OUTPUT.length >= 2 ? JSON.parse(INPUT_OUTPUT) : nil

if PARSED_JSON.to_s.empty?
 abort("infraParam json is nil or empty. Abrting execution...")
end

#puts "PARSED_JSON - #{PARSED_JSON}"

INPUT_JSON = PARSED_JSON['input']
#puts "INPUT_JSON - #{INPUT_JSON}"

OUTPUT_JSON = PARSED_JSON['output']
#puts "OUTPUT_JSON - #{OUTPUT_JSON}"

VARIABLE_JSON = PARSED_JSON['variables']
#puts "variables - #{VARIABLE_JSON}"

#@isVariablePresent = VARIABLE_JSON.is_a?(Hash)


#OUTPUT_JSON.each { |key, value| puts "#{key} : #{value}" }

#Methos to get output hash by resource type
def getOutputHashByResourceType(type)
	OUTPUT_JSON[type]
end

#Method is used to get attribute hash by resource name.
def getAttributesByResourceName(name)
	INPUT_JSON[name]
end

#Method is used to get attribute hash by resource category and resource name.
def getAttributesByResourceTypeAndName(type,name)
	_categoryJson = INPUT_JSON[type]
	if _categoryJson != nil
		_inputJson=_categoryJson[name]
	else
		_inputJson=INPUT_JSON[name]	
	end
	return _inputJson	
end

def getInputJson
	INPUT_JSON
end

#Method check if value is from input varibale. If it is then value is extracted from variable hash. 
def value(attrvalue)
  #puts "attribute value : #{attrvalue}"
  _value=attrvalue
  if attrvalue.is_a? String and attrvalue.include? "${var."
     #puts "variable is present"
     _value=VARIABLE_JSON[attrvalue[6..-2]]
  end
  #puts "value : #{_value}"
  return _value
end

def to_bool(str)
	return true if str.class.to_s == "TrueClass"
	return false if str.class.to_s == "FalseClass"
	return true if str =~ (/^(true|t|yes|y|1)$/i)
	return false if str.empty? || str =~ (/^(false|f|no|n|0)$/i)

	raise ArgumentError.new "invalid value: #{str}"
end

def compare_arr(a,b)
    a.size==b.size and a&b==a
end

def validate_have_value(tf_name, aws_name, aws_input,type="")
	if aws_input.has_key?(tf_name) and aws_input[tf_name] != nil
		it { should have_value aws_name, value(aws_input[tf_name]) , type }
	end
end

def pick_hash(id, hashArray, value)
	if id != nil && !id.empty? && hashArray != nil && !hashArray.empty?
		hashArray.each { |e|
			if( e[id] == value )
				return e
			end
		}
	end
	nil
end