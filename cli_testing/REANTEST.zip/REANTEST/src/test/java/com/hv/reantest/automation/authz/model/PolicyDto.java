package com.hv.reantest.automation.authz.model;

public class PolicyDto extends BaseDto{
	String name;

	String description;

	String resourceId;

	String resourceType;

	String rule;

	String effect;

	String denyErrorMessage;

	private String metadata;

	private boolean display = true;

	public String getEffect() {
		return effect;
	}

	public void setEffect(String effect) {
		this.effect = effect;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	public String getResourceType() {
		return resourceType;
	}

	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}

	public String getRule() {
		return rule;
	}

	public void setRule(String rule) {
		this.rule = rule;
	}

	public String getDenyErrorMessage() {
		return denyErrorMessage;
	}

	public void setDenyErrorMessage(String denyErrorMessage) {
		this.denyErrorMessage = denyErrorMessage;
	}

	public String getMetadata() {
		return metadata;
	}

	public void setMetadata(String metadata) {
		this.metadata = metadata;
	}

	public boolean isDisplay() {
		return display;
	}

	public void setDisplay(boolean display) {
		this.display = display;
	}

}
