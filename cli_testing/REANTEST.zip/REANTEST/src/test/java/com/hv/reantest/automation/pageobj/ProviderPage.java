package com.hv.reantest.automation.pageobj;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.hv.reantest.automation.DriverFactory;

@Component
@ConfigurationProperties(prefix = "providerpage")
public class ProviderPage extends AbstractPage {

	
	@Autowired
	DriverFactory driverFactory;
	
	@Autowired
	CommonPage commonpage;
	
	@Value("${com.hv.reantest.automation.infrasturcture.subnet_id")
	String subnetId;

	@Value("${com.hv.reantest.automation.infrasturcture.security_group_id")
	String securityGroupId;

	@Value("${com.hv.reantest.automation.infrasturcture.bucket_name")
	String bucketName;
	
	@Value("${com.hv.reantest.automation.infrasturcture.role_name")
	String roleName;
	
	@Value("${com.hv.reantest.automation.infrasturcture.instance_profile_arn")
	String InstanceProfileArn;
	
	@Value("${com.hv.reantest.automation.infrasturcture.key_pair_name")
    String keyPairName;
	
	@Value("${com.hv.reantest.automation.infrasturcture.private_key")
	String privateKey;

	public void fillAWSCredentialsProviderJson(String type) {
		
		editText("input_3", "Provider1");
		clickId("select_4");
		clickElementWithXPath("//md-option[@value='aws']");
		commonpage.selectProviderTypeAndFillDetails(type);
	}

	public void fillInfrastuctureDetials() {
		clickElementWithXPath("//md-pagination-wrapper/md-step-item[2]/md-step-label-wrapper/span[contains(text(),'INFRASTRUCTURE')]");
		editText("input_7", subnetId);
		editText("input_8", securityGroupId);
		editText("input_9", bucketName);
		editText("input_10", roleName);
		editText("input_11", keyPairName);
		editText("input_12", privateKey);
	}

	public void makeProviderDefault() {
		clickElementWithXPath("//div[@class='md-icon']/following::md-checkbox[@aria-label='Use As default Provider']");
	}

}
