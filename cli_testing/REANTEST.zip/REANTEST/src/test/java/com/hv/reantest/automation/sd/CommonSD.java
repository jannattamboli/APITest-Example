package com.hv.reantest.automation.sd;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.hv.reantest.automation.pageobj.CommonPage;
import com.hv.reantest.automation.pageobj.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class CommonSD {

	@Autowired
	CommonPage commonpage;
	
	@Autowired
	LoginPage loginpage;
	
	@Value("${com.hv.reantest.automation.authentication.admin_user}")
	String adminUser;
	
	@Value("${com.hv.reantest.automation.authentication.admin_password}")
	String adminPassword;
	
	@Value("${com.hv.reantest.automation.authentication.non_admin_user}")
	String nonAdminUser;
	
	@Value("${com.hv.reantest.automation.authentication.non_admin_password}")
	String nonAdminPassword;
	
	
	@Given("^User is at \"([^\"]*)\" dashboard page$")
	public void userIsAtReantestDashboardPage(String accelerator)  {
		loginpage.toPage();
		loginpage.login(nonAdminUser, nonAdminPassword);
		commonpage.navigateToAccelerator(accelerator);
	}
	
	@Given("^Admin is at \"([^\"]*)\" dashboard page$")
	public void adminIsAtReantestDashboardPage(String accelerator)  {
		loginpage.toPage();
		loginpage.login(adminUser, adminPassword);
		commonpage.navigateToAccelerator(accelerator);
	}
	
	@When("^User navigates to \"([^\"]*)\" page$")
	public void user_navigates_to_next_page(String label) throws Throwable {
		commonpage.navigateToTabs(label);
		System.out.println("in steps definition for next page ");
		}
	
	@When("^User navigate to \"([^\"]*)\"$")
	public void User_navigate_to_provider(String option) throws Throwable {
		commonpage.navigateToMoreOption(option);
	}
	
	@When("^User click on \"([^\"]*)\" button$")
	public void user_click_on_submit_button_to_save_provider(String label) throws Throwable {
		commonpage.navigateToTabs(label);
	}
	
	
}
