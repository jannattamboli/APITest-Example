/**
 * 
 */
package com.hv.reantest.automation.sd;

import java.util.List;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.hv.reantest.automation.TestApplication;
import com.hv.reantest.automation.pageobj.UserPage;

import cucumber.api.DataTable;
import cucumber.api.java.en.When;

/**
 * @author Rahul
 *
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = TestApplication.class)
@SpringBootTest
public class UserPageSD {

	@Autowired
	private UserPage userPage;

	@When("^create user if Not Exist$")
	public void create_user_if_not_exist(DataTable dataTable) throws Throwable {

		List<String> list = dataTable.raw().get(0);
		String userName = list.get(0);
		String userEmail = list.get(1);

		userPage.createUserIfNotExist(userName, userEmail);

	}

	@When("^Disable user: \\\"([^\\\"]*)\\\"$") 
	public void disable_user(String userName) {
		userPage.disableUser(userName);
	}
}