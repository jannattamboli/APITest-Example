/**
 * 
 */
package com.hv.reantest.automation.rest.client.impl;

import org.springframework.stereotype.Component;

import com.hv.reantest.automation.authz.model.AddUserToGroup;
import com.hv.reantest.automation.authz.model.GroupDto;
import com.hv.reantest.automation.common.rest.client.BaseRestTemplate;
import com.hv.reantest.automation.rest.client.GroupRestClient;

/**
 * @author Rahul
 * @param <T>
 *
 */
@Component
public class GroupRestClientImpl extends BaseRestTemplate<GroupDto> implements GroupRestClient {

	public GroupRestClientImpl() throws Exception {
		super();
		// TODO Auto-generated constructor stub
	}

	private static String GROUP_URL = "authz/group";

	@Override
	public GroupDto getGroupWithName(String name) {
		return getForObject(appendUrls(GROUP_URL, "search") + "?name=" + name, GroupDto.class);
	}

	@Override
	public GroupDto saveGroup(GroupDto groupDto) {
		return postForObject(GROUP_URL, groupDto, GroupDto.class);
	}

	@Override
	public void deleteGroupById(Long id) {
		delete(appendUrls(GROUP_URL, id + ""));
	}

	@Override
	public void addUserToGroup(AddUserToGroup addUserToGroup) {
		postForObject(appendUrls(GROUP_URL, "user"), addUserToGroup, String.class);
	}

	@Override
	public GroupDto updateGroup(GroupDto groupDto) {
		return putForObject(GROUP_URL, groupDto, GroupDto.class);
	}

}