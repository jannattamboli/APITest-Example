/**
 * 
 */
package com.hv.reantest.automation.pageobj;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hv.reantest.automation.authz.model.AddUserToGroup;
import com.hv.reantest.automation.authz.model.BaseUserDto;
import com.hv.reantest.automation.authz.model.GroupDto;
import com.hv.reantest.automation.authz.model.PolicyDto;
import com.hv.reantest.automation.rest.client.GroupRestClient;
import com.hv.reantest.automation.rest.client.UserRestClient;

/**
 * @author Rahul
 *
 */
@Component
@ConfigurationProperties(prefix = "groupPage")
public class GroupPage extends AbstractPage {

	@Autowired
	private GroupRestClient groupRestClient;

	@Autowired
	private UserRestClient userRestClient;

	public GroupDto getGroupWithName(String name) {
		return groupRestClient.getGroupWithName(name);
	}

	public GroupDto createGroupIfNotExist(String name) {
		GroupDto existingGroup = getGroupWithName(name);

		if (existingGroup == null) {
			GroupDto group = new GroupDto();
			group.setName(name);
			group.setDescription("group created through automation");
			setPoliciesToGroup(group);
			return groupRestClient.saveGroup(group);
		}
		return existingGroup;
	}

	private void setPoliciesToGroup(GroupDto group) {

		GroupDto cloudArchGroup = groupRestClient.getGroupWithName("CLOUD_ARCHITECT");
		Set<PolicyDto> policies = cloudArchGroup.getPolicies();
		group.setPolicies(policies);

	}

	public void addUserToGroup(Long groupId, Long userId) {

		AddUserToGroup userToGroup = new AddUserToGroup();
		userToGroup.setUserId(userId);
		userToGroup.setGroupId(groupId);
		groupRestClient.addUserToGroup(userToGroup);
	}

	public void addUserToGroupWithGroupNameAndUserName(String groupName, String username) {
		GroupDto group = getGroupWithName(groupName);
		BaseUserDto user = userRestClient.getByUsername(username);
		if (group != null && user != null)
			addUserToGroup(group.getId(), user.getId());
	}

	public void deleteGroup(String name) throws Exception {

		GroupDto group = groupRestClient.getGroupWithName(name);

		if (group != null) {
			List<BaseUserDto> usersList = new ArrayList<>();
			List<AddUserToGroup> addUserToGroupList = new ArrayList<AddUserToGroup>();
			Collection<BaseUserDto> users = userRestClient.getUsersFromGroup(group.getId());
			TypeReference<BaseUserDto> baseUserDtoType = new TypeReference<BaseUserDto>() {
			};
			BaseUserDto readValue = null; // convert Hashmap into BaseUserDto object
			for (Iterator iterator = users.iterator(); iterator.hasNext();) {
				ObjectMapper mapper = new ObjectMapper();
				readValue = mapper.convertValue(iterator.next(), baseUserDtoType);
				usersList.add(readValue);
			}
			if (users != null) {
				for (BaseUserDto user : usersList) {
					AddUserToGroup userToGroup = new AddUserToGroup();
					userToGroup.setGroupId(group.getId());
					userToGroup.setUserId(user.getId());
					addUserToGroupList.add(userToGroup);
				}
				userRestClient.detachGroupFromUser(addUserToGroupList); // detaching existing Policies
			}
			groupRestClient.deleteGroupById(group.getId());
		}
	}

}
