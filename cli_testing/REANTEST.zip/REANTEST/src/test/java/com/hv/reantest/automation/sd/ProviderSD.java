package com.hv.reantest.automation.sd;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.hv.reantest.automation.TestApplication;
import com.hv.reantest.automation.pageobj.CommonPage;
import com.hv.reantest.automation.pageobj.ProviderPage;

import cucumber.api.java.en.When;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = TestApplication.class)
@SpringBootTest
public class ProviderSD {

	@Autowired
	CommonPage commonpage;
	
	@Autowired
	ProviderPage providerpage;
	

	@When("^Fill the AWS credentials tab details using \"([^\"]*)\"$")
	public void fill_the_AWS_credentials_tab_details_using(String type) throws Throwable {
		providerpage.fillAWSCredentialsProviderJson(type);
		}

	@When("^Fill the Infrastucture tab details$")
	public void fill_the_Infrastucture_tab_details() throws Throwable {
		providerpage.fillInfrastuctureDetials();
		providerpage.makeProviderDefault();
		}

}
