package com.hv.reantest.automation.sd;

import java.util.List;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.hv.reantest.automation.TestApplication;
import com.hv.reantest.automation.pageobj.AbstractPage;
import com.hv.reantest.automation.pageobj.LoginPage;
import com.hv.reantest.automation.pageobj.PlatformHomePage;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = TestApplication.class)
@SpringBootTest
public class LoginPageSD extends AbstractPage{
	
	@Autowired
	LoginPage loginPage;
	
	@Autowired
	PlatformHomePage platFormPage;
	
	@Value("${com.hv.reantest.automation.authentication.admin_user}")
	String adminUser;
	
	@Value("${com.hv.reantest.automation.authentication.admin_password}")
	String adminPassword;
	
	@Value("${com.hv.reantest.automation.authentication.non_admin_user}")
	String nonAdminUser;
	
	@Value("${com.hv.reantest.automation.authentication.non_admin_password}")
	String nonAdminPassword;

	@Given("^User is at sign up page$")
	public void userGoesToSignUp() throws Throwable {
		loginPage.toPage().goOnSignUp();
	}

	@Given("^User is at sign in page$")
	public void userIsAtSignInPage() throws Throwable {
		loginPage.toPage();
	}
	
	@Given("^User sign in$")
	public void userSignIn(DataTable dataTable) throws Throwable {
		List<String> list = dataTable.raw().get(0);
		String userName = list.get(0);
		String userPasswrod = list.get(1);
		loginPage.login(userName, userPasswrod);
	}
	
	@Given("^Admin sign in$")
	public void adminCanSignIn() throws Throwable {
		loginPage.login(adminUser, adminPassword);
	}
	
	@Given("^Non Admin User sign in$")
	public void nonAdminUserSignIn() throws Throwable {
		loginPage.login(nonAdminUser, nonAdminPassword);
	}
	
	@Then("^Verify authentication failed error$")
	public void verifyInvalidUserMessage() {
		loginPage.verifyErrorNotificationMessage("Authentication Failed:");
	}

    @Given("^User sign out$")
    public void userSignOut() throws Throwable {
        loginPage.logout();
    }
    
    @When("^User enters only \"([^\"]*)\" in SignIn form$")
    public void userEntersOnlyInSignInForm(String arg) throws Throwable {
    	loginPage.enterFieldInSigninForm(arg);
    }

    @Then("^Verify SignIn button is disabled$")
    public void verifySignInButtonIsDisabled() throws Throwable {
		boolean b = isElementDisabled("login-signin-btn");
		if(!b) {
			 throw new RuntimeException("Verify sign-in button is not disabled");
		}
    }
    
	@Then("^Verify SignIn button is enabled$")
	public void verifySignInButtonEnabled() throws Throwable {
		boolean b = isElementDisabled("login-signin-btn");
		if(b) {
			 throw new RuntimeException("Verify sign-in button is not enabled");
		}
	}

}

