package com.hv.reantest.automation.pageobj;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.hv.reantest.automation.utils.AutomationUtils;

import cucumber.api.DataTable;

@Component
@ConfigurationProperties(prefix = "loginpage")
public class SignUpPage extends AbstractPage{

	public void enterSignupDetails(String fullName, String username, String email, String password) {
		editText("input_0", fullName);
		editText("input_1", username);
		editText("input_2", email);
		editText("input_3", password);
	}
	
	public void clearTheForm(String fullName, String username, String email, String password) {
		editText("input_0", "");
		editText("input_1", "");
		editText("input_2", "");
		editText("input_3", "");
	}


	public void clickTermsAndConditions() {
		clickElementWithText("I agree to the");
	}

	public void clickSignUpButton() {
		clickMdButtonWithLabel("SIGN UP");
		
	}
}
