/**
 * 
 */
package com.hv.reantest.automation.rest.client.impl;

import java.util.Collection;
import java.util.List;

import org.springframework.stereotype.Component;

import com.hv.reantest.automation.authz.model.AddUserToGroup;
import com.hv.reantest.automation.authz.model.BaseUserDto;
import com.hv.reantest.automation.authz.model.UserDto;
import com.hv.reantest.automation.common.rest.client.BaseRestTemplate;
import com.hv.reantest.automation.rest.client.UserRestClient;

/**
 * @author Rahul
 *
 */
@Component
public class UserRestClientImpl extends BaseRestTemplate<BaseUserDto> implements UserRestClient {

	public UserRestClientImpl() throws Exception {
		super();
		// TODO Auto-generated constructor stub
	}

	public static final String USER_URL = "user";
	private static final String GROUP_URL = "authz/group";

	@Override
	public BaseUserDto getByUsername(String username) {
		String getUserUrl = appendUrls(USER_URL, "get-by-username", username);
		return getForObject(getUserUrl, BaseUserDto.class);
	}

	@Override
	public BaseUserDto signup(UserDto userDto) {
		String signupUserUrl = appendUrls(USER_URL, "signup");
		return postForObject(signupUserUrl, userDto, BaseUserDto.class);
	}

	@Override
	public BaseUserDto updateUser(BaseUserDto userDto) {
		return putForObject(USER_URL, userDto, BaseUserDto.class);
	}

	@Override
	public BaseUserDto disableUser(long id) {
		String disableUserUrl = appendUrls(USER_URL, "disable", id + "");
		return putForObject(disableUserUrl, null, BaseUserDto.class);
	}
	
	@Override
	public BaseUserDto enableUser(long id) {
		String enableUserUrl = appendUrls(USER_URL, "/enable/", id + "");
		return putForObject(enableUserUrl, null, BaseUserDto.class);
	}
	
	@Override
	public Collection<BaseUserDto> getUsersFromGroup(Long id) throws Exception {
		return getForListOfObjects(appendUrls(GROUP_URL, "usersbygroup", id + ""), BaseUserDto.class);
	}

	@Override
	public void detachGroupFromUser(List<AddUserToGroup> addUserToGroupList) {
		postForObject(appendUrls(GROUP_URL, "users/detach"), addUserToGroupList, BaseUserDto.class);
	}
}
