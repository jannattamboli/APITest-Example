/**
 * 
 */
package com.hv.reantest.automation.rest.client;

import org.springframework.stereotype.Component;

import com.hv.reantest.automation.authz.model.AddUserToGroup;
import com.hv.reantest.automation.authz.model.GroupDto;

/**
 * @author Rahul
 *
 */
@Component
public interface GroupRestClient {

	public GroupDto saveGroup(GroupDto groupDto);

	public GroupDto getGroupWithName(String name);

	public void deleteGroupById(Long id);

	void addUserToGroup(AddUserToGroup addUserToGroup);

	GroupDto updateGroup(GroupDto groupDto);

	
}
