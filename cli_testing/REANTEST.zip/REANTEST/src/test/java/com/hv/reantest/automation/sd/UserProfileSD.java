package com.hv.reantest.automation.sd;

import java.util.List;
import java.util.Map;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.hv.reantest.automation.TestApplication;
import com.hv.reantest.automation.pageobj.UserProfilePage;

import cucumber.api.DataTable;
import cucumber.api.java.en.When;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = TestApplication.class)
@SpringBootTest
public class UserProfileSD {

	@Autowired
	UserProfilePage userProfile;
	
	@When("^User navigate to profile page$")
	public void user_navigate_to_profile_page() throws Throwable {
	    userProfile.navigateTouserprofile();
	}

	@When("^User validate the user data$")
	public void user_validate_the_user_data(DataTable dataTable) throws Throwable {
		List<Map<String,String>> userData=dataTable.asMaps(String.class, String.class);
	    userProfile.validateUserData(userData);
	}

	@When("^Change Full Name as \"([^\"]*)\"$")
	public void change_Full_Name(String newFullName) throws Throwable {
	    userProfile.changeFullName(newFullName);
	}

	@When("^Update user$")
	public void update_user() throws Throwable {
	    userProfile.clickUpdateUser();
	}

	@When("^User validate the change password form$")
	public void user_validate_the_change_password_form(DataTable dataTable) throws Throwable {
		List<Map<String,String>> parameters=dataTable.asMaps(String.class, String.class);
		String currentPassword=parameters.get(0).get("currentPassword");
	    userProfile.validateChangePasswordForm(currentPassword);
	}

	@When("^change password$")
	public void change_password(DataTable dataTable) throws Throwable {
		List<Map<String,String>> parameters=dataTable.asMaps(String.class, String.class);
	    userProfile.changePassword(parameters);
	}
}
