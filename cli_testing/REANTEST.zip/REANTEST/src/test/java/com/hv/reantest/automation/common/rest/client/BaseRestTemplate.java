package com.hv.reantest.automation.common.rest.client;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.hv.reantest.automation.utils.JsonUtils;

@Component
public class BaseRestTemplate<T> extends RestTemplate {
	
	

	@Value("${com.hv.authz.base-url}")
	protected String authBaseUrl;
	
	@Value("${com.hv.reantest.automation.authentication.admin_user}")
	private String adminUser;
	
	@Value("${com.hv.reantest.automation.authentication.admin_password}")
	private String adminPassword;


	public Collection<T> getForListOfObjects(String url, Class<T> t) throws Exception {
		HttpEntity<Object> requestEntity = getEntityWithHeader();
		String s = exchange(appendUrls(authBaseUrl, url), HttpMethod.GET, requestEntity, String.class).getBody();
		return JsonUtils.readJsonAsList(s, new TypeReference<List<T>>() {
		});
	}

	public <T> T getForObject(String url, Class<T> t) {
		HttpEntity<Object> requestEntity = getEntityWithHeader();
		System.out.println(appendUrls(authBaseUrl, "/", url));
		return exchange(appendUrls(authBaseUrl, url), HttpMethod.GET, requestEntity, t).getBody();
	}

	public <T> T postForObject(String url, Object r, Class<T> t) {
		HttpEntity<Object> requestEntity = getEntityHeaderWithBody(r);
		ResponseEntity<T> exchange = exchange(appendUrls(authBaseUrl, url), HttpMethod.POST, requestEntity, t);
		return exchange.getBody();
	}

	public HttpEntity<Object> getEntityWithHeader() {
		HttpHeaders headers = getHeaders();
		HttpEntity<Object> requestEntity = new HttpEntity<>(headers);
		return requestEntity;
	}

	public HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "application/json");
		headers.add("Accept", "*/*");
		headers.add("Authorization", adminUser + ":" + adminPassword);
		return headers;
	}

	public HttpEntity<Object> getEntityHeaderWithBody(Object r) {
		HttpHeaders headers = getHeaders();
		HttpEntity<Object> requestEntity = new HttpEntity<Object>(r, headers);
		return requestEntity;
	}

	public <T> T putForObject(String url, Object r, Class<T> t) {
		HttpEntity<Object> requestEntity = getEntityHeaderWithBody(r);
		ResponseEntity<T> exchange = exchange(appendUrls(authBaseUrl, url), HttpMethod.PUT, requestEntity, t);
		return exchange.getBody();
	}

	public void delete(String url) {
		HttpEntity<Object> requestEntity = getEntityWithHeader();
		exchange(appendUrls(authBaseUrl, url), HttpMethod.DELETE, requestEntity, String.class);
	}

	public String appendUrls(String... urls) {
		String url = "";
		if (urls != null && urls.length > 0) {
			url = urls[0];
			for (int i = 1; i < urls.length; i++) {
				String u = urls[i];
				if (!url.endsWith("/")) {
					url += "/";
				}
				url += u;
			}
		}
		return url;

	}

	public void setAuthnzBaseUrl(String url) {
		authBaseUrl = url;
	}
}
