package com.hv.reantest.automation.pageobj;

import org.apache.commons.lang3.text.translate.NumericEntityUnescaper.OPTION;
import org.openqa.selenium.support.ui.Sleeper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.hv.reantest.automation.DriverFactory;
import com.hv.reantest.automation.utils.AutomationUtils;

@Component
@ConfigurationProperties(prefix = "commonpage")

public class CommonPage extends AbstractPage {
	
	@Autowired
	DriverFactory driverFactory;
	@Value("${com.hv.reantest.automation.authentication.aws_access_key}")
	String accessKey;
	
	@Value("${com.hv.reantest.automation.authentication.aws_secret_key}")
	String secretKey;
	
	@Value("${com.hv.reantest.automation.authentication.aws_region}")
	String region;
	
	@Value("${com.hv.reantest.automation.authentication.role_arn}")
	String roleArn;
	
	@Value("${com.hv.reantest.automation.authentication.session_name}")
	String sessionName;
	
	@Value("${com.hv.reantest.automation.authentication.external_id}")
	String externalId;
	
    public void navigateToAccelerator(String accelerator) {
    	System.out.println("before navigating to accelerator");
    	clickId("accelerator-dropdown");
    	clickId(accelerator);
    	System.out.println("navigating to accelerator");
	}
    
     public void navigateToTestJob(String testjob) {
		
		clickXpath(testjob);
	}
    
    public void navigateToTabs(String label) {
		
    	switch(label) {
		case "NEXT":
			clickMdButtonWithLabel(label);
			break;
		case "PREVIOUS":
			clickMdButtonWithLabel(label);
			break;
		case "Submit":
			clickMdButtonWithLabel(label);
			break;
		case "schedule":
			clickMdButtonWithLabel(label);
			break;
		case "CANCEL":
			clickMdButtonWithLabel(label);
			break;
		case "ADD PROVIDER":
			clickMdButtonWithLabel(label);
    	}
    	AutomationUtils.sleepInSec(5);
		
	}
    
	public void navigateToMoreOption(String option) {
		
		clickElementHavingClass("fa deploynow-new-icons action-icon", "i");
		switch(option) {
		case "Scans":
			clickId("scanner");
			System.out.println("Navigated to Scanner");
			break;
		case "Provider":
			clickId("providers");
			System.out.println("Navigated to Provider");
			break;
		case "Schedule":
			clickId("scheduler");
			System.out.println("Navigated to schedule list");
			break;
		case "Configuration":
			clickId("config");
			System.out.println("Navigated to configuration page");
			break;
		default:
			System.out.println("Not a valid option");
		}
	}

	public void fillProviderJson(String type) {
		String basicCredentials= "{\n" + 
                "  \"access_key_id\": \"" +accessKey+ "\",\n" + 
                "  \"secret_key\": \""+secretKey+"\",\n" + 
                "  \"region\": \""+region+"\"\n" + 
                "}";
		
		String instanceProfile= "{\n" + 
				"  \"region\": \""+ region+"\"\n" + 
				"}";
		
		String assumeRoleUsingInstanceProfile= "{\n" + 
				"  \"region\": \""+ region+"\",\n" + 
				"  \"assume_role\": {\n" + 
				"    \"role_arn\": \"\""+roleArn+",\n" + 
				"    \"session_name\": \"\""+sessionName+",\n" + 
				"    \"external_id\": \"\""+externalId+"\n" + 
				"  }\n" + 
				"}";
		
		String assumeRoleUsingBasicCredentials="{\n" + 
                "  \"access_key\": \"" +accessKey+ "\",\n" + 
                "  \"secret_key\": \""+secretKey+"\",\n" + 
				"  \"region\": \""+region+"\",\n" + 
				"  \"assume_role\": {\n" + 
				"    \"role_arn\": \"\""+roleArn+",\n" + 
				"    \"session_name\": \"\""+sessionName+",\n" + 
				"    \"external_id\": \"\""+externalId+"\n" + 
				"  }\n" + 
				"}";
		
		AutomationUtils.sleepInSec(5);
		if (type.equalsIgnoreCase("basicCredentials"))
		    enterInJSONEditor(basicCredentials);
		else if(type.equalsIgnoreCase("assumeRoleUsingBasicCredentials"))
			enterInJSONEditor(assumeRoleUsingBasicCredentials);
		else if(type.equalsIgnoreCase("instanceProfile"))
			enterInJSONEditor(instanceProfile);
		else
			enterInJSONEditor("assumeRoleUsingInstanceProfile");
		
		AutomationUtils.sleepInSec(5);
	}
	
	protected void selectProviderTypeAndFillDetails(String type) 
	{
		
		System.out.println("In selectProviderTypeAndFillDetails");
		switch(type)
		{
		case "BasicCredentials" :
			clickMdRadioButtonWithValue("basicCredentials");
			fillProviderJson(type);
			break;
		case "AssumeRoleUsingBasicCredentials" :
			clickMdRadioButtonWithValue("basicCredentials");
			clickElementWithXPath("//span[contains(text(),'Assume Role')]");
			fillProviderJson(type);
			break;
		case "InstanceProfile" :
			clickMdRadioButtonWithValue("instanceProfile");
			fillProviderJson(type);
			break;
		case "AssumeRoleUsingInstanceProfile" :
			clickMdRadioButtonWithValue("instanceProfile");
			clickElementWithXPath("//span[contains(text(),'Assume Role')]");
			fillProviderJson(type);
			break;
		}
	}

	
	
	
}
