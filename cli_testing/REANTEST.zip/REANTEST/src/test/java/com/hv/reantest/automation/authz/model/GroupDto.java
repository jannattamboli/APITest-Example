package com.hv.reantest.automation.authz.model;

import java.util.Set;

/**
 * @author ganeshkhakare
 *
 */
public class GroupDto extends BaseDto {

	

	String name;

	String description;

	Set<PolicyDto> policies;


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Set<PolicyDto> getPolicies() {
		return policies;
	}

	public void setPolicies(Set<PolicyDto> policies) {
		this.policies = policies;
	}
}
