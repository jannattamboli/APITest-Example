package com.hv.reantest.automation.sd;

import java.util.List;
import java.util.Map;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.hv.reantest.automation.TestApplication;
import com.hv.reantest.automation.pageobj.AbstractPage;
import com.hv.reantest.automation.pageobj.SignUpPage;
import com.hv.reantest.automation.utils.AutomationUtils;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = TestApplication.class)
@SpringBootTest
public class SignUpUserSD extends AbstractPage{
	
	@Autowired
	SignUpPage signUpPage;
	
	@Given("^User fills sign up form$")
	public void enterSignupDetails(DataTable dataTable) throws Throwable {
		List<String> list = dataTable.raw().get(0);
		String fullName = list.get(0);
		String username = list.get(1);
		String email = list.get(2);
		String password = list.get(3);
		signUpPage.enterSignupDetails(fullName, username, email, password);
	}
	
	@Given("^User fills sign up form and accepts terms and conditions$")
	public void enterSignupDetailsAndAcceptTerms(DataTable dataTable) throws Throwable {
		this.enterSignupDetails(dataTable);
		signUpPage.clickTermsAndConditions();
	}
	
	@Given("^I accepts terms and conditions$")
	public void acceptsTermsAndCondition(DataTable dataTable) throws Throwable {
		signUpPage.clickTermsAndConditions();
	}
	
	@Then("^Verify SignUp button is disabled$")
	public void verifySignUpButtonDisabled() throws Throwable {
		boolean b = isElementDisabled("reg-signin-btn");
		if(!b) {
			 throw new RuntimeException("Verify sign-up button is not disabled");
		}
	
	}
	
	@Then("^Verify SignUp button is enabled$")
	public void verifySignUpButtonEnabled() throws Throwable {
		boolean b = isElementDisabled("reg-signin-btn");
		if(b) {
			 throw new RuntimeException("Verify sign-up button is not enabled");
		}
	}
	
	@Then("^User click on Signup button$")
	public void user_click_on_Signup_button_and_verify_successful_signup_notification_message() throws Throwable {
	    signUpPage.clickSignUpButton();
	}
	
	@When("^User validate sign up form with empty or invalid values and accepts terms and conditions and check button is disabled$")
	public void enterDataArraySignupDetails(DataTable dataTable) throws Throwable {
		List<Map<String, String>> list = dataTable.asMaps(String.class, String.class);
		for(int i=0; i<list.size(); i++) {	
		    String fullName = list.get(i).get("fullName");
			String username = list.get(i).get("username");
			String email = list.get(i).get("emailId");
			String password = list.get(i).get("password");
			signUpPage.enterSignupDetails(fullName, username, email, password);
		    signUpPage.clickTermsAndConditions();
		    this.verifySignUpButtonDisabled();
		    AutomationUtils.sleepInSec(5);
		}
	}
}
