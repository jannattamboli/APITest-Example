/**
 * 
 */
package com.hv.reantest.automation.rest.client;

import java.util.Collection;
import java.util.List;

import org.springframework.stereotype.Component;

import com.hv.reantest.automation.authz.model.AddUserToGroup;
import com.hv.reantest.automation.authz.model.BaseUserDto;
import com.hv.reantest.automation.authz.model.UserDto;

/**
 * @author Rahul
 *
 */
@Component
public interface UserRestClient {

	BaseUserDto getByUsername(String username);

	BaseUserDto disableUser(long id);

	Collection<BaseUserDto> getUsersFromGroup(Long id) throws Exception;

	BaseUserDto updateUser(BaseUserDto userDto);

	BaseUserDto signup(UserDto userDto);

	void detachGroupFromUser(List<AddUserToGroup> addUserToGroupList);

	BaseUserDto enableUser(long id);

}
