package com.hv.reantest.automation.sd;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.hv.reantest.automation.TestApplication;
import com.hv.reantest.automation.pageobj.LoginPage;
import com.hv.reantest.automation.pageobj.PlatformHomePage;

import cucumber.api.java.en.Then;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = TestApplication.class)
@SpringBootTest
public class PlatformHomePageSD {
	
	@Value("${com.hv.reantest.automation.authentication.admin_user}")
	String adminUser;
	
	@Autowired
	PlatformHomePage plaformHomePage;
	
	@Autowired
	LoginPage loginPage;
	
	
	@Then("^Verify user is logged in$")
	public void verifyUserIsSignedIn(String user) {
		plaformHomePage.clickAndVerifyLoginUser(user);
	}
	
	@Then("^Verify admin is logged in$")
	public void verifyAdminIsSignedIn() {
		plaformHomePage.clickAndVerifyLoginUser(adminUser);
	}
	
	@Then("^Logout user$") 
	public void loggOutUser(){
		plaformHomePage.loggOutUser();
		loginPage.waitUntilLogginPageLoaded();
	}
	
	@Then("^Verify \"([^\"]*)\" has signed in$")
	public void verify_provided_user_has_signed_in(String userName) throws Throwable {
		plaformHomePage.clickAndVerifyLoginUser(userName);
	}
}
