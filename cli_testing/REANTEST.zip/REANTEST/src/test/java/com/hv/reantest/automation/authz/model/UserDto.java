/**
 * 
 */
package com.hv.reantest.automation.authz.model;

/**
 * @author komal
 *
 */
public class UserDto extends BaseUserDto {
	private UserAuthenticationDto userAuthentication;

	public UserAuthenticationDto getUserAuthentication() {
		return userAuthentication;
	}

	public void setUserAuthentication(UserAuthenticationDto userAuthentication) {
		this.userAuthentication = userAuthentication;
	}
}
