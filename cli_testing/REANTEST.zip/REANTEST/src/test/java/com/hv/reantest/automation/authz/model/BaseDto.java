package com.hv.reantest.automation.authz.model;

/**
 * @author ganeshkhakare
 *
 */
public class BaseDto {

	long id;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
}
