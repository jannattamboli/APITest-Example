/**
 * 
 */
package com.hv.reantest.automation.sd;

import java.util.List;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.hv.reantest.automation.TestApplication;
import com.hv.reantest.automation.authz.model.BaseUserDto;
import com.hv.reantest.automation.authz.model.GroupDto;
import com.hv.reantest.automation.pageobj.GroupPage;
import com.hv.reantest.automation.pageobj.UserPage;

import cucumber.api.DataTable;
import cucumber.api.java.en.When;

/**
 * @author Rahul
 *
 */

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = TestApplication.class)
@SpringBootTest
public class GroupPageSD {

	@Autowired
	private GroupPage groupPage;

	@Autowired
	private UserPage userPage;

	@When("^Create group and user if not exist and add in group$")
	public void create_group_and_user_if_not_exit_and_add_in_group(DataTable dataTable) throws Throwable {

		List<String> list = dataTable.raw().get(0);
		String groupName = list.get(0);
		String userName = list.get(1);
		String userEmail = list.get(2);
		
		BaseUserDto user = userPage.createUserIfNotExist(userName, userEmail);
		GroupDto group = groupPage.createGroupIfNotExist(groupName);

		// add user to group
		if (group != null && user != null)
			groupPage.addUserToGroup(group.getId(), user.getId());

	}

	@When("^Create group if not exist: \\\"([^\\\"]*)\\\"$")
	public void create_group_if_not_exit(String groupName) throws Throwable {
		groupPage.createGroupIfNotExist(groupName);
	}

	@When("^Add user to group$")
	public void add_user_to_group(DataTable dataTable) throws Throwable {
		List<String> list = dataTable.raw().get(0);
		String groupName = list.get(0);
		String userName = list.get(1);

		groupPage.addUserToGroupWithGroupNameAndUserName(groupName, userName);
	}

	@When("^Delete group and Disable user$")
	public void delete_group_and_disable_user(DataTable dataTable) throws Throwable {
		List<String> list = dataTable.raw().get(0);
		String groupName = list.get(0);
		String userName = list.get(1);
		groupPage.deleteGroup(groupName);
		userPage.disableUser(userName);
	}

	@When("^Delete group: \\\"([^\\\"]*)\\\"$")
	public void delete_group(String groupName) throws Throwable {
		groupPage.deleteGroup(groupName);
	}
}
