/**
 * 
 */
package com.hv.reantest.automation.authz.model;

/**
 * @author komal
 *
 */
public class UserAuthenticationDto extends BaseDto {
	private String password;

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
