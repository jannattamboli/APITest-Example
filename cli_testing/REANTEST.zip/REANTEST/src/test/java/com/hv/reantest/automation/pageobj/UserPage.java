/**
 * 
 */
package com.hv.reantest.automation.pageobj;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.hv.reantest.automation.authz.model.AddUserToGroup;
import com.hv.reantest.automation.authz.model.BaseUserDto;
import com.hv.reantest.automation.authz.model.UserAuthenticationDto;
import com.hv.reantest.automation.authz.model.UserDto;
import com.hv.reantest.automation.rest.client.UserRestClient;

/**
 * @author Rahul
 *
 */
@Component
@ConfigurationProperties(prefix = "userPage")
public class UserPage extends AbstractPage {

	private BaseUserDto existingUser;
	
	@Autowired
	private UserRestClient userRestClient;

	public BaseUserDto getUserWithName(String name) {
		return userRestClient.getByUsername(name);
	}

	public BaseUserDto createUserIfNotExist(String name, String email) {

		existingUser = getUserWithName(name);
		if (existingUser == null) {
			UserDto user = new UserDto();
			UserAuthenticationDto userAuthentication = new UserAuthenticationDto();
			user.setName(name);
			user.setUsername(name);
			user.setEmail(email);
			user.setVerified(true);
			user.setVerificationDate(new Date());
			userAuthentication.setPassword(name);
			user.setUserAuthentication(userAuthentication);
			existingUser = userRestClient.signup(user);
		} else if (existingUser.isDisabled())
			userRestClient.enableUser(existingUser.getId());
		return existingUser;
	}

	public void disableUser(String userName) {
		BaseUserDto user = getUserWithName(userName);
		if (user != null)
			userRestClient.disableUser(user.getId());
	}
	
	
	public Collection<BaseUserDto> getUsersFromGroup(Long id) throws Exception {
		return userRestClient.getUsersFromGroup(id);
	}
	
	public void detachGroupToUser(List<AddUserToGroup> addUserToGroupList) {
		userRestClient.detachGroupFromUser(addUserToGroupList);
	}
	

}
