package com.hv.reantest.automation.pageobj;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "homepage")
public class PlatformHomePage extends AbstractPage{
	

	public final String homeIconXPath = "//i[contains(@class,'deploynow-new-icons fa user-icon')]";

	
	public void clickAndVerifyLoginUser(String user) {
		waitUntilElementWithXPathPresent(homeIconXPath, 50);
		clickElementWithXPath(homeIconXPath);
		assert (isElementPresentWithXPATH("//*[@id='userProfilelink']/*[text()='"+user.toLowerCase()+"']") == true) : "Logged in user with username " + user.toLowerCase() + " does not present";
	}

	public void loggOutUser() {
		try{
			clickId("userLogoutlink");
		}
		catch(Exception e){
			waitUntilElementWithXPathPresent(homeIconXPath, 15);
			clickElementWithXPath(homeIconXPath);
			clickId("userLogoutlink");
		}
		
	}

	

	

}
