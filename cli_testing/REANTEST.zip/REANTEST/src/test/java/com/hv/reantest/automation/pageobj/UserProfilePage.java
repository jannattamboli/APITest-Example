package com.hv.reantest.automation.pageobj;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.hv.reantest.automation.utils.AutomationUtils;

@Component
@ConfigurationProperties(prefix = "userProfilePage")
public class UserProfilePage extends AbstractPage{

	public void navigateTouserprofile()	{
		//waitForButtonToBeEnabledAndClick("//*[@id='profile-dropdown']");
		if(driverFactory.getDriver().findElement(By.xpath("//*[@id='userProfilelink']")).isDisplayed())
			clickId("userProfilelink");
		else{
			clickElementWithXPath("//*[@id='profile-dropdown']");
			clickId("userProfilelink");
		}
		waitUntilElementWithXPathPresent("//h3[contains(text(),'Welcome')] ");
	}

	public void validateUserData(List<Map<String, String>> userData) {
		String userName=userData.get(0).get("username");
		String email=userData.get(0).get("email");
		String fullName=userData.get(0).get("fullName");
		isThere(userName);
		isThere(email);
		isThere(fullName);		
	}

	public void changeFullName(String newFullName) {
		editTextWithName("name", newFullName);
	}

	public void clickUpdateUser() {
		clickMdButtonWithLabel(" UPDATE USER ");
		AutomationUtils.sleepInSec(1);
		clickMdButtonWithLabel("YES");
	}

	public void changePassword(List<Map<String, String>> parameters) {
		String oldPassword=parameters.get(0).get("oldPassword");
		String newPassword=parameters.get(0).get("newPassword");
		clickElementWithText("CHANGE PASSWORD", "span");
		enterNewPasswordCredentials(oldPassword,newPassword);
	}
	protected void enterNewPasswordCredentials(String oldPassword, String newPassword) {
		editText("userOldPassword", oldPassword);
		editText("userNewPassword", newPassword);
		editText("userConfirmPassword", newPassword);
		waitForButtonToBeEnabledAndClick("SUBMIT");
	}

	public void validateChangePasswordForm(String currentPassword) {
		AutomationUtils.sleepInSec(2);
		clickElementWithText("CHANGE PASSWORD", "span");
		AutomationUtils.sleepInSec(2);
		isElementByXPathDisabled("//*[text()='SUBMIT']");
		enterNewPasswordCredentials("", "");
		isElementByXPathDisabled("//*[text()='SUBMIT']");
		editText("userOldPassword", currentPassword);
		isElementByXPathDisabled("//*[text()='SUBMIT']");
		editText("userNewPassword", "ABCDEFGhij123");
		isElementByXPathDisabled("//*[text()='SUBMIT']");
		editText("userConfirmPassword", "abcdefGHI456");
		isElementByXPathDisabled("//*[text()='SUBMIT']");	
		editText("userNewPassword", "123");
		isElementByXPathDisabled("//*[text()='SUBMIT']");
		editText("userConfirmPassword", "456");
		isElementByXPathDisabled("//*[text()='SUBMIT']");
		editText("userNewPassword", "ABCDEFG");
		isElementByXPathDisabled("//*[text()='SUBMIT']");
		editText("userConfirmPassword", "abcde");
		isElementByXPathDisabled("//*[text()='SUBMIT']");
		clickMdButtonWithLabel("CANCEL");
		AutomationUtils.sleepInSec(1);
	}

	
}
