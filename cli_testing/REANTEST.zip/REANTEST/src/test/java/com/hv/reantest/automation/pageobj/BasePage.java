
package com.hv.reantest.automation.pageobj;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.hv.reantest.automation.utils.AutomationUtils;

@Component
@ConfigurationProperties(prefix = "common")
public class BasePage extends AbstractPage{
	
	public void moveToSubmenu(String submenu)
	{
		clickIdByJs("action-dropdown ");
		waitUntilElementWithIdPresent(submenu);
		clickIdByJs(submenu);
	}

	public void moveToUserProfile(){
		clickIdByJs("userProfilelink");
	}	

	public void moveToHomePage() {
        clickElementWithJs("//span[@class='fa-stack fa-lg img-size deploynow-new-icons REAN-DeployLogo']");
        AutomationUtils.sleepInSec(5);
    }
	
	public void clickOnSubmitButton() {
		clickElementWithJs("//button[contains(text(),'SUBMIT')]");
	}

	
}
