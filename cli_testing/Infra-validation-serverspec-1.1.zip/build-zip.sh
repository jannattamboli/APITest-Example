#!/bin/sh
home=$(pwd)
zip -r Infra-validation-serverspec-$1.zip . -x *.git*
echo "Zip artifact for serverspec validation automation is created." 
