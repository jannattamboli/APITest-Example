package starter.status;

public enum AppStatus {
    RUNNING, DOWN
}
