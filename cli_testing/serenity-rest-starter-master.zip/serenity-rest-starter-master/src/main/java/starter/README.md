### Application code
 
These packages contain a simple SpringBoot web service, which is exercised as part of the sample test scenarios.